/* SecureTable Audit Dashboard — ADMIN read-only.
   Actual authorization is enforced by API Gateway and Lambda. */
(() => {
  'use strict';
  const session = window.STAuth?.requireRole('ADMIN');
  if (!session) return;
  const byId = id => document.getElementById(id);
  const PAGESIZE = 30;
  const fmtNum = n => Number(n || 0).toLocaleString('vi-VN');
  const localDay = () => new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  const dateShift = (day, amount) => {
    const d = new Date(day + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+amount); return d.toISOString().slice(0,10);
  };
  const dateTime = iso => {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.valueOf())) return String(iso);
    return d.toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',dateStyle:'short',timeStyle:'medium'});
  };
  function node(tag, text, cls) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }
  const setStatus = (message, error=false) => {
    const el=byId('status'); el.textContent=message; el.className='status'+(error?' err':'');
  };
  let cursorPages=[null], page=0, nextCursor=null, requestID=0, filters=null;
  function buildFilters() {
    const from=byId('from-date').value, to=byId('to-date').value;
    const length=(Date.parse(to+'T12:00:00Z')-Date.parse(from+'T12:00:00Z'))/86400000;
    if (!from || !to || !Number.isFinite(length) || length<0 || length>30) throw new Error('Chọn khoảng từ 1 đến 31 ngày.');
    return {
      from,to,actor:byId('actor-filter').value.trim(),
      action:byId('action-filter').value.trim().toUpperCase(),
      resource:byId('resource-filter').value.trim(),limit:String(PAGESIZE)
    };
  }
  function drawOverview(summary) {
    byId('total-events').textContent=fmtNum(summary.total_events);
    byId('unique-actors').textContent=fmtNum(summary.unique_actors);
    byId('unique-actions').textContent=fmtNum(summary.unique_actions);
    const daily=byId('daily-bars'); daily.replaceChildren();
    const stats=Array.isArray(summary.by_day)?summary.by_day:[];
    if (!stats.length) daily.append(node('p','Không có sự kiện trong kỳ.','small'));
    else {
      const max=Math.max(1,...stats.map(x=>x.count));
      for(const item of stats){
        const box=node('div',undefined,'audit-day');
        const count=node('span',fmtNum(item.count),'count');
        const bar=node('div',undefined,'audit-bar'); bar.style.height=Math.max(3,Math.round(125*Number(item.count)/max))+'px';
        bar.title=item.date+': '+item.count+' sự kiện';
        box.append(count,bar,node('small',item.date.slice(5))); daily.append(box);
      }
    }
    const acts=byId('action-stats'); acts.replaceChildren();
    const popular=Array.isArray(summary.action_counts)?summary.action_counts.slice(0,8):[];
    if(!popular.length) acts.append(node('p','Chưa có hành động nào.','small'));
    for(const item of popular){
      const div=node('div',undefined,'action-stat');div.append(node('span',item.action),node('strong',fmtNum(item.count)));acts.append(div);
    }
  }
  function actionKind(action){
    const val=String(action||'');
    if (/REJECT|OUT|LOSS|UNPAID/.test(val)) return 'danger';
    if (/CORRECT|COUNT|AUTO/.test(val)) return 'warn';
    return '';
  }
  function drawTable(items,total,limit,cursor){
    const tbody=byId('audit-rows');tbody.replaceChildren();
    const n=(Array.isArray(items)?items:[]);
    for(const row of n){
      const tr=node('tr');
      tr.append(node('td',dateTime(row.timestamp||row.created_at)));
      const action=node('td');action.append(node('span',row.action||'UNKNOWN','audit-action '+actionKind(row.action)));tr.append(action);
      tr.append(node('td',row.actor_role||'—'));
      tr.append(node('td',row.actor_id||'—','actor'));
      tr.append(node('td',[row.resource_type,row.resource_id].filter(Boolean).join(' / ')||row.bill_id||row.table_id||'—','resource'));
      const detail=node('td');const btn=node('button','Xem chi tiết','ghost');btn.type='button';btn.addEventListener('click',()=>showDetail(row));detail.append(btn);tr.append(detail);
      tbody.append(tr);
    }
    if(!n.length){const tr=node('tr'),cell=node('td','Không tìm thấy sự kiện phù hợp.');cell.colSpan=6;tr.append(cell);tbody.append(tr);}
    const start=n.length? page*limit+1:0, end=page*limit+n.length;
    byId('results-label').textContent=`${fmtNum(total)} sự kiện phù hợp · sắp xếp mới nhất trước`;
    byId('page-label').textContent=`Hiển thị ${fmtNum(start)}–${fmtNum(end)} / ${fmtNum(total)} · Trang ${page+1}`;
    byId('prev-btn').disabled=page===0;
    byId('next-btn').disabled=!cursor;
    nextCursor=cursor;
  }
  function showDetail(row){
    byId('detail-title').textContent=row.action||'Chi tiết sự kiện';
    byId('detail-meta').textContent=`${dateTime(row.timestamp||row.created_at)} · ${row.audit_id||''}`;
    byId('detail-json').textContent=JSON.stringify(row,null,2);
    byId('detail-dialog').showModal();
  }
  async function loadPage(index){
    if(index<0 || index>=cursorPages.length) return;
    const req=++requestID;page=index;
    byId('search-btn').disabled=true;byId('reload-btn').disabled=true;
    setStatus('Đang đọc nhật ký hệ thống…');
    try{
      const params=new URLSearchParams(filters);
      if(cursorPages[index])params.set('cursor',cursorPages[index]);
      const data=await STAuth.api('/v1/staff/audit-logs?'+params.toString());
      if(req!==requestID)return;
      drawOverview(data.summary||{});
      drawTable(data.items,data.total,PAGESIZE,data.next_cursor);
      setStatus('Đã tải nhật ký. Mốc truy vấn: '+dateTime(data.read_at)+'.');
    }catch(e){
      if(req===requestID)setStatus('Không thể tải nhật ký: '+e.message,true);
    }finally{
      if(req===requestID){byId('search-btn').disabled=false;byId('reload-btn').disabled=false;}
    }
  }
  function search(){
    try{filters=buildFilters();}catch(e){setStatus(e.message,true);return;}
    cursorPages=[null];page=0;nextCursor=null;loadPage(0);
  }
  byId('actor-label').textContent='Tài khoản ADMIN: '+(session.claims.email||session.claims.sub||'đã xác thực');
  byId('logout-btn').addEventListener('click',STAuth.logout);
  byId('close-dialog').addEventListener('click',()=>byId('detail-dialog').close());
  byId('audit-form').addEventListener('submit',e=>{e.preventDefault();search();});
  byId('reset-btn').addEventListener('click',()=>{
    const now=localDay();byId('to-date').value=now;byId('from-date').value=dateShift(now,-6);
    byId('actor-filter').value='';byId('action-filter').value='';byId('resource-filter').value='';search();
  });
  byId('reload-btn').addEventListener('click',search);
  byId('prev-btn').addEventListener('click',()=>loadPage(page-1));
  byId('next-btn').addEventListener('click',()=>{
    if(!nextCursor)return;
    cursorPages[page+1]=nextCursor;
    loadPage(page+1);
  });
  const now=localDay();byId('to-date').value=now;byId('from-date').value=dateShift(now,-6);search();
})();
