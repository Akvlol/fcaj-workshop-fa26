/* Frontend OAuth2 Authorization Code + PKCE for Amazon Cognito managed login.
   Role checks here only select UI. Real authorization MUST happen in API Gateway + Lambda. */
(() => {
  'use strict';
  const conf = window.SECURETABLE_CONFIG || {};
  const AUTH_KEY = 'securetable_auth_v1';
  const PENDING_KEY = 'securetable_pkce_v1';
  const ROLE_PATHS = { ADMIN: '/finance.html', RECEPTION: '/reception.html', KITCHEN: '/kitchen.html', INVENTORY: '/inventory.html' };
  const ROLE_ORDER = ['ADMIN', 'RECEPTION', 'KITCHEN', 'INVENTORY'];

  const callbackUri = () => location.origin + '/callback.html';
  const loggedOutUri = () => location.origin + '/login.html';
  function domain() { return String(conf.cognitoDomain || '').replace(/\/$/, ''); }
  function isConfigured() {
    return /^https:\/\/[a-z0-9.-]+$/i.test(domain()) &&
      !domain().includes('YOUR_PREFIX') && !!conf.clientId &&
      !conf.clientId.includes('YOUR_') && !!conf.userPoolId &&
      !conf.userPoolId.includes('YOUR_');
  }
  function base64url(bytes) {
    let binary = ''; for (const b of bytes) binary += String.fromCharCode(b);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function randString() { const bytes = new Uint8Array(32); crypto.getRandomValues(bytes); return base64url(bytes); }
  async function pkceChallenge(verifier) {
    const input = new TextEncoder().encode(verifier);
    return base64url(new Uint8Array(await crypto.subtle.digest('SHA-256', input)));
  }
  async function login() {
    if (!isConfigured()) throw new Error('Chưa cấu hình Cognito. Cập nhật config.js trước khi đăng nhập.');
    const verifier = randString() + randString();
    const state = randString();
    sessionStorage.setItem(PENDING_KEY, JSON.stringify({ verifier, state, created: Date.now() }));
    const url = new URL(domain() + '/oauth2/authorize');
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('client_id', conf.clientId);
    url.searchParams.set('redirect_uri', callbackUri());
    url.searchParams.set('scope', 'openid email profile');
    url.searchParams.set('code_challenge_method', 'S256');
    url.searchParams.set('code_challenge', await pkceChallenge(verifier));
    url.searchParams.set('state', state);
    location.assign(url.toString());
  }
  function decodeJwtPayload(token) {
    const parts = String(token || '').split('.');
    if (parts.length !== 3) throw new Error('Token không hợp lệ.');
    const s = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(s + '='.repeat((4 - s.length % 4) % 4)));
  }
  function validClaims(claims) {
    if (!claims || typeof claims !== 'object') return false;
    const expectedIssuer = 'https://cognito-idp.ap-southeast-1.amazonaws.com/' + conf.userPoolId;
    return claims.token_use === 'id' && claims.aud === conf.clientId &&
      claims.iss === expectedIssuer && Number(claims.exp) * 1000 > Date.now() + 10000;
  }
  function currentSession() {
    if (!isConfigured()) return null;
    try {
      const data = JSON.parse(sessionStorage.getItem(AUTH_KEY) || 'null');
      if (!data || !data.id_token) return null;
      const claims = decodeJwtPayload(data.id_token);
      if (!validClaims(claims)) return null;
      return { token: data.id_token, claims };
    } catch (_) { return null; }
  }
  function groupsFrom(claims) {
    const groups = claims?.['cognito:groups'];
    return Array.isArray(groups) ? groups.filter(x => typeof x === 'string') : [];
  }
  function primaryRole(claims) { return ROLE_ORDER.find(role => groupsFrom(claims).includes(role)) || null; }
  function rolePath(claims) { return ROLE_PATHS[primaryRole(claims)] || null; }
  async function finishCallback() {
    const params = new URLSearchParams(location.search);
    const code = params.get('code');
    const state = params.get('state');
    const error = params.get('error');
    // Remove OAuth code from address bar before using it.
    history.replaceState(null, '', '/callback.html');
    if (error) throw new Error('Cognito từ chối đăng nhập: ' + error);
    if (!code || !state) throw new Error('Không tìm thấy OAuth authorization code/state.');
    const pendingText = sessionStorage.getItem(PENDING_KEY);
    sessionStorage.removeItem(PENDING_KEY);
    if (!pendingText) throw new Error('Không tìm thấy PKCE. Hãy đăng nhập lại cùng tab trình duyệt.');
    const pending = JSON.parse(pendingText);
    if (pending.state !== state || Date.now() - pending.created > 600000)
      throw new Error('OAuth state không hợp lệ hoặc yêu cầu đã hết hạn.');
    const form = new URLSearchParams({
      grant_type: 'authorization_code', client_id: conf.clientId,
      code, redirect_uri: callbackUri(), code_verifier: pending.verifier
    });
    const res = await fetch(domain() + '/oauth2/token', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString(), cache: 'no-store'
    });
    const data = await res.json();
    if (!res.ok || !data.id_token) throw new Error('Không đổi được authorization code lấy ID token. Kiểm tra Cognito App Client và callback URL.');
    const claims = decodeJwtPayload(data.id_token);
    if (!validClaims(claims)) throw new Error('ID token không khớp Cognito App Client/User Pool hoặc hết hạn.');
    // Keep tokens in sessionStorage for this tab only; no refresh tokens persisted.
    sessionStorage.setItem(AUTH_KEY, JSON.stringify({ id_token: data.id_token }));
    const path = rolePath(claims);
    if (!path) {
      sessionStorage.removeItem(AUTH_KEY);
      throw new Error('Tài khoản chưa thuộc ADMIN, RECEPTION, KITCHEN hoặc INVENTORY. Hãy kiểm tra Cognito Groups.');
    }
    location.replace(path);
  }
  function requireRole(role) {
    const session = currentSession();
    if (!session) { location.replace('/login.html'); return null; }
    if (!groupsFrom(session.claims).includes(role)) {
      location.replace(rolePath(session.claims) || '/login.html');
      return null;
    }
    return session;
  }
  async function api(path, opts = {}) {
    const session = currentSession();
    if (!session) throw new Error('Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại.');
    if (!path.startsWith('/v1/staff/')) throw new Error('Đường dẫn API không hợp lệ.');
    const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}), Authorization: 'Bearer ' + session.token };
    const res = await fetch(path, { ...opts, headers, cache: 'no-store' });
    let body = {};
    try { body = await res.json(); } catch (_) { }
    if (!res.ok) {
      const msg = body?.error?.message || body?.error?.code || body?.error || body?.message || ('HTTP ' + res.status);
      const err = new Error(typeof msg === 'string' ? msg : 'HTTP ' + res.status);
      err.status = res.status;
      throw err;
    }
    return body;
  }
  function logout() {
    sessionStorage.removeItem(AUTH_KEY);
    sessionStorage.removeItem(PENDING_KEY);
    if (!isConfigured()) { location.replace('/login.html'); return; }
    const url = new URL(domain() + '/logout');
    url.searchParams.set('client_id', conf.clientId);
    url.searchParams.set('logout_uri', loggedOutUri());
    location.assign(url.toString());
  }
  window.STAuth = Object.freeze({ login, finishCallback, currentSession, primaryRole, rolePath, requireRole, api, logout, isConfigured });
})();
