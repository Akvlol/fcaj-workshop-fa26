document.addEventListener('DOMContentLoaded', async () => {
  const info = document.getElementById('auth-message');
  try { await STAuth.finishCallback(); }
  catch (e) { info.className = 'status err'; info.textContent = e.message; }
});
