window.SECURETABLE_CONFIG = Object.freeze({
  cognitoDomain: 'https://ap-southeast-17uhnri2k7.auth.ap-southeast-1.amazoncognito.com',
  clientId: '1197c8vmhehijuc5ak2utjdng9',
  userPoolId: 'ap-southeast-1_7uhNrI2k7'
});
