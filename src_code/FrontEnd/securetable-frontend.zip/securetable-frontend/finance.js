document.addEventListener('DOMContentLoaded', () => {
  'use strict';
  const session = STAuth.requireRole('ADMIN');
  if (!session) return;
  const el = id => document.getElementById(id);
  const vnd = n => Number(n || 0).toLocaleString('vi-VN', {maximumFractionDigits:0}) + ' đ';
  const day = iso => iso.slice(8, 10) + '/' + iso.slice(5, 7);
  const todayLocal = () => new Intl.DateTimeFormat('en-CA', {
    timeZone:'Asia/Ho_Chi_Minh', year:'numeric', month:'2-digit', day:'2-digit'
  }).format(new Date());
  // date-only arithmetic in UTC avoids DST/timezone drift.
  const shift = (iso, delta) => {
    const [y,m,d] = iso.split('-').map(Number);
    const x = new Date(Date.UTC(y, m - 1, d + delta));
    return x.toISOString().slice(0,10);
  };
  const oneDayAgo = (date, n) => shift(date, -n);
  let latestRequest = 0;
  const setStatus = (msg, error = false) => {
    el('status').className = error ? 'status err' : 'status';
    el('status').textContent = msg;
  };
  const textNode = (tag, value, cls = '') => {
    const n = document.createElement(tag); n.textContent = String(value);
    if (cls) n.className = cls; return n;
  };
  function cell(label, value, hint) {
    const box = textNode('div', '', 'card');
    box.append(textNode('div', label, 'kpi-title'));
    box.append(textNode('div', vnd(value), 'kpi-value'));
    if (hint) box.append(textNode('div', hint, 'kpi-footnote'));
    return box;
  }
  function redraw(data, rows, stock) {
    const kpis = el('kpis'); kpis.replaceChildren();
    const items = [
      ['Doanh thu thực thu',data.collected_revenue_vnd,'Bill PAID'],
      ['Chi phí mua nguyên liệu',data.purchase_spend_vnd,'Đã tính các lần điều chỉnh'],
      ['Giá vốn tiêu hao',data.material_consumption_cost_vnd,'Ước tính theo lúc Complete'],
      ['Thất thoát nguyên liệu',data.inventory_loss_cost_vnd,'Báo hết + kiểm kê thiếu'],
      ['Khoản chưa thu',data.unpaid_bill_value_vnd,'Bill UNPAID, không tính vào thực thu'],
      ['Chênh lệch thu − chi mua',data.cash_difference_vnd,'Không phải lợi nhuận ròng'],
      ['Lợi nhuận gộp ước tính',data.estimated_gross_profit_vnd,'Thực thu − giá vốn tiêu hao'],
      ['Ước tính sau thất thoát',data.estimated_after_loss_vnd,'Chưa trừ chi phí vận hành'],
    ];
    for (const [label, value, hint] of items) kpis.append(cell(label,value,hint));
    const billCounts = el('bill-counts'); billCounts.replaceChildren();
    for (const [key,label] of [['paid','PAID'],['unpaid','UNPAID'],['empty','EMPTY']]) {
      const b = textNode('div', '', 'bill-count');
      b.append(textNode('strong', data.bills?.[key] || 0));
      b.append(textNode('span', label)); billCounts.append(b);
    }
    const chart = el('chart'); chart.replaceChildren();
    const max = Math.max(1, ...rows.flatMap(r => [Math.abs(Number(r.collected_revenue_vnd||0)), Math.abs(Number(r.purchase_spend_vnd||0))]));
    for (const r of rows) {
      const grp = textNode('div', '', 'chart-day');
      const bars = textNode('div', '', 'chart-bars');
      for (const [prop, cls] of [['collected_revenue_vnd','bar-revenue'],['purchase_spend_vnd','bar-expense']]) {
        const n = Number(r[prop] || 0);
        const b = textNode('div', '', 'chart-bar ' + cls);
        b.style.height = (Math.max(2, Math.abs(n) / max * 190)) + 'px';
        b.title = day(r.date) + ': ' + vnd(n) + (n<0 ? ' (âm)' : '');
        b.setAttribute('aria-label', b.title);
        bars.append(b);
      }
      grp.append(bars, textNode('span', day(r.date), 'chart-label')); chart.append(grp);
    }
    const tbody = el('daily-rows'); tbody.replaceChildren();
    for (const r of rows) {
      const tr = document.createElement('tr');
      const vals = [r.date, vnd(r.collected_revenue_vnd), vnd(r.purchase_spend_vnd),
        vnd(r.material_consumption_cost_vnd), vnd(r.inventory_loss_cost_vnd), vnd(r.unpaid_bill_value_vnd)];
      for(const val of vals) tr.append(textNode('td', val));
      tbody.append(tr);
    }
    if (!rows.length) {
      const tr = document.createElement('tr'), td = textNode('td', 'Không có dữ liệu'); td.colSpan=6; tr.append(td); tbody.append(tr);
    }
    const notes = el('finance-notes'); notes.replaceChildren();
    const notesText = [
      'Doanh thu chỉ gồm Bill đã đóng và PAID.',
      'Chi nhập kho khác giá vốn nguyên liệu tiêu hao.',
      'Thất thoát kiểm kê chỉ được tính một lần.',
      'Số liệu là ước tính; chưa bao gồm lương, điện nước và thuê mặt bằng.',
      'Dữ liệu quét trực tiếp; khi có giao dịch đồng thời, hãy tải lại để đối soát.'
    ];
    for(const s of notesText) notes.append(textNode('p', s));
    el('stock-section').hidden = !Array.isArray(stock);
    const stocks = el('stock-rows'); stocks.replaceChildren();
    for(const ing of (stock || [])) {
      const tr = document.createElement('tr');
      const vals = [ing.name + ' (' + ing.ingredient_id + ')',
        Number(ing.qty_base || 0).toLocaleString('vi-VN') + ' ' + ing.unit,
        Number(ing.reserved || 0).toLocaleString('vi-VN') + ' ' + ing.unit,
        ing.last_counted_at ? new Date(ing.last_counted_at).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}) : 'Chưa kiểm kê'];
      for(const val of vals) tr.append(textNode('td',val)); stocks.append(tr);
    }
  }
  async function load(mode, start, end) {
    const req = ++latestRequest;
    el('from-date').value = start; el('to-date').value = end;
    el('period-label').textContent = 'Báo cáo: ' + start + ' → ' + end + ' · Múi giờ Asia/Ho_Chi_Minh';
    setStatus('Đang tải báo cáo…');
    const btn = el('filter-btn'); btn.disabled = true;
    try {
      let data;
      if(mode==='day') data = await STAuth.api('/v1/staff/finance/daily/' + start);
      else if(mode==='week') data = await STAuth.api('/v1/staff/finance/weekly?week_start=' + start);
      else data = await STAuth.api('/v1/staff/finance/summary?from=' + start + '&to=' + end);
      if(req!==latestRequest) return;
      const rows = Array.isArray(data.days) ? data.days : [data];
      redraw(data, rows, mode==='day' ? data.stock : null);
      setStatus('Đã tải báo cáo. Lần cập nhật: ' + new Date().toLocaleTimeString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}) + ' (giờ Việt Nam).');
    } catch(e) {
      if(req===latestRequest) setStatus('Không tải được báo cáo: ' + e.message, true);
    } finally { if(req===latestRequest) btn.disabled = false; }
  }
  el('user-label').textContent = 'Đăng nhập: ' + (session.claims.email || 'ADMIN');
  document.querySelector('.logout').addEventListener('click', STAuth.logout);
  el('today-btn').addEventListener('click', () => {const now=todayLocal(); load('day',now,now);});
  el('last7-btn').addEventListener('click', () => {const now=todayLocal();load('range',oneDayAgo(now,6),now);});
  el('week-btn').addEventListener('click', () => {
    const now = todayLocal();
    const n = new Date(now + 'T12:00:00Z').getUTCDay();
    const start = oneDayAgo(now,(n+6)%7);
    load('week',start,shift(start,6));
  });
  el('range-form').addEventListener('submit', ev => {
    ev.preventDefault();
    const from=el('from-date').value, to=el('to-date').value;
    const span=Math.round((Date.parse(to+'T00:00:00Z')-Date.parse(from+'T00:00:00Z'))/86400000);
    if(!from || !to || span<0 || span>30) {setStatus('Chọn khoảng từ 1 đến 31 ngày.',true); return;}
    load('range',from,to);
  });
  const now=todayLocal(); load('range',oneDayAgo(now,6),now);
});
