document.addEventListener('DOMContentLoaded', () => {
  'use strict';
  const session = window.STAuth?.requireRole('INVENTORY');
  if (!session) return;
  document.querySelector('.logout').addEventListener('click', STAuth.logout);
  document.getElementById('hello').textContent = 'Đăng nhập: ' + (session.claims.email || session.claims['cognito:username'] || 'Inventory');

  const el = id => document.getElementById(id);
  const money = val => new Intl.NumberFormat('vi-VN', {style:'currency',currency:'VND',maximumFractionDigits:0}).format(val);
  const quantity = n => Number(n).toLocaleString('vi-VN', {maximumFractionDigits:3});
  const item = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const status = (message, kind='ok') => {
    el('inv-status').className = kind === 'err' ? 'status err' : kind === 'warn' ? 'status warn' : 'status';
    el('inv-status').textContent = message;
  };
  let inventory = [];
  let cursorIngredients = null;
  let cursorReceipts = null;
  let pendingKey = null;
  let processing = false;
  let lines = [];
  let selectedReceipt = null;
  let correctionInputs = [];
  let correctionKey = null;
  let correctionBusy = false;

  function setBusy(busy) {
    processing = busy;
    el('confirm-receipt').disabled = busy;
    el('add-line').disabled = busy;
    for (const input of el('receipt-form').querySelectorAll('input,select,button')) input.disabled = busy;
  }
  function refreshOptions() {
    for (const line of lines) {
      const selectedId = line.select.value;
      line.select.replaceChildren();
      line.select.append(item('option', '', 'Chọn nguyên liệu'));
      line.select.firstElementChild.value = '';
      for (const ing of inventory) {
        const option = item('option', '', `${ing.name} (${ing.ingredient_id})`);
        option.value = ing.ingredient_id;
        if (ing.stockout_cascade_state === 'PENDING') option.disabled = true;
        line.select.append(option);
      }
      if (inventory.some(i => i.ingredient_id === selectedId)) line.select.value = selectedId;
      updateUnit(line);
    }
  }
  function updateUnit(line) {
    const ing = inventory.find(i => i.ingredient_id === line.select.value);
    line.qtyLabel.textContent = `Số lượng${ing ? ' (' + ing.base_unit + ')' : ''}`;
  }
  function recalculation() {
    pendingKey = null;
    let total = 0;
    for (const line of lines) {
      const q = Number(line.qty.value);
      const p = Number(line.price.value);
      if (Number.isFinite(q) && q > 0 && Number.isSafeInteger(p) && p >= 0) total += Math.round(q * p);
    }
    el('total-cost').textContent = money(total);
    el('stockout-warning').hidden = !lines.some(l => inventory.some(i => i.ingredient_id === l.select.value && i.stockout_cascade_state === 'PENDING'));
  }
  function removeLine(line) {
    if (processing) return;
    lines = lines.filter(x => x !== line);
    line.node.remove();
    if (!lines.length) addLine();
    recalculation();
  }
  function addLine() {
    if (lines.length >= 10 || processing) return;
    const node = item('div', 'inv-line');
    const ingField = item('div', 'inv-field');
    const ingLabel = item('label', '', 'Nguyên liệu');
    const select = item('select');
    select.required = true;
    select.id = 'receipt-ingredient-' + (crypto.randomUUID ? crypto.randomUUID() : Date.now());
    ingLabel.htmlFor = select.id;
    ingField.append(ingLabel, select);

    const qtyField = item('div', 'inv-field');
    const qtyLabel = item('label', '', 'Số lượng');
    const qty = item('input');
    qty.type = 'number'; qty.step = '0.001'; qty.min = '0.001'; qty.max = '100000'; qty.required = true;
    qty.inputMode = 'decimal';
    qty.placeholder = 'Ví dụ: 3.5';
    qty.id = 'receipt-qty-' + (crypto.randomUUID ? crypto.randomUUID() : Date.now());
    qtyLabel.htmlFor = qty.id;
    qtyField.append(qtyLabel, qty);

    const priceField = item('div', 'inv-field');
    const priceLabel = item('label', '', 'Đơn giá (VND)');
    const price = item('input');
    price.type = 'number'; price.step = '1000'; price.min = '0'; price.max = '1000000000'; price.required = true;
    price.inputMode = 'numeric';
    price.placeholder = 'Ví dụ: 200000';
    price.title = 'Mũi tên tăng/giảm 1.000 VND; vẫn có thể nhập số nguyên VND bất kỳ';
    price.id = 'receipt-price-' + (crypto.randomUUID ? crypto.randomUUID() : Date.now());
    priceLabel.htmlFor = price.id;
    priceField.append(priceLabel, price);

    const remove = item('button', 'ghost', 'Xóa');
    remove.type = 'button';
    node.append(ingField, qtyField, priceField, remove);
    const line = {node, select, qtyLabel, qty, price};
    lines.push(line);
    select.addEventListener('change', () => {updateUnit(line); recalculation();});
    qty.addEventListener('input', recalculation);
    price.addEventListener('input', recalculation);
    remove.addEventListener('click', () => removeLine(line));
    el('receipt-lines').append(node);
    refreshOptions();
    recalculation();
  }

  function renderIngredients() {
    const tbody = el('ingredient-list');
    tbody.replaceChildren();
    const data = [...inventory].sort((a,b) => a.name.localeCompare(b.name, 'vi'));
    if (!data.length) {
      const tr=item('tr'); const td=item('td','', 'Chưa có nguyên liệu.'); td.colSpan=6; tr.append(td); tbody.append(tr); return;
    }
    for (const ing of data) {
      const tr = item('tr');
      const name = item('td');
      name.append(item('strong','',ing.name),item('div','small',ing.ingredient_id));
      const cell = item('td');
      const state = ing.stock_status || 'UNKNOWN';
      const tag = item('span', 'inv-tag' + (state==='OUT_OF_STOCK' ? ' err' : state==='LOW' ? ' warn' : ''), state);
      cell.append(tag);
      if (ing.stockout_cascade_state === 'PENDING') cell.append(item('div','small','Đang xử lý stock-out'));
      tr.append(name,cell,
        item('td','inv-numbers',`${quantity(ing.stock_book)} ${ing.base_unit}`),
        item('td','inv-numbers',`${quantity(ing.reserved)} ${ing.base_unit}`),
        item('td','inv-numbers',`${quantity(ing.available)} ${ing.base_unit}`),
        item('td','inv-numbers',money(ing.last_unit_cost_vnd) + '/' + ing.base_unit));
      tbody.append(tr);
    }
  }

  async function loadIngredients(append=false) {
    try {
      const query = '/v1/staff/ingredients?limit=100' + (append && cursorIngredients ? '&cursor=' + encodeURIComponent(cursorIngredients) : '');
      const result = await STAuth.api(query);
      if (!append) inventory = [];
      for (const ing of Array.isArray(result.items) ? result.items : []) {
        const idx = inventory.findIndex(x => x.ingredient_id === ing.ingredient_id);
        if (idx >= 0) inventory[idx] = ing; else inventory.push(ing);
      }
      cursorIngredients = result.next_cursor || null;
      el('more-ingredients').hidden = !cursorIngredients;
      renderIngredients();
      refreshOptions();
      status('Đã tải ' + inventory.length + ' nguyên liệu từ DynamoDB.');
    } catch (err) { status('Không thể tải nguyên liệu: ' + err.message, 'err'); }
  }

  function renderReceipts(receipts) {
    const root = el('receipt-list');
    root.replaceChildren();
    if (!receipts.length) { root.append(item('div','empty','Chưa có phiếu nhập nào.')); return; }
    receipts.sort((a,b) => b.confirmed_at.localeCompare(a.confirmed_at));
    for (const r of receipts) {
      const row = item('div','inv-receipt');
      const head = item('div','inv-receipt-header');
      head.append(item('strong','',r.receipt_id),item('strong','',money(r.total_purchase_vnd)));
      if (latestReceiptId && r.receipt_id === latestReceiptId) {
        const correctionButton = item('button', 'ghost', 'Điều chỉnh');
        correctionButton.type = 'button';
        correctionButton.addEventListener('click', () => openCorrection(r));
        head.append(correctionButton);
      } else {
        head.append(item('span','small','Chỉ xem · phiếu cũ'));
      }
      row.append(head,item('div','small',r.supplier_name + ' · ' + new Date(r.confirmed_at).toLocaleString('vi-VN')));
      if (r.note) row.append(item('div','small','Ghi chú: ' + r.note));
      if (r.is_corrected) {
        row.append(item('div', 'small', `Đã điều chỉnh ${r.correction_count} lần · Tổng gốc: ${money(r.original_total_purchase_vnd)} · Tổng hiện tại: ${money(r.total_purchase_vnd)}`));
      }
      const summary = (r.items || []).map(x => {
        const original = x.original_qty !== undefined && Number(x.original_qty) !== Number(x.qty)
          ? ` (gốc: ${quantity(x.original_qty)} ${x.unit})` : '';
        return `${x.ingredient_id} ${quantity(x.qty)} ${x.unit}${original}`;
      }).join(' · ');
      row.append(item('div','small',summary));
      root.append(row);
    }
  }
  let latestReceiptId = null;
  let receipts = [];
  async function loadReceipts(append=false) {
    try {
      const path = '/v1/staff/inventory/receipts?limit=30' + (append && cursorReceipts ? '&cursor=' + encodeURIComponent(cursorReceipts) : '');
      const result = await STAuth.api(path);
      latestReceiptId = result.latest_receipt_id || null;
      if (!append) receipts = [];
      if (selectedReceipt && selectedReceipt.receipt_id !== latestReceiptId) {
        selectedReceipt = null;
        correctionKey = null;
        el('correction-section').hidden = true;
        status('Đã có phiếu nhập mới. Phiếu điều chỉnh trước đó đã bị khóa.', 'warn');
      }
      for (const rec of result.items || []) {
        const idx = receipts.findIndex(x => x.receipt_id === rec.receipt_id);
        if (idx >= 0) receipts[idx]=rec; else receipts.push(rec);
      }
      cursorReceipts = result.next_cursor || null;
      el('more-receipts').hidden = !cursorReceipts;
      renderReceipts(receipts);
    } catch (err) { status('Không thể tải phiếu nhập: ' + err.message, 'err'); }
  }

  async function submitReceipt(event) {
    event.preventDefault();
    if (processing) return;
    const supplier_name = el('supplier').value.trim();
    const note = el('receipt-note').value.trim();
    const payloadItems = [];
    const used = new Set();
    for (const line of lines) {
      const id = line.select.value;
      const ing = inventory.find(x => x.ingredient_id === id);
      const qty = Number(line.qty.value);
      const price = Number(line.price.value);
      if (!ing || used.has(id)) { status('Hãy chọn các nguyên liệu khác nhau cho mỗi dòng.', 'err'); return; }
      if (ing.stockout_cascade_state === 'PENDING') { status('Chưa thể nhập nguyên liệu đang xử lý hết hàng.', 'warn'); return; }
      if (line.qty.value.trim() === '' || line.price.value.trim() === '' || !Number.isFinite(qty) || qty < 0.001 || qty > 100000 || Math.abs(Math.round(qty * 1000) - qty * 1000) > 1e-7 || !Number.isSafeInteger(price) || price < 0 || price > 1000000000) {
        status('Số lượng tối đa 3 chữ số thập phân và giá nhập phải là số nguyên VND.', 'err'); return;
      }
      used.add(id);
      payloadItems.push({ingredient_id:id, unit:ing.base_unit, qty, unit_price_vnd:price});
    }
    if (!supplier_name) { status('Vui lòng nhập tên nhà cung cấp.', 'err'); el('supplier').focus(); return; }
    if (!payloadItems.length) { status('Vui lòng thêm ít nhất một nguyên liệu.', 'err'); return; }
    const total = payloadItems.reduce((s,x) => s + Math.round(x.qty*x.unit_price_vnd),0);
    if (!window.confirm(`Xác nhận nhập ${payloadItems.length} nguyên liệu từ ${supplier_name}, chi phí ${money(total)}? Dữ liệu sẽ ghi vào tồn kho và sổ chi phí.`)) return;
    if (!pendingKey) pendingKey = 'INV-' + crypto.randomUUID();
    setBusy(true);
    let succeeded = false;
    status('Đang ghi phiếu nhập và cập nhật kho...');
    try {
      const result = await STAuth.api('/v1/staff/inventory/receipts', {
        method:'POST',
        headers:{'Idempotency-Key':pendingKey},
        body: JSON.stringify({supplier_name, note, items: payloadItems})
      });
      pendingKey = null;
      el('receipt-form').reset();
      el('receipt-lines').replaceChildren();
      lines = [];
      await Promise.all([loadIngredients(),loadReceipts()]);
      succeeded = true;
      status('Đã xác nhận phiếu ' + result.receipt_id + '. Tổng chi: ' + money(result.total_purchase_vnd) + '. Thông báo SNS chưa được gửi (outbox PENDING).');
    } catch (err) {
      status('Lưu phiếu thất bại: ' + err.message + '. Nếu mất kết nối, thử gửi lại mà không sửa nội dung để giữ Idempotency-Key.', 'err');
    } finally { setBusy(false); if (succeeded) addLine(); }
  }

  function openCorrection(receipt) {
    if (!latestReceiptId || receipt.receipt_id !== latestReceiptId) {
      status('Chỉ được điều chỉnh phiếu nhập mới nhất. Hãy tải lại danh sách phiếu.', 'warn');
      return;
    }
    selectedReceipt = receipt;
    correctionKey = null;
    el('correction-section').hidden = false;
    el('correction-context').textContent = `Phiếu ${receipt.receipt_id} · ${receipt.supplier_name} · Tổng hiện tại: ${money(receipt.total_purchase_vnd)} · Tổng gốc: ${money(receipt.original_total_purchase_vnd ?? receipt.total_purchase_vnd)}`;
    el('correction-reason').value = '';
    const root = el('correction-lines');
    root.replaceChildren();
    correctionInputs = [];
    for (const line of receipt.items || []) {
      const container = item('div','correction-line');
      const description = item('div');
      const ing = inventory.find(x => x.ingredient_id === line.ingredient_id);
      description.append(item('strong','', ing?.name || line.ingredient_id));
      description.append(item('p','', `Hiện tại: ${quantity(line.qty)} ${line.unit} · thành tiền ${money(line.line_total_vnd)} (đơn giá ban đầu: ${money(line.unit_price_vnd)}/${line.unit})`));
      const qtyLabel = item('label','',`Chênh lệch số lượng (${line.unit})`);
      const qty = item('input');
      qty.type='number'; qty.step='0.001'; qty.min='-100000';qty.max='100000';qty.value='0';qty.inputMode='decimal';
      qtyLabel.append(qty);
      const amountLabel = item('label','','Chênh lệch tiền nhập (VND)');
      const amount = item('input');
      amount.type='number'; amount.step='1000'; amount.min='-1000000000'; amount.max='1000000000'; amount.value='0'; amount.inputMode='numeric';
      amountLabel.append(amount);
      const record = {line, qty, amount, amountCustomized:false};
      qty.addEventListener('input', () => {
        correctionKey=null;
        if (!record.amountCustomized && qty.value.trim()) {
          const n=Number(qty.value);
          if (Number.isFinite(n)) amount.value=String(Math.round(n*Number(line.unit_price_vnd)));
        }
      });
      amount.addEventListener('input', () => { record.amountCustomized=true; correctionKey=null; });
      container.append(description,qtyLabel,amountLabel);
      root.append(container);
      correctionInputs.push(record);
    }
    void loadCorrections(receipt.receipt_id);
    el('correction-section').scrollIntoView({behavior:'smooth',block:'start'});
  }

  async function loadCorrections(receiptId) {
    const root=el('correction-history');
    root.hidden=false;
    root.replaceChildren(item('strong','', 'Lịch sử điều chỉnh'));
    try {
      const out=await STAuth.api('/v1/staff/inventory/receipts/' + encodeURIComponent(receiptId) + '/corrections?limit=30');
      if (selectedReceipt?.receipt_id !== receiptId) return;
      root.append(item('p','small', 'Tổng gốc: ' + money(out.original_total_vnd) + ' · Tổng sau điều chỉnh: ' + money(out.corrected_total_vnd)));
      if (!out.items?.length) {
        root.append(item('p','small','Phiếu này chưa có điều chỉnh.'));
        return;
      }
      for (const rec of out.items) {
        const description = `${new Date(rec.created_at).toLocaleString('vi-VN')} · ${rec.reason} · ${money(rec.amount_delta_vnd)}`;
        root.append(item('div','', description));
      }
    } catch (err) { root.append(item('p','small','Chưa tải được lịch sử: ' + err.message)); }
  }

  async function submitCorrection(e) {
    e.preventDefault();
    if (!selectedReceipt || correctionBusy) return;
    if (!latestReceiptId || selectedReceipt.receipt_id !== latestReceiptId) {
      status('Phiếu này không còn là phiếu nhập gần nhất.', 'err');
      await loadReceipts();
      return;
    }
    const reason=el('correction-reason').value.trim();
    if (reason.length < 5) { status('Cần ghi rõ lý do điều chỉnh (ít nhất 5 ký tự).','err');return; }
    const adjustments=[];
    for (const row of correctionInputs) {
      const q=Number(row.qty.value);
      const v=Number(row.amount.value);
      if (!row.qty.value.trim() || !row.amount.value.trim() || !Number.isFinite(q)
          || q < -100000 || q > 100000 || Math.abs(Math.round(q*1000)-q*1000)>1e-7
          || !Number.isSafeInteger(v) || Math.abs(v)>1000000000) {
        status('Số lượng điều chỉnh phải có tối đa 3 số thập phân; tiền phải là số nguyên VND.', 'err');
        return;
      }
      if (q !== 0 || v !== 0) adjustments.push({ingredient_id:row.line.ingredient_id, quantity_delta_base:q, purchase_amount_delta_vnd:v});
    }
    if (!adjustments.length) { status('Chưa có giá trị nào cần điều chỉnh.', 'err');return; }
    const total=adjustments.reduce((acc,x)=>acc+x.purchase_amount_delta_vnd,0);
    if (!window.confirm(`Điều chỉnh phiếu ${selectedReceipt.receipt_id}: ${adjustments.length} dòng, tiền chênh lệch ${money(total)}. Phiếu gốc không bị sửa. Xác nhận?`)) return;
    if (!correctionKey) correctionKey='COR-' + crypto.randomUUID();
    correctionBusy=true;
    el('correction-submit').disabled=true;
    const receiptId=selectedReceipt.receipt_id;
    try {
      const result=await STAuth.api('/v1/staff/inventory/receipts/' + encodeURIComponent(receiptId) + '/corrections',{
        method:'POST',
        headers:{'Idempotency-Key':correctionKey},
        body:JSON.stringify({reason,items:adjustments})
      });
      correctionKey=null;
      await Promise.all([loadIngredients(),loadReceipts()]);
      status('Đã điều chỉnh phiếu ' + result.receipt_id + ': ' + money(result.amount_delta_vnd)
        + '. Giá trị phiếu sau điều chỉnh: ' + money(result.corrected_total_vnd) + '.');
      const fresh=receipts.find(x=>x.receipt_id===receiptId) || selectedReceipt;
      openCorrection(fresh);
    } catch (err) {
      // API enforces the rule atomically, including when another browser
      // confirms a newer receipt after this page was loaded.
      status('Không thể điều chỉnh: ' + err.message + '. Nếu request bị mất kết nối, gửi lại cùng dữ liệu để tránh ghi trùng.', 'err');
      await loadReceipts();
    } finally {
      correctionBusy=false;
      el('correction-submit').disabled=false;
    }
  }
  el('correction-form').addEventListener('submit',submitCorrection);
  el('correction-reason').addEventListener('input',()=>{correctionKey=null;});
  el('correction-cancel').addEventListener('click',()=>{selectedReceipt=null; el('correction-section').hidden=true;});

  el('supplier').addEventListener('input', () => {pendingKey=null;});
  el('receipt-note').addEventListener('input', () => {pendingKey=null;});
  // Native number step=1000 makes arrows useful; custom validation still allows
  // any integer VND typed manually (e.g. 25500), as the API expects.
  el('receipt-form').noValidate = true;
  el('receipt-form').addEventListener('submit', submitReceipt);
  el('add-line').addEventListener('click', addLine);
  el('refresh-inv').addEventListener('click', () => loadIngredients());
  el('refresh-receipts').addEventListener('click', () => loadReceipts());
  el('more-ingredients').addEventListener('click', () => loadIngredients(true));
  el('more-receipts').addEventListener('click', () => loadReceipts(true));
  addLine();
  loadIngredients();
  loadReceipts();

  // Inventory end-of-day count (all ingredients, single atomic batch, max 40).
  let countRows = [];
  let countPreviewData = null;
  let countBody = null;
  let countKey = null;
  let countSaving = false;
  const countStatus = (s, kind='ok') => {
    el('count-status').textContent = s;
    el('count-status').className = kind === 'err' ? 'status err' : kind === 'warn' ? 'status warn' : 'status';
  };
  const staleCountPreview = () => {
    countPreviewData = null;
    countBody = null;
    countKey = null;
    el('count-result').hidden = true;
    el('count-confirm').hidden = true;
  };
  async function loadCountIngredients() {
    el('count-refresh').disabled = true;
    staleCountPreview();
    countStatus('Đang tải toàn bộ nguyên liệu để chuẩn bị kiểm kê...');
    try {
      let cursor = null;
      const ing = [];
      do {
        const url = '/v1/staff/ingredients?limit=100' + (cursor ? '&cursor=' + encodeURIComponent(cursor) : '');
        const data = await STAuth.api(url);
        ing.push(...(data.items || []));
        cursor = data.next_cursor || null;
        if (ing.length > 40) throw new Error('Kho có hơn 40 nguyên liệu, bản kiểm kê một giao dịch chưa hỗ trợ.');
      } while (cursor);
      const root = el('count-input-lines');
      root.replaceChildren();
      countRows = [];
      for (const ingRow of ing.sort((a,b) => a.name.localeCompare(b.name, 'vi'))) {
        const tr = item('tr');
        tr.append(item('td','',`${ingRow.name} (${ingRow.ingredient_id})`),
                  item('td','inv-numbers',`${quantity(ingRow.stock_book)} ${ingRow.base_unit}`));
        const td = item('td');
        const input = item('input','count-actual-input');
        input.type = 'number'; input.min = '0'; input.max = '1000000'; input.step = '0.001';
        input.inputMode = 'decimal'; input.placeholder = 'Nhập số thực tế';
        input.setAttribute('aria-label', `Số lượng thực tế của ${ingRow.name}, ${ingRow.base_unit}`);
        input.required = true;
        input.addEventListener('input', staleCountPreview);
        td.append(input,item('span','small',` ${ingRow.base_unit}`));
        tr.append(td);root.append(tr);
        countRows.push({ingredient:ingRow,input});
      }
      countStatus('Đã tải ' + countRows.length + ' nguyên liệu. Hãy đo thực tế và nhập đủ từng dòng (có thể nhập 0).');
      el('count-preview-button').disabled = countRows.length === 0;
    } catch (err) {
      countStatus('Không thể chuẩn bị kiểm kê: ' + err.message, 'err');
      countRows = [];
      el('count-preview-button').disabled = true;
    } finally { el('count-refresh').disabled = false; }
  }
  async function showCountPreview(event) {
    event.preventDefault();
    if (countSaving) return;
    staleCountPreview();
    const items=[];
    for (const row of countRows) {
      const input = row.input;
      const number = Number(input.value);
      if (input.value.trim()==='' || !Number.isFinite(number) || number<0 || number>1000000 ||
          Math.abs(number*1000-Math.round(number*1000))>1e-7) {
        countStatus(`Vui lòng nhập số thực tế (tối đa 3 số thập phân) cho ${row.ingredient.name}.`, 'err');
        input.focus();return;
      }
      items.push({ingredient_id:row.ingredient.ingredient_id,actual_qty_base:number});
    }
    if (!items.length) {countStatus('Chưa có nguyên liệu để kiểm kê.','err');return;}
    countBody={counted_at:new Date().toISOString(), note:el('count-note').value.trim(), items};
    el('count-preview-button').disabled = true;
    countStatus('Đang tính chênh lệch và kiểm tra các Bill, món chờ...');
    try {
      const preview = await STAuth.api('/v1/staff/inventory/counts/preview', {
        method:'POST', body:JSON.stringify(countBody)
      });
      const result=el('count-result');result.replaceChildren(); result.hidden=false;
      result.append(item('h3','', 'Kết quả kiểm kê (chưa ghi dữ liệu)'));
      const table=item('table','inv-table');const head=item('thead');
      const headRow=item('tr');
      ['Nguyên liệu','Ghi sổ','Thực tế','Chênh lệch','Giá trị thiếu (ước tính)'].forEach(t=>headRow.append(item('th','',t)));
      head.append(headRow);table.append(head);
      const tbody=item('tbody');
      for(const row of preview.items||[]) {
        const tr=item('tr');
        tr.append(item('td','',row.name),item('td','inv-numbers',`${quantity(row.book_qty)} ${row.unit}`),
                  item('td','inv-numbers',`${quantity(row.actual_qty_base)} ${row.unit}`),
                  item('td','inv-numbers',`${row.difference_qty_base>0?'+':''}${quantity(row.difference_qty_base)} ${row.unit}`),
                  item('td','inv-numbers',money(row.loss_value_estimated_vnd)));
        tbody.append(tr);
      }
      table.append(tbody);
      const wrap=item('div','inv-table-wrap');wrap.append(table);result.append(wrap);
      result.append(item('p','',`Thất thoát ước tính: ${money(preview.loss_value_estimated_vnd)} · Giá trị thừa ước tính: ${money(preview.surplus_value_estimated_vnd)} (không tính là doanh thu)`));
      countPreviewData=preview;
      countBody.snapshot_hash=preview.snapshot_hash;
      countKey=null;
      if (preview.count_ready ?? preview.restaurant_ready) {
        countStatus('Đã xem trước. Có thể xác nhận khi không còn Bill hoạt động, món chờ hoặc nguyên liệu đang giữ chỗ.');
        el('count-confirm').hidden=false;
      } else {
        countStatus('Chưa thể xác nhận: '+(preview.blockers||[]).join('; '),'warn');
        result.append(item('p','small','Bạn có thể xem trước nhưng chỉ xác nhận khi đã đóng mọi bill và hoàn tất các món chờ.'));
      }
    } catch(err) {
      countBody=null;
      countStatus('Không thể xem trước kiểm kê: '+err.message,'err');
    } finally {el('count-preview-button').disabled=false;}
  }
  async function confirmStockCount() {
    if (!countPreviewData || !countBody || countSaving || !(countPreviewData.count_ready ?? countPreviewData.restaurant_ready)) return;
    const preview=countPreviewData;
    if (!window.confirm(`Xác nhận kiểm kê ${countBody.items.length} nguyên liệu?\nThất thoát ước tính: ${money(preview.loss_value_estimated_vnd)}\nGiá trị thừa ước tính: ${money(preview.surplus_value_estimated_vnd)}\n\nHệ thống sẽ ghi lại tồn kho và lịch sử. Không thể hoàn tác trực tiếp.`)) return;
    if (!countKey) countKey='COUNT-'+crypto.randomUUID();
    countSaving=true;
    el('count-confirm').disabled=true;
    el('count-preview-button').disabled=true;
    countStatus('Đang ghi kiểm kê, biến động và audit trong một transaction...');
    try {
      const result=await STAuth.api('/v1/staff/inventory/counts',{
        method:'POST', headers:{'Idempotency-Key':countKey},body:JSON.stringify(countBody)
      });
      countStatus(`Đã xác nhận kiểm kê ${result.count_id}. Thiếu ước tính: ${money(result.loss_value_estimated_vnd)}. Giá trị thừa: ${money(result.surplus_value_estimated_vnd)}.`);
      await Promise.all([loadIngredients(),loadCountHistory()]);
      // Clear only after a confirmed success. Never automatically submit a second time.
      countKey=null;
      countBody=null;
      countPreviewData=null;
      el('count-note').value='';
      el('count-result').hidden=true;
      el('count-confirm').hidden=true;
      await loadCountIngredients();
    } catch(err) {
      // Keep key + exact request payload for safe retry following an ambiguous timeout.
      countStatus('Không thể xác nhận kiểm kê: '+err.message+'. Nếu request mất kết nối, giữ nguyên dữ liệu và gửi lại; đừng nhập lại thành một phiếu mới.', 'err');
    } finally {
      countSaving=false;
      el('count-confirm').disabled=false;
      el('count-preview-button').disabled=false;
    }
  }
  async function loadCountHistory() {
    try {
      const result=await STAuth.api('/v1/staff/inventory/counts?limit=20');
      const root=el('count-history');root.replaceChildren();
      if (!result.items?.length) {root.append(item('p','small','Chưa có lịch sử kiểm kê.'));return;}
      for(const rec of result.items) {
        const div=item('div','inv-receipt');
        div.append(item('strong','',rec.count_id),item('div','small',`${new Date(rec.confirmed_at).toLocaleString('vi-VN')} · ${rec.ingredient_count} nguyên liệu`),
                   item('div','small',`Thất thoát ước tính: ${money(rec.loss_value_estimated_vnd)} · Thừa ước tính: ${money(rec.surplus_value_estimated_vnd)}`));
        if(rec.note) div.append(item('div','small','Ghi chú: '+rec.note));
        root.append(div);
      }
    } catch(err) {el('count-history').replaceChildren(item('p','small','Không tải được lịch sử: '+err.message));}
  }
  el('count-form').addEventListener('submit',showCountPreview);
  el('count-note').addEventListener('input',staleCountPreview);
  el('count-refresh').addEventListener('click',loadCountIngredients);
  el('count-confirm').addEventListener('click',confirmStockCount);
  el('count-refresh-history').addEventListener('click',loadCountHistory);
  void loadCountIngredients();
  void loadCountHistory();
});
