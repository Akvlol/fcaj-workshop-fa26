document.addEventListener('DOMContentLoaded', () => {
  'use strict';
  const session = STAuth.requireRole('KITCHEN');
  if (!session) return;
  document.querySelector('.logout').onclick = STAuth.logout;
  document.getElementById('hello').textContent = 'Đăng nhập: ' +
    (session.claims.email || session.claims['cognito:username'] || 'Kitchen');

  const queue = document.getElementById('queue');
  const status = document.getElementById('status');
  const refresh = document.getElementById('refresh-btn');
  let busy = false;

  function elem(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function notice(message, kind = 'ok') {
    status.className = kind === 'error' ? 'status err' : kind === 'warn' ? 'status warn' : 'status';
    status.textContent = message;
  }
  function friendlyTime(timestamp) {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    if (!Number.isFinite(date.getTime())) return '';
    return new Intl.DateTimeFormat('vi-VN', {
      dateStyle: 'short', timeStyle: 'short', timeZone: 'Asia/Ho_Chi_Minh'
    }).format(date);
  }
  function setBusy(active) {
    busy = active;
    refresh.disabled = active;
    for (const button of queue.querySelectorAll('button')) button.disabled = active;
  }
  async function requestAction(item, action, payload) {
    if (busy) return false;
    setBusy(true);
    notice('Đang xử lý phần món ' + item.item_id + '…');
    try {
      const data = await STAuth.api(
        '/v1/staff/kitchen/items/' + encodeURIComponent(item.item_id) + '/' + action,
        { method: 'POST', body: JSON.stringify(payload) }
      );
      if (data.status === 'PROCESSING') {
        const ingredientNames = Array.isArray(data.ingredient_ids) ? data.ingredient_ids.join(', ') : (data.ingredient_id || 'đã chọn');
        notice('Đã ghi nhận hết nguyên liệu: ' + ingredientNames + '. Các món liên quan đang được tự động từ chối. Nhấn Tải lại để kiểm tra.', 'warn');
      } else {
        notice('Đã ' + (action === 'complete' ? 'hoàn thành' : 'từ chối') + ' phần món ' + item.item_id + '.');
      }
      await load(false);
      return true;
    } catch (error) {
      notice('Không thể xử lý: ' + error.message, 'error');
      return false;
    } finally {
      setBusy(false);
    }
  }
  function readChoice(title, value, name, type = 'radio') {
    const label = elem('label', 'kitchen-choice');
    const input = document.createElement('input');
    input.type = type;
    input.name = name;
    input.value = value;
    const labelText = elem('span', '', title);
    label.append(input, labelText);
    return {label, input};
  }
  function renderItem(item) {
    const card = elem('article', 'kitchen-order');
    const top = elem('div', 'kitchen-order-head');
    const details = elem('div', 'kitchen-order-info');
    const tableId = typeof item.table_id === 'string' && item.table_id ? item.table_id : '';
    const tablePill = elem('span', 'kitchen-table', tableId ? ('Bàn ' + tableId) : 'Chưa xác định bàn');
    const name = elem('h3', 'kitchen-dish', item.dish_name || item.dish_id || 'Món chưa có tên');
    details.append(tablePill, name);
    const meta = elem('p', 'kitchen-meta', `Bill ${item.bill_id || '—'} · Mã phần món ${item.item_id || '—'}`);
    details.append(meta);
    const time = friendlyTime(item.created_at);
    if (time) details.append(elem('p', 'kitchen-meta', 'Đặt lúc ' + time));
    if (item.note) details.append(elem('p', 'kitchen-note', 'Ghi chú khách: ' + item.note));
    top.append(details);
    card.append(top);

    const actions = elem('div', 'kitchen-actions');
    const completeBtn = elem('button', '', 'Complete');
    completeBtn.type = 'button';
    completeBtn.addEventListener('click', () => {
      if (busy) return;
      if (!window.confirm('Xác nhận hoàn thành món ' + name.textContent + ' của ' + (tableId || 'bàn chưa xác định') + '?')) return;
      requestAction(item, 'complete', {note: 'Đã chế biến xong'});
    });
    const rejectBtn = elem('button', 'danger', 'Reject');
    rejectBtn.type = 'button';
    rejectBtn.setAttribute('aria-expanded', 'false');
    actions.append(completeBtn, rejectBtn);
    card.append(actions);

    const panel = elem('section', 'kitchen-reject-panel');
    panel.hidden = true;
    const heading = elem('h4', '', 'Lý do từ chối');
    const reasonOptions = elem('div', 'kitchen-reason-options');
    const stockOption = readChoice('Hết nguyên liệu', 'stock', 'reason-' + item.item_id);
    const otherOption = readChoice('Vì lý do khác', 'other', 'reason-' + item.item_id);
    reasonOptions.append(stockOption.label, otherOption.label);
    panel.append(heading, reasonOptions);
    card.append(panel);

    const content = elem('div', 'kitchen-reject-content');
    panel.append(content);
    rejectBtn.addEventListener('click', () => {
      if (busy) return;
      panel.hidden = !panel.hidden;
      rejectBtn.setAttribute('aria-expanded', String(!panel.hidden));
      if (panel.hidden) {
        stockOption.input.checked = false;
        otherOption.input.checked = false;
        content.replaceChildren();
      }
    });
    function makeForm(mode) {
      content.replaceChildren();
      if (mode === 'other') {
        const noteLabel = elem('label', 'kitchen-label', 'Ghi chú bắt buộc (vì sao từ chối?)');
        const textarea = elem('textarea', 'kitchen-textarea');
        textarea.rows = 3;
        textarea.maxLength = 200;
        textarea.placeholder = 'Ví dụ: Máy chế biến bị hỏng, khách yêu cầu đổi món…';
        noteLabel.append(textarea);
        const error = elem('div', 'kitchen-validation');
        const send = elem('button', 'danger', 'Gửi từ chối');
        send.type = 'button';
        send.addEventListener('click', async () => {
          const note = textarea.value.trim();
          if (!note) {
            error.textContent = 'Cần nhập ghi chú trước khi từ chối.';
            textarea.focus();
            return;
          }
          error.textContent = '';
          await requestAction(item, 'reject', { reason: 'OTHER', note });
        });
        content.append(noteLabel, error, send);
      } else if (mode === 'stock') {
        content.append(elem('p', 'kitchen-meta', 'Tick một hoặc nhiều nguyên liệu đã thực sự hết:'));
        const options = Array.isArray(item.ingredient_options) ? item.ingredient_options : [];
        const list = elem('div', 'kitchen-ingredient-list');
        const checks = [];
        for (const ingredient of options) {
          const ingId = ingredient.ingredient_id;
          if (typeof ingId !== 'string' || !ingId) continue;
          const text = (ingredient.name || ingId) + ' (' + ingId + ')';
          const choice = readChoice(text, ingId, 'ingredient-' + item.item_id + '-' + ingId, 'checkbox');
          list.append(choice.label);
          checks.push({input: choice.input, name: ingredient.name || ingId, id: ingId});
        }
        if (!checks.length) content.append(elem('p', 'kitchen-validation', 'Không có dữ liệu nguyên liệu cho món này. Kiểm tra API Kitchen Queue.'));
        else content.append(list);
        const error = elem('div', 'kitchen-validation');
        const firstSend = elem('button', 'danger', 'Gửi');
        firstSend.type = 'button';
        firstSend.disabled = !checks.length;
        const confirmBox = elem('div', 'kitchen-confirm');
        confirmBox.hidden = true;
        const warning = elem('p', 'kitchen-confirm-warning');
        const confirmButtons = elem('div', 'row');
        const back = elem('button', 'ghost', 'Quay lại');
        back.type = 'button';
        const finalSend = elem('button', 'danger', 'Xác nhận và gửi');
        finalSend.type = 'button';
        confirmButtons.append(back, finalSend);
        confirmBox.append(warning, confirmButtons);
        let selected = [];
        const clearConfirmation = () => {
          if (confirmBox.hidden) return;
          confirmBox.hidden = true;
          firstSend.hidden = false;
          selected = [];
        };
        checks.forEach(({input}) => input.addEventListener('change', clearConfirmation));
        firstSend.addEventListener('click', () => {
          selected = checks.filter(x => x.input.checked);
          if (!selected.length) {
            error.textContent = 'Hãy chọn ít nhất một nguyên liệu đã hết.';
            return;
          }
          error.textContent = '';
          const names = selected.map(x => x.name).join(', ');
          warning.textContent = 'XÁC NHẬN LẠI: ' + names + ' thực tế đã hết. Hệ thống sẽ đưa tồn ghi sổ các nguyên liệu này về 0, ghi thất thoát và tự từ chối TẤT CẢ phần món đang chờ có sử dụng chúng. Không thể hoàn tác trực tiếp.';
          confirmBox.hidden = false;
          firstSend.hidden = true;
        });
        back.addEventListener('click', clearConfirmation);
        finalSend.addEventListener('click', async () => {
          if (!selected.length || busy) return;
          const ids = selected.map(x => x.id);
          const names = selected.map(x => x.name).join(', ');
          const ok = await requestAction(item, 'reject', {
            reason: 'OUT_OF_STOCK',
            out_ingredient_ids: ids,
            note: 'Bếp xác nhận nguyên liệu thực tế đã hết: ' + names
          });
          if (!ok) clearConfirmation();
        });
        content.append(error, firstSend, confirmBox);
      }
    }
    stockOption.input.addEventListener('change', () => { if (stockOption.input.checked) makeForm('stock'); });
    otherOption.input.addEventListener('change', () => { if (otherOption.input.checked) makeForm('other'); });
    return card;
  }

  async function load(announce = true) {
    if (announce) notice('Đang tải hàng đợi bếp…');
    refresh.disabled = true;
    try {
      const result = await STAuth.api('/v1/staff/kitchen/queue?limit=30');
      const items = Array.isArray(result.items) ? result.items : [];
      queue.replaceChildren();
      if (items.length === 0) queue.append(elem('div', 'empty', 'Chưa có món nào đang chờ xử lý.'));
      else items.forEach(item => queue.append(renderItem(item)));
      if (announce) notice('Đang hiển thị ' + items.length + ' phần món đang chờ.');
      if (result.next_cursor) status.textContent += ' Vẫn còn món ở trang sau; API có hỗ trợ phân trang.';
    } catch (error) {
      queue.replaceChildren(elem('div', 'empty', 'Không tải được Kitchen Queue.'));
      notice('Lỗi tải đơn hàng: ' + error.message, 'error');
    } finally {
      if (!busy) refresh.disabled = false;
    }
  }
  refresh.addEventListener('click', () => { if (!busy) load(); });
  load();
});
