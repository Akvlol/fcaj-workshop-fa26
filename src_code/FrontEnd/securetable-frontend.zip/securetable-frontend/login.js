document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('login-btn');
  const status = document.getElementById('status');
  if (!STAuth.isConfigured()) {
    btn.disabled = true;
    status.className = 'status warn';
    status.textContent = 'Cần cập nhật 3 giá trị trong config.js (Cognito domain, Client ID, User Pool ID) rồi upload lại S3.';
    return;
  }
  const session = STAuth.currentSession();
  const path = session && STAuth.rolePath(session.claims);
  if (path) { location.replace(path); return; }
  btn.addEventListener('click', async () => {
    btn.disabled = true;
    status.textContent = 'Đang chuyển sang trang đăng nhập Cognito…';
    try { await STAuth.login(); }
    catch (e) { btn.disabled = false; status.className = 'status err'; status.textContent = e.message; }
  });
});
