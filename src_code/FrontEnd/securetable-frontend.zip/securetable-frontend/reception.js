/* Reception enhancement. Depends on the existing /auth.js and /config.js. */
document.addEventListener('DOMContentLoaded', () => {
  'use strict';
  const session = STAuth.requireRole('RECEPTION');
  if (!session) return;
  const $ = id => document.getElementById(id);
  const money = v => Number(v || 0).toLocaleString('vi-VN') + ' đ';
  const statusText = s => ({ OPEN: 'Đang mở', CLOSING: 'Đang đóng', CLOSED: 'Đã đóng', FREE: 'Trống', OCCUPIED: 'Đang sử dụng', PAID: 'Đã thanh toán', UNPAID: 'Chưa thanh toán', EMPTY: 'Bill rỗng' })[s] || s;
  const state = { current: null, pendingConfirm: null, qrUrl: '' };
  const savedKey = id => 'st_reception_close_' + id;

  function message(el, text, kind = '') {
    el.hidden = false;
    el.className = 'status' + (kind ? ' ' + kind : '');
    el.textContent = text;
  }
  function clear(el) { el.replaceChildren(); }
  function node(tag, text, cls) { const n = document.createElement(tag); if (text !== undefined) n.textContent = String(text); if (cls) n.className = cls; return n; }
  function rowValue(label, value) {
    const line = node('div');
    line.append(node('span', label), node('strong', value));
    return line;
  }
  function when(date) { try { return date ? new Date(date).toLocaleString('vi-VN', {timeZone:'Asia/Ho_Chi_Minh'}) : '—'; } catch (_) { return '—'; } }
  function getPending(id) {
    try { return JSON.parse(sessionStorage.getItem(savedKey(id)) || 'null'); } catch (_) { return null; }
  }
  function setPending(id, value) { sessionStorage.setItem(savedKey(id), JSON.stringify(value)); }

  $('hello').textContent = 'Đăng nhập: ' + (session.claims.email || session.claims['cognito:username'] || 'Reception');
  document.querySelector('.logout').addEventListener('click', STAuth.logout);
  $('copy-link').addEventListener('click', async () => {
    if (!state.qrUrl) return;
    try { await navigator.clipboard.writeText(state.qrUrl); $('copy-link').textContent = 'Đã copy'; }
    catch (_) { $('copy-link').textContent = 'Không thể copy'; }
  });

  $('open-form').addEventListener('submit', async event => {
    event.preventDefault();
    const id = $('table-id').value.trim().toUpperCase();
    const count = Number($('guest-count').value);
    if (!/^T[A-Z0-9_-]{1,30}$/.test(id) || !Number.isInteger(count) || count < 1 || count > 50) {
      message($('response'), 'Mã bàn hoặc số khách không hợp lệ.', 'err'); return;
    }
    const btn = $('open-btn'); btn.disabled = true;
    message($('response'), 'Đang mở Bill…');
    try {
      const data = await STAuth.api('/v1/staff/bills', {
        method: 'POST', headers: {'Idempotency-Key': crypto.randomUUID()},
        body: JSON.stringify({table_id:id, guest_count:count})
      });
      message($('response'), 'Đã mở Bill ' + data.bill_id + ' cho bàn ' + id);
      state.qrUrl = location.origin + '/?table=' + encodeURIComponent(id);
      clear($('bill-info'));
      const title = node('strong', 'Bill: ' + data.bill_id);
      const url = node('p', state.qrUrl, 'url');
      const link = node('a', 'Xem trang khách ' + id);
      link.href = state.qrUrl; link.target = '_blank'; link.rel = 'noopener noreferrer';
      $('bill-info').append(title, url, link);
      $('copy-link').disabled = false;
      await refreshLists();
      await showBill(data.bill_id);
    } catch (e) {
      message($('response'), 'Mở Bill thất bại: ' + e.message, 'err');
    } finally { btn.disabled = false; }
  });

  async function loadTables() {
    const container = $('table-list');
    try {
      const data = await STAuth.api('/v1/staff/tables');
      clear(container);
      for (const table of (data.tables || [])) {
        const btn = node('button', undefined, 'reception-table');
        btn.type = 'button';
        btn.append(node('strong', table.name || table.table_id));
        const s = node('span', statusText(table.status) + (table.active_bill_id ? ' · ' + table.active_bill_id : ''),
                       table.status === 'FREE' ? 'table-free' : table.status === 'CLOSING' ? 'table-closing' : 'table-busy');
        btn.append(s);
        if (table.active_bill_id) btn.addEventListener('click', () => showBill(table.active_bill_id));
        else {
          btn.addEventListener('click', () => { $('table-id').value = table.table_id; window.scrollTo({top:0, behavior:'smooth'}); });
        }
        container.append(btn);
      }
      $('tables-status').textContent = `${(data.tables || []).length} bàn · Nhấn vào bàn để xem hóa đơn.`;
    } catch (e) { $('tables-status').textContent = 'Không tải được bàn: ' + e.message; }
  }
  async function loadBills() {
    const container = $('bill-list');
    try {
      const data = await STAuth.api('/v1/staff/bills?limit=50');
      clear(container);
      for (const bill of (data.bills || [])) {
        const line = node('div', undefined, 'reception-bill');
        const left = node('div');
        left.append(node('strong', bill.bill_id));
        left.append(node('p', [bill.table_id || '?', statusText(bill.outcome || bill.status), when(bill.opened_at)].join(' · '), 'small'));
        const view = node('button', 'Chi tiết', 'ghost'); view.type = 'button';
        view.addEventListener('click', () => showBill(bill.bill_id));
        line.append(left, view); container.append(line);
      }
      $('bills-status').textContent = `${(data.bills || []).length} hóa đơn gần đây.`;
    } catch (e) { $('bills-status').textContent = 'Không tải được Bill: ' + e.message; }
  }
  async function refreshLists() { await Promise.all([loadTables(),loadBills()]); }
  $('refresh-tables').addEventListener('click', loadTables);
  $('refresh-bills').addEventListener('click', loadBills);
  $('hide-detail').addEventListener('click', () => { $('bill-panel').hidden = true; state.current = null; });
  $('reload-detail').addEventListener('click', () => { if (state.current) showBill(state.current.bill_id, false); });

  async function showBill(billId, scroll = true) {
    $('bill-panel').hidden = false;
    message($('detail-status'), 'Đang tải chi tiết Bill…');
    try {
      const data = await STAuth.api('/v1/staff/bills/' + encodeURIComponent(billId));
      state.current = data;
      $('detail-status').hidden = true;
      $('detail-title').textContent = 'Bàn ' + data.table_id + ' · ' + data.bill_id;
      $('detail-meta').textContent = statusText(data.outcome || data.status) + ' · Mở lúc ' + when(data.opened_at) + (data.closed_at ? ' · Đóng lúc ' + when(data.closed_at) : '');
      clear($('item-summary'));
      for (const [status, title] of [['ORDERED','Đang chờ'],['COMPLETED','Đã xong'],['REJECTED','Đã từ chối']]) {
        const metric = node('div', undefined, 'reception-stat');
        metric.append(node('strong', String(data.counts?.[status] ?? 0)), node('span', title));
        $('item-summary').append(metric);
      }
      clear($('detail-items'));
      for (const item of (data.items || [])) {
        const line = node('div', undefined, 'reception-portion');
        const col = node('div', undefined, 'portion-detail');
        const flag = node('span', item.status, 'reception-status-tag ' + item.status.toLowerCase());
        const name = node('strong', item.dish_name || item.dish_id);
        const info = node('div', [item.note ? 'Khách: ' + item.note : '',
            item.reason ? 'Lý do từ chối: ' + item.reason : '',
            item.source === 'AUTO_COMPLETED_ON_CLOSE' ? 'Tự hoàn thành khi đóng bill' : '',
            item.kitchen_note ? 'Bếp: ' + item.kitchen_note : ''].filter(Boolean).join(' · '), 'small');
        col.append(flag, name); if (info.textContent) col.append(info);
        line.append(col, node('div', item.status === 'REJECTED' ? 'Không tính tiền' : money(item.price_vnd), 'portion-price'));
        $('detail-items').append(line);
      }
      if (!data.items?.length) $('detail-items').append(node('div', 'Bill chưa có món.', 'empty'));
      clear($('detail-totals'));
      $('detail-totals').append(rowValue('Đã hoàn thành', money(data.completed_total_vnd)));
      $('detail-totals').append(rowValue('Còn chờ — sẽ tính nếu tự hoàn thành', money(data.pending_total_vnd)));
      $('detail-totals').append(rowValue(data.status === 'CLOSED' ? 'Tổng tiền Bill' : 'Tạm tính nếu đóng ngay', money(data.status === 'CLOSED' ? data.total_vnd : data.estimated_total_vnd)));
      $('close-area').hidden = data.status === 'CLOSED';
      $('closed-area').hidden = data.status !== 'CLOSED';
      if (data.status === 'CLOSED') {
        message($('closed-summary'), 'Đã đóng Bill · ' + statusText(data.outcome) + ' · ' + money(data.total_vnd));
        sessionStorage.removeItem(savedKey(data.bill_id));
      }
      if (data.status === 'OPEN') {
        $('closing-notice').hidden = true;
        const saved = getPending(data.bill_id);
        if (saved) {
          document.querySelector(`input[name="payment"][value="${saved.unpaid ? 'UNPAID' : 'PAID'}"]`).checked = true;
          $('close-note').value = saved.note;
        } else {
          document.querySelector('input[name="payment"][value="PAID"]').checked = true;
          $('close-note').value = '';
        }
        $('close-btn').textContent = 'Xem lại trước khi đóng Bill';
      }
      if (data.status === 'CLOSING') {
        const original = {key: data.close_request_key, unpaid: !!data.close_unpaid, note:data.close_note || ''};
        setPending(data.bill_id, original);
        document.querySelector(`input[name="payment"][value="${original.unpaid ? 'UNPAID' : 'PAID'}"]`).checked = true;
        $('close-note').value = original.note;
        $('close-btn').textContent = 'Tiếp tục đóng Bill';
        message($('closing-notice'), 'Bill đang ở trạng thái CLOSING. Giữ nguyên phương thức thanh toán và ghi chú; dùng nút Tiếp tục để hoàn tất.', 'warn');
      }
      for (const element of document.querySelectorAll('input[name="payment"]')) element.disabled = data.status === 'CLOSING';
      $('close-note').disabled = data.status === 'CLOSING';
      $('note-required').textContent = document.querySelector('input[name="payment"]:checked').value === 'UNPAID' ? '(bắt buộc)' : '(tùy chọn)';
      if (scroll) $('bill-panel').scrollIntoView({behavior:'smooth', block:'start'});
    } catch (e) { message($('detail-status'), 'Không tải được Bill: ' + e.message, 'err'); }
  }
  document.querySelectorAll('input[name="payment"]').forEach(radio => radio.addEventListener('change', () => {
    $('note-required').textContent = document.querySelector('input[name="payment"]:checked').value === 'UNPAID' ? '(bắt buộc)' : '(tùy chọn)';
  }));

  $('close-form').addEventListener('submit', event => {
    event.preventDefault();
    const bill = state.current;
    if (!bill || bill.status === 'CLOSED') return;
    const unpaid = document.querySelector('input[name="payment"]:checked').value === 'UNPAID';
    const note = $('close-note').value.trim();
    if (unpaid && !note) { message($('detail-status'), 'Bill UNPAID phải có ghi chú.', 'err'); return; }
    state.pendingConfirm = {billId:bill.bill_id, unpaid, note};
    clear($('confirm-summary'));
    $('confirm-summary').append(rowValue('Bàn', bill.table_id));
    $('confirm-summary').append(rowValue('Trạng thái', unpaid ? 'UNPAID' : 'PAID'));
    $('confirm-summary').append(rowValue('Món chờ sẽ tự xử lý', String(bill.counts.ORDERED)));
    $('confirm-summary').append(rowValue('Tạm tính trước đóng', money(bill.estimated_total_vnd)));
    $('close-confirm').showModal();
  });
  $('cancel-close').addEventListener('click', () => $('close-confirm').close());
  $('confirm-close').addEventListener('click', async () => {
    const data = state.pendingConfirm;
    if (!data) return;
    const old = getPending(data.billId);
    const saved = old && old.unpaid === data.unpaid && old.note === data.note
      ? old : {key: crypto.randomUUID(), unpaid:data.unpaid, note:data.note};
    // Once submitted, persist exact same payload/key for every retry.
    setPending(data.billId, saved);
    const button = $('confirm-close'); button.disabled = true;
    try {
      const result = await STAuth.api('/v1/staff/bills/' + encodeURIComponent(data.billId) + '/close', {
        method:'POST', headers:{'Idempotency-Key':saved.key},
        body:JSON.stringify({unpaid:saved.unpaid, note:saved.note})
      });
      $('close-confirm').close();
      if (result.status === 'CLOSED') {
        sessionStorage.removeItem(savedKey(data.billId));
        message($('detail-status'), 'Đã đóng Bill thành công: ' + statusText(result.outcome) + ' · ' + money(result.total_vnd));
      } else {
        message($('detail-status'), 'Bill đang đóng: ' + (result.message || 'Nhấn Tiếp tục đóng Bill.'), 'warn');
      }
      await refreshLists();
      await showBill(data.billId, false);
    } catch (e) {
      $('close-confirm').close();
      message($('detail-status'), 'Không hoàn tất đóng Bill: ' + e.message + '. Nếu mất kết nối, nhấn gửi lại mà không thay đổi nội dung.', 'err');
    } finally { button.disabled = false; }
  });

  $('copy-receipt').addEventListener('click', async () => {
    const bill = state.current; if (!bill || bill.status !== 'CLOSED') return;
    const lines = ['SECURETABLE', 'Bill ' + bill.bill_id, 'Bàn ' + bill.table_id,
       'Kết quả: ' + bill.outcome, 'Đóng lúc: ' + when(bill.closed_at), ''];
    for (const item of bill.items || []) if (item.status === 'COMPLETED') lines.push(item.dish_name + ': ' + money(item.price_vnd));
    lines.push('', 'Tổng: ' + money(bill.total_vnd));
    try { await navigator.clipboard.writeText(lines.join('\n')); $('copy-receipt').textContent = 'Đã copy hóa đơn'; }
    catch (_) { $('copy-receipt').textContent = 'Không thể copy'; }
  });

  refreshLists();
});
