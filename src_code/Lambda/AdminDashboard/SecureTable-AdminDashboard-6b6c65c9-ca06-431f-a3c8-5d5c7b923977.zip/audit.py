"""SecureTable Audit Dashboard — read-only ADMIN API.

GET /v1/staff/audit-logs?from=YYYY-MM-DD&to=YYYY-MM-DD&actor=&action=&resource=&limit=50&cursor=

DynamoDB schema: SecureTable-AuditLogs, partition key audit_id (String).
This MVP scans (including every LastEvaluatedKey page), then sorts and filters in
memory. It fails explicitly if MAX_SCAN_ITEMS is exceeded rather than showing
an inaccurate partial list or summary. For growing logs, add a date-based GSI.

Auth: API Gateway REST Cognito User Pool authorizer, ID token, scopes empty.
The Lambda additionally REQUIRES ADMIN in authorizer claims.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import logging
import os
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
from zoneinfo import ZoneInfo

import boto3
from botocore.exceptions import ClientError

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)

TABLE_NAME = os.environ.get("AUDIT_TABLE_NAME", "SecureTable-AuditLogs")
MAX_SCAN_ITEMS = int(os.environ.get("MAX_SCAN_ITEMS", "8000"))
TZ = ZoneInfo("Asia/Ho_Chi_Minh")
REDACT_KEYS = {
    "authorization", "password", "passwd", "secret", "secret_key",
    "access_token", "id_token", "refresh_token", "guest_session_token", "session_token",
    "api_key", "cookie", "set-cookie", "private_key", "jwt"
}


def table():
    return boto3.resource("dynamodb").Table(TABLE_NAME)


def response(status, body):
    return {"statusCode": status,
            "headers": {"Content-Type": "application/json; charset=utf-8",
                        "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
            "body": json.dumps(body, ensure_ascii=False, separators=(",", ":"), default=json_number)}


def json_number(x):
    if isinstance(x, Decimal):
        return int(x) if x == x.to_integral_value() else float(x)
    raise TypeError(type(x).__name__)


def error(status, code, message):
    return response(status, {"error": {"code": code, "message": message}})


def authorized(event):
    # No header-based fallback: the identity must come from API Gateway's authorizer.
    claims = ((event.get("requestContext") or {}).get("authorizer") or {}).get("claims") or {}
    if not isinstance(claims, dict) or not claims.get("sub"):
        return 401, "MISSING_COGNITO_IDENTITY", "Thiếu danh tính Cognito đã xác thực."
    raw = claims.get("cognito:groups", [])
    if isinstance(raw, list):
        groups = {str(g).strip() for g in raw}
    elif isinstance(raw, str):
        # REST API may serialize Cognito group claims as '[ADMIN, ...]' or '["ADMIN", ...]'.
        groups = {g.strip().strip('"\' ') for g in raw.strip("[]").split(",")}
    else:
        groups = set()
    if "ADMIN" not in groups:
        return 403, "FORBIDDEN", "Chỉ ADMIN được xem Audit Dashboard."
    return None


def parse_day(value, fallback):
    if value is None or value == "":
        return fallback
    if len(value) != 10 or value[4] != "-" or value[7] != "-":
        raise ValueError("Ngày phải theo định dạng YYYY-MM-DD.")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError("Ngày không hợp lệ.") from exc


def parse_instant(value):
    if not isinstance(value, str) or not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None


def safe_value(x, depth=0):
    if depth >= 6:
        return "[TRUNCATED]"
    if isinstance(x, dict):
        out = {}
        for i, (k, v) in enumerate(x.items()):
            if i >= 60:
                out["_truncated"] = True
                break
            key = str(k)
            out[key] = "[REDACTED]" if key.lower() in REDACT_KEYS else safe_value(v, depth + 1)
        return out
    if isinstance(x, (list, tuple, set)):
        return [safe_value(v, depth + 1) for v in list(x)[:60]]
    if isinstance(x, Decimal):
        return json_number(x)
    if isinstance(x, str):
        return x[:2500] + (" …[TRUNCATED]" if len(x) > 2500 else "")
    if isinstance(x, (bool, int, float)) or x is None:
        return x
    return str(x)[:150]


def fingerprint(filters):
    return hashlib.sha256(json.dumps(filters, sort_keys=True, ensure_ascii=True).encode()).hexdigest()[:20]


def encode_cursor(offset, cutoff, digest):
    data = {"o": offset, "c": cutoff.isoformat(), "f": digest}
    return base64.urlsafe_b64encode(json.dumps(data, separators=(",", ":")).encode()).decode().rstrip("=")


def decode_cursor(raw, digest):
    if len(raw) > 512:
        raise ValueError("Cursor không hợp lệ.")
    try:
        data = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)).decode())
        off = data["o"]
        cutoff = parse_instant(data["c"])
        if type(off) is not int or off < 0 or off > 100000 or data["f"] != digest or not cutoff:
            raise ValueError()
        if cutoff > datetime.now(timezone.utc) + timedelta(minutes=5):
            raise ValueError()
        return off, cutoff
    except (ValueError, KeyError, TypeError, UnicodeError, binascii.Error, json.JSONDecodeError) as exc:
        raise ValueError("Cursor không hợp lệ hoặc không khớp bộ lọc.") from exc


def read_audit():
    # Do not silently give an incomplete report if the Scan is too large.
    all_rows = []
    total_read = 0
    last = None
    dynamo_table = table()
    while True:
        kwargs = {"Limit": 250, "ConsistentRead": False}
        if last:
            kwargs["ExclusiveStartKey"] = last
        page = dynamo_table.scan(**kwargs)
        total_read += int(page.get("ScannedCount", len(page.get("Items", []))))
        if total_read > MAX_SCAN_ITEMS:
            raise OverflowError("Số lượng log vượt giới hạn quét của bản MVP. Cần thêm GSI theo ngày.")
        all_rows.extend(page.get("Items", []))
        last = page.get("LastEvaluatedKey")
        if not last:
            break
    return all_rows, total_read


def audit_list(event):
    query = event.get("queryStringParameters") or {}
    if not isinstance(query, dict):
        query = {}
    today = datetime.now(TZ).date()
    try:
        start = parse_day(query.get("from"), today - timedelta(days=6))
        end = parse_day(query.get("to"), today)
        if end < start or (end - start).days > 30:
            raise ValueError("Chọn khoảng từ 1 đến 31 ngày.")
        raw_limit = str(query.get("limit") or "50")
        if not raw_limit.isascii() or not raw_limit.isdecimal():
            raise ValueError("limit phải là số nguyên.")
        limit = int(raw_limit)
        if limit < 1 or limit > 100:
            raise ValueError("limit phải từ 1 đến 100.")
        actor = str(query.get("actor") or "").strip().lower()
        action = str(query.get("action") or "").strip().upper()
        resource = str(query.get("resource") or "").strip().lower()
        for x in (actor, action, resource):
            if len(x) > 100:
                raise ValueError("Bộ lọc không được dài hơn 100 ký tự.")
        filters = {"from": start.isoformat(), "to": end.isoformat(),
                   "actor": actor, "action": action, "resource": resource, "limit": limit}
        digest = fingerprint(filters)
        if query.get("cursor"):
            offset, cutoff = decode_cursor(str(query["cursor"]), digest)
        else:
            offset, cutoff = 0, datetime.now(timezone.utc)
    except ValueError as exc:
        return error(400, "INVALID_FILTER", str(exc))

    begin = datetime.combine(start, time.min, TZ).astimezone(timezone.utc)
    finish = datetime.combine(end + timedelta(days=1), time.min, TZ).astimezone(timezone.utc)
    try:
        rows, scanned_count = read_audit()
    except OverflowError as exc:
        return error(422, "AUDIT_SCAN_LIMIT", str(exc))
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "ClientError")
        LOG.error("DynamoDB Audit scan failed: %s", code)
        return error(500, "DYNAMODB_READ_FAILED", "Không đọc được AuditLogs. Kiểm tra IAM và tên bảng trong CloudWatch.")
    except Exception:
        LOG.exception("Unexpected AuditLogs read failure")
        return error(500, "AUDIT_INTERNAL_ERROR", "Có lỗi khi đọc nhật ký hệ thống.")

    matches = []
    for row in rows:
        stamp = parse_instant(row.get("timestamp") or row.get("created_at"))
        if stamp is None or not (begin <= stamp < finish) or stamp > cutoff:
            continue
        if actor and actor not in str(row.get("actor_id") or "").lower():
            continue
        if action and action != str(row.get("action") or "").upper():
            continue
        if resource:
            fields = (row.get("resource_type"), row.get("resource_id"), row.get("table_id"), row.get("bill_id"))
            if not any(resource in str(v or "").lower() for v in fields):
                continue
        matches.append((stamp, str(row.get("audit_id") or ""), row))
    matches.sort(key=lambda x: (x[0], x[1]), reverse=True)
    total = len(matches)
    page_rows = [safe_value(x[2]) for x in matches[offset:offset + limit]]
    next_pos = offset + limit
    actors = {str(x[2].get("actor_id") or "") for x in matches if x[2].get("actor_id")}
    actions = Counter(str(x[2].get("action") or "UNKNOWN") for x in matches)
    by_day = Counter(x[0].astimezone(TZ).date().isoformat() for x in matches)
    overview = {
        "total_events": total,
        "unique_actors": len(actors),
        "unique_actions": len(actions),
        "action_counts": [{"action": k, "count": v} for k, v in actions.most_common(15)],
        "by_day": [{"date": k, "count": v} for k, v in sorted(by_day.items())]
    }
    return response(200, {
        "items": page_rows,
        "total": total,
        "limit": limit,
        "next_cursor": encode_cursor(next_pos, cutoff, digest) if next_pos < total else None,
        "summary": overview,
        "filters": filters,
        "scanned_items": scanned_count,
        "read_at": datetime.now(timezone.utc).isoformat()
    })


def lambda_handler(event, context):
    event = event or {}
    auth = authorized(event)
    if auth:
        return error(*auth)
    method = str(event.get("httpMethod") or "").upper()
    path = (event.get("path") or "").rstrip("/")
    if method != "GET":
        return error(405, "METHOD_NOT_ALLOWED", "Audit API chỉ hỗ trợ GET.")
    if path != "/v1/staff/audit-logs":
        return error(404, "NOT_FOUND", "Đường dẫn không tồn tại.")
    return audit_list(event)
