"""SecureTable Finance Dashboard (ADMIN only, read-only).

REST API Gateway + Cognito User Pool Authorizer, Lambda proxy integration.
Data model matched to SecureTable-Reception, -Inventory and -Kitchen (Nov 2026).
No AWS credentials, secrets or third party libraries besides Lambda runtime boto3.

MVP limitations: full DynamoDB table scans, capped for safety; not a transactionally
consistent cross-table snapshot; single restaurant, low volume. For production,
replace scans with date GSIs or daily aggregate records and add reconciliation.
"""
import json
import os
import re
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

import boto3
from botocore.exceptions import ClientError

TZ = ZoneInfo('Asia/Ho_Chi_Minh')
REGION = os.environ.get('AWS_REGION', 'ap-southeast-1')
DB = boto3.resource('dynamodb', region_name=REGION)
NAMES = {
    'bills': 'SecureTable-Bills',
    'ledger': 'SecureTable-FinanceLedger',
    'movements': 'SecureTable-InventoryMovements',
    'counts': 'SecureTable-InventoryCounts',
    'ingredients': 'SecureTable-Ingredients',
}
TABLES = {k: DB.Table(name) for k, name in NAMES.items()}
MAX_PAGES_PER_TABLE = 100
MAX_ITEMS_PER_TABLE = 25000
DATE_RX = re.compile(r'^\d{4}-\d{2}-\d{2}$')
CONSUMPTION_REASONS = frozenset({'KITCHEN_COMPLETED', 'AUTO_COMPLETED_ON_CLOSE'})
LOSS_REASONS = frozenset({'OUT_OF_STOCK_LOSS'})
PURCHASE_TYPES = frozenset({'PURCHASE_EXPENSE', 'PURCHASE_EXPENSE_ADJUSTMENT'})


def reply(code, data):
    return {'statusCode': code, 'headers': {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'},
        'body': json.dumps(data, ensure_ascii=False, default=str)}


def fail(status, code, message):
    return reply(status, {'error': {'code': code, 'message': message}})


def staff_claims(event):
    return ((event.get('requestContext') or {}).get('authorizer') or {}).get('claims') or {}


def is_admin(claims):
    value = claims.get('cognito:groups', '')
    if isinstance(value, list):
        return 'ADMIN' in value
    if isinstance(value, str):
        # REST API Gateway may inject a string such as '[ADMIN, RECEPTION]'.
        return 'ADMIN' in re.findall(r'[A-Za-z][A-Za-z0-9_-]*', value)
    return False


def parse_day(value):
    if not isinstance(value, str) or not DATE_RX.fullmatch(value):
        raise ValueError('Ngày phải theo định dạng YYYY-MM-DD')
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError('Ngày không hợp lệ') from exc


def as_vnd(obj, field):
    val = Decimal(str(obj.get(field, 0) or 0))
    if not val.is_finite():
        raise ValueError('Dữ liệu tiền tệ không hợp lệ: ' + field)
    # Total cost of usage can have fractions of VND. Round once per report,
    # not once per movement, to avoid accumulating rounding errors.
    return val


def business_day(timestamp, fallback=None):
    if isinstance(timestamp, str) and timestamp:
        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            if dt.tzinfo is None:
                return None   # refuse to guess timezone
            return dt.astimezone(TZ).date().isoformat()
        except ValueError:
            return None
    return fallback if isinstance(fallback, str) and DATE_RX.fullmatch(fallback) else None


def scan_all(name):
    out, cursor = [], None
    for _ in range(MAX_PAGES_PER_TABLE):
        params = {'ConsistentRead': True}
        if cursor:
            params['ExclusiveStartKey'] = cursor
        result = TABLES[name].scan(**params)
        out.extend(result.get('Items') or [])
        if len(out) > MAX_ITEMS_PER_TABLE:
            raise RuntimeError('REPORT_TOO_LARGE')
        cursor = result.get('LastEvaluatedKey')
        if not cursor:
            return out
    raise RuntimeError('REPORT_TOO_LARGE')


def load_data(include_stock=False):
    data = {k: scan_all(k) for k in ('bills', 'ledger', 'movements', 'counts')}
    if include_stock:
        data['ingredients'] = scan_all('ingredients')
    return data


def empty_metrics(d):
    return {'date': d, 'bills': {'paid': 0, 'unpaid': 0, 'empty': 0},
            'collected_revenue_vnd': 0, 'unpaid_bill_value_vnd': 0,
            'purchase_spend_vnd': 0, 'material_consumption_cost_vnd': 0,
            'inventory_loss_cost_vnd': 0, 'cash_difference_vnd': 0,
            'estimated_gross_profit_vnd': 0, 'estimated_after_loss_vnd': 0}


def build_metrics(start, end, data):
    days = {}
    current = start
    while current <= end:
        days[current.isoformat()] = empty_metrics(current.isoformat())
        current += timedelta(days=1)
    # Use Decimal for aggregate cost and rounded VND only at output stage.
    totals = {day: {'revenue': Decimal(0), 'unpaid': Decimal(0),
                    'purchase': Decimal(0), 'consumed': Decimal(0),
                    'loss': Decimal(0)} for day in days}
    bill_records = {}
    for b in data['bills']:
        if b.get('status') != 'CLOSED':
            continue
        d = business_day(b.get('closed_at'))
        if d not in days:
            continue
        outcome = b.get('outcome')
        if outcome not in ('PAID', 'UNPAID', 'EMPTY'):
            continue
        billid = b.get('bill_id')
        if billid:
            bill_records[billid] = b
        days[d]['bills'][outcome.lower()] += 1
        amt = as_vnd(b, 'total_vnd')
        if outcome == 'PAID':
            totals[d]['revenue'] += amt
        elif outcome == 'UNPAID':
            totals[d]['unpaid'] += amt
    for l in data['ledger']:
        if l.get('entry_type') not in PURCHASE_TYPES:
            continue
        d = business_day(l.get('created_at'), l.get('business_date'))
        if d in days:
            totals[d]['purchase'] += as_vnd(l, 'amount_vnd')
    for m in data['movements']:
        d = business_day(m.get('created_at'))
        if d not in days:
            continue
        reason = m.get('reason')
        if reason in CONSUMPTION_REASONS:
            totals[d]['consumed'] += as_vnd(m, 'total_cost_vnd')
        elif reason in LOSS_REASONS:
            totals[d]['loss'] += as_vnd(m, 'total_cost_vnd')
    # Count losses are ONLY read from InventoryCounts; their corresponding
    # STOCK_COUNT_DISCREPANCY movement is intentionally excluded.
    for c in data['counts']:
        if c.get('status') != 'CONFIRMED':
            continue
        d = business_day(c.get('confirmed_at'), c.get('business_date'))
        if d in days:
            totals[d]['loss'] += as_vnd(c, 'loss_value_estimated_vnd')
    for d, row in days.items():
        t = totals[d]
        for name, key in (('collected_revenue_vnd', 'revenue'),
                          ('unpaid_bill_value_vnd', 'unpaid'),
                          ('purchase_spend_vnd', 'purchase'),
                          ('material_consumption_cost_vnd', 'consumed'),
                          ('inventory_loss_cost_vnd', 'loss')):
            row[name] = int(t[key].quantize(Decimal('1'), rounding='ROUND_HALF_UP'))
        row['cash_difference_vnd'] = row['collected_revenue_vnd'] - row['purchase_spend_vnd']
        row['estimated_gross_profit_vnd'] = row['collected_revenue_vnd'] - row['material_consumption_cost_vnd']
        row['estimated_after_loss_vnd'] = row['estimated_gross_profit_vnd'] - row['inventory_loss_cost_vnd']
    return list(days.values())


def summary(days, start, end, include_rows=True):
    keys = ('collected_revenue_vnd', 'unpaid_bill_value_vnd', 'purchase_spend_vnd',
            'material_consumption_cost_vnd', 'inventory_loss_cost_vnd',
            'cash_difference_vnd', 'estimated_gross_profit_vnd', 'estimated_after_loss_vnd')
    counts = ('paid', 'unpaid', 'empty')
    result = {'from': start.isoformat(), 'to': end.isoformat(),
              'bills': {k: sum(d['bills'][k] for d in days) for k in counts}}
    result.update({key: sum(d[key] for d in days) for key in keys})
    if include_rows:
        result['days'] = days
    result['notes'] = {
        'date_basis': 'Bill: ngày đóng; chi/tiêu hao/thất thoát: ngày sự kiện (Asia/Ho_Chi_Minh)',
        'purchase_vs_cogs': 'Chi mua nguyên liệu khác giá vốn tiêu hao; không lấy thu trừ chi mua làm lợi nhuận',
        'cost_method': 'Giá nhập gần nhất tại thời điểm phát sinh; các chỉ số lợi nhuận là ước tính',
        'data_freshness': 'MVP dùng Scan; số liệu có thể đổi khi phát sinh giao dịch đồng thời',
    }
    return result


def stock_view(data):
    latest_count = {}
    for count in data['counts']:
        if count.get('status') != 'CONFIRMED':
            continue
        when = count.get('confirmed_at') or ''
        for item in count.get('items') or []:
            iid = item.get('ingredient_id')
            if iid and when > latest_count.get(iid, ''):
                latest_count[iid] = when
    stock = []
    for ing in data.get('ingredients', []):
        iid = ing.get('ingredient_id')
        if not iid:
            continue
        stock.append({'ingredient_id': iid, 'name': ing.get('name') or iid,
                      'unit': ing.get('base_unit') or '',
                      'qty_base': float(ing.get('stock_book', 0) or 0),
                      'reserved': float(ing.get('reserved', 0) or 0),
                      'last_counted_at': latest_count.get(iid)})
    return sorted(stock, key=lambda x: x['ingredient_id'])


def lambda_handler(event, context):
    claims = staff_claims(event)
    if not isinstance(claims, dict) or not isinstance(claims.get('sub'), str) or not claims['sub']:
        return fail(401, 'UNAUTHORIZED', 'Thiếu danh tính Cognito')
    if not is_admin(claims):
        return fail(403, 'FORBIDDEN', 'Chỉ ADMIN được xem báo cáo tài chính')
    if (event.get('httpMethod') or '').upper() != 'GET':
        return fail(405, 'METHOD_NOT_ALLOWED', 'Chỉ hỗ trợ GET')
    resource = event.get('resource') or event.get('path') or ''
    params = event.get('queryStringParameters') or {}
    try:
        if resource in ('/v1/staff/finance/daily/{date}',) or re.fullmatch(r'/v1/staff/finance/daily/\d{4}-\d{2}-\d{2}', resource):
            target = (event.get('pathParameters') or {}).get('date') or resource.rsplit('/', 1)[-1]
            d = parse_day(target)
            data = load_data(include_stock=True)
            day = build_metrics(d, d, data)[0]
            day['stock'] = stock_view(data)
            day['notes'] = summary([day], d, d, include_rows=False)['notes']
            day['stock_note'] = 'Tồn HIỆN TẠI, không phải snapshot của ngày báo cáo'
            return reply(200, day)
        if resource == '/v1/staff/finance/summary':
            start, end = parse_day(params.get('from')), parse_day(params.get('to'))
            if end < start or (end - start).days > 30:
                return fail(400, 'INVALID_RANGE', 'Khoảng ngày phải từ 1 đến 31 ngày')
            data = load_data()
            return reply(200, summary(build_metrics(start, end, data), start, end))
        if resource == '/v1/staff/finance/weekly':
            week = parse_day(params.get('week_start'))
            if week.weekday() != 0:
                return fail(400, 'INVALID_WEEK_START', 'week_start phải là Thứ Hai')
            end = week + timedelta(days=6)
            data = load_data()
            result = summary(build_metrics(week, end, data), week, end)
            result['week_start'] = week.isoformat()
            return reply(200, result)
        return fail(404, 'NOT_FOUND', 'Finance endpoint không tồn tại')
    except ValueError as exc:
        return fail(400, 'INVALID_INPUT', str(exc))
    except ClientError as exc:
        code = (exc.response.get('Error') or {}).get('Code', 'UNKNOWN')
        print('Finance DynamoDB error:', code)  # no tokens/user data
        return fail(500, 'DYNAMODB_READ_ERROR', 'Không thể đọc dữ liệu báo cáo; kiểm tra CloudWatch và IAM')
    except RuntimeError as exc:
        if str(exc) == 'REPORT_TOO_LARGE':
            return fail(503, 'REPORT_TOO_LARGE', 'Dữ liệu đã vượt giới hạn Scan của bản MVP; cần GSI/aggregate')
        raise
