"""SecureTable AdminDashboard Lambda (REST API Gateway Lambda proxy integration).

Merges existing Finance + Audit entry points without changing their implementations.
The original modules retain their individual ADMIN checks and API response schemas.
"""
import json

import finance
import audit


def lambda_handler(event, context):
    event = event or {}
    path = str(event.get("path") or "").rstrip("/")
    resource = str(event.get("resource") or "").rstrip("/")

    if path == "/v1/staff/audit-logs" or resource == "/v1/staff/audit-logs":
        return audit.lambda_handler(event, context)

    if (path.startswith("/v1/staff/finance/") or
            resource.startswith("/v1/staff/finance/")):
        return finance.lambda_handler(event, context)

    return {
        "statusCode": 404,
        "headers": {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        },
        "body": json.dumps({"error": {"code": "NOT_FOUND", "message": "Endpoint không tồn tại."}},
                           ensure_ascii=False),
    }
