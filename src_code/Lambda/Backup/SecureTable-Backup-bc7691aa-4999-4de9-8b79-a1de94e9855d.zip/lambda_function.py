"""SecureTable weekly full DynamoDB exports to S3.

EventBridge Scheduler payload:
  {"scheduled_at": "<aws.scheduler.scheduled-time>"}

Manual test payload:
  {"dry_run": true, "backup_id": "demo-2026-11-25"}

Manual live payload (retry with identical backup_id within 8 hours):
  {"dry_run": false, "backup_id": "demo-2026-11-25"}
"""

import hashlib
import json
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import boto3
from botocore.exceptions import ClientError

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
DDB = boto3.client("dynamodb")
TABLES = (
    "SecureTable-Bills",
    "SecureTable-Orders",
    "SecureTable-OrderItems",
    "SecureTable-Ingredients",
    "SecureTable-InventoryReceipts",
    "SecureTable-InventoryCorrections",
    "SecureTable-InventoryMovements",
    "SecureTable-FinanceLedger",
    "SecureTable-InventoryCounts",
    "SecureTable-AuditLogs",
    "SecureTable-Tables",
    "SecureTable-MenuItems",
    "SecureTable-ReceiptCorrectionState",
)


def _parse_utc(value):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("scheduled_at must be ISO 8601 with UTC offset")
    when = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    if when.tzinfo is None:
        raise ValueError("scheduled_at must include an offset or Z")
    return when.astimezone(timezone.utc).replace(microsecond=0)


def _backup_ref(event):
    scheduled = event.get("scheduled_at")
    if scheduled:
        when = _parse_utc(scheduled)
        # Scheduler fires at Sunday 02:00 Asia/Ho_Chi_Minh.
        # Export a common point slightly behind schedule to leave PITR catch-up time.
        snapshot = when - timedelta(minutes=15)
        if snapshot > datetime.now(timezone.utc) - timedelta(minutes=1):
            raise ValueError("Export snapshot must be in the past")
        return when.strftime("%Y%m%dT%H%M%SZ"), snapshot

    backup_id = event.get("backup_id")
    if backup_id is None:
        backup_id = "manual-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        LOGGER.warning("No backup_id supplied for manual call; reruns may create another export batch")
    if not isinstance(backup_id, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", backup_id):
        raise ValueError("backup_id must contain 1-64 letters, numbers, '-' or '_'")
    # For an ad hoc demo, DynamoDB chooses the latest exportable snapshot.
    return backup_id, None


def _check_table(table, snapshot):
    desc = DDB.describe_table(TableName=table)["Table"]
    if desc.get("TableStatus") != "ACTIVE":
        raise RuntimeError(f"{table}: table is not ACTIVE")
    pitr = DDB.describe_continuous_backups(TableName=table)["ContinuousBackupsDescription"].get(
        "PointInTimeRecoveryDescription", {}
    )
    if pitr.get("PointInTimeRecoveryStatus") != "ENABLED":
        raise RuntimeError(f"{table}: PITR is not ENABLED")
    earliest = pitr.get("EarliestRestorableDateTime")
    latest = pitr.get("LatestRestorableDateTime")
    if snapshot is not None and earliest is not None and latest is not None:
        if not earliest <= snapshot <= latest:
            raise RuntimeError(
                f"{table}: snapshot {snapshot.isoformat()} outside PITR window "
                f"[{earliest.isoformat()}, {latest.isoformat()}]"
            )
    return desc["TableArn"]


def lambda_handler(event, context):
    event = event or {}
    if not isinstance(event, dict):
        raise ValueError("Expected a JSON object")
    bucket = os.environ.get("BACKUP_BUCKET", "").strip()
    if not bucket:
        raise RuntimeError("Set BACKUP_BUCKET under Lambda Environment variables")
    prefix_root = os.environ.get("BACKUP_PREFIX", "securetable/weekly").strip("/")
    if not prefix_root or ".." in prefix_root or "//" in prefix_root:
        raise ValueError("Invalid BACKUP_PREFIX")
    dry_run = event.get("dry_run", False)
    if type(dry_run) is not bool:
        raise ValueError("dry_run must be boolean")
    batch_id, snapshot = _backup_ref(event)
    region = os.environ.get("AWS_REGION", "ap-southeast-1")
    LOGGER.info("Backup start batch=%s region=%s tables=%s dry_run=%s", batch_id, region, len(TABLES), dry_run)

    # Validate all tables and PITR before starting any paid export.
    # This does not freeze the restaurant; exports are not transactionally atomic across tables.
    verified = {}
    invalid = []
    for table in TABLES:
        try:
            verified[table] = _check_table(table, snapshot)
        except ClientError as exc:
            invalid.append({"table": table, "error": exc.response.get("Error", {}).get("Code", "AWS_ERROR")})
        except Exception as exc:
            invalid.append({"table": table, "error": str(exc)})

    if invalid:
        LOGGER.error("PRECHECK_FAILED %s", json.dumps(invalid, ensure_ascii=False))
        if not dry_run:
            raise RuntimeError("Backup preflight failed: " + json.dumps(invalid, ensure_ascii=False))
        return {"mode": "DRY_RUN", "ready": False, "table_count": len(TABLES), "errors": invalid}

    if dry_run:
        return {
            "mode": "DRY_RUN",
            "ready": True,
            "table_count": len(TABLES),
            "tables": list(TABLES),
            "bucket": bucket,
            "s3_prefix": f"{prefix_root}/{batch_id}/",
            "export_time": snapshot.isoformat() if snapshot else "latest restorable",
        }

    exports = []
    errors = []
    for table in TABLES:
        s3_prefix = f"{prefix_root}/{batch_id}/{table}"
        token = hashlib.sha256(f"{region}:{bucket}:{s3_prefix}".encode("utf-8")).hexdigest()
        request = {
            "TableArn": verified[table],
            "S3Bucket": bucket,
            "S3Prefix": s3_prefix,
            "S3SseAlgorithm": "AES256",
            "ExportFormat": "DYNAMODB_JSON",
            "ExportType": "FULL_EXPORT",
            "ClientToken": token,
        }
        if snapshot is not None:
            request["ExportTime"] = snapshot
        try:
            result = DDB.export_table_to_point_in_time(**request)["ExportDescription"]
            exports.append({
                "table": table,
                "status": result.get("ExportStatus", "IN_PROGRESS"),
                "export_arn": result["ExportArn"],
                "s3_prefix": s3_prefix,
            })
            LOGGER.info("EXPORT_REQUESTED table=%s status=%s arn=%s", table, result.get("ExportStatus"), result["ExportArn"])
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "AWS_ERROR")
            errors.append({"table": table, "code": code})
            LOGGER.exception("EXPORT_REQUEST_FAILED table=%s error=%s", table, code)

    LOGGER.info("BATCH_RESULT requested=%s errors=%s batch=%s", len(exports), len(errors), batch_id)
    if errors:
        # Let Lambda/Scheduler error metrics and retry capture partial failure. ClientToken
        # deduplicates identical requests for 8 hours. Retry with the same scheduled_at.
        raise RuntimeError("Some exports could not start: " + json.dumps(errors))

    return {
        "mode": "STARTED",
        "batch_id": batch_id,
        "table_count": len(TABLES),
        "exports_requested": len(exports),
        "export_time": snapshot.isoformat() if snapshot else "latest restorable",
        "bucket": bucket,
        "exports": exports,
        "note": "IN_PROGRESS is not COMPLETED. Verify each export in DynamoDB > Exports to S3.",
    }
