"""SecureTable GuestServices -- GuestSessions + Menu.

API Gateway REST Lambda proxy integration:
  POST /v1/guest/sessions  -> create a guest session for an open table bill
  GET  /v1/guest/menu      -> show menu after validating the guest session

No Cognito authorizer on these guest routes. Menu requires the guest Bearer token.
AWS Lambda handler: lambda_function.lambda_handler
"""

import boto3
import hashlib
import json
import re
import secrets
import time
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from botocore.exceptions import ClientError


db = boto3.resource("dynamodb")
tables = db.Table("SecureTable-Tables")
bills = db.Table("SecureTable-Bills")
sessions = db.Table("SecureTable-GuestSessions")
menu = db.Table("SecureTable-MenuItems")
ingredients = db.Table("SecureTable-Ingredients")
SESSION_HOURS = 2


def response(status, data):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Cache-Control": "no-store"
        },
        "body": json.dumps(data, ensure_ascii=False)
    }


# Original GuestSession.py behavior (renamed handler only).
def create_guest_session(event, context):

    # 1. Read and validate table ID
    try:
        body = event.get("body")

        if not isinstance(body, str) or len(body) > 1024:
            raise ValueError()

        data = json.loads(body)

        if not isinstance(data, dict):
            raise ValueError()

        table_id = data.get("table_id")

        if not isinstance(table_id, str):
            raise ValueError()

        table_id = table_id.strip().upper()

        if not re.fullmatch(r"T[A-Z0-9_-]{1,30}", table_id):
            raise ValueError()

    except (ValueError, TypeError):
        return response(400, {
            "error": "INVALID_TABLE_ID"
        })

    try:
        # 2. Check table
        result = tables.get_item(
            Key={"table_id": table_id},
            ConsistentRead=True
        )

        table = result.get("Item")

        if not table:
            return response(409, {
                "error": "TABLE_NOT_ACTIVE"
            })

        if table.get("status") != "OCCUPIED":
            return response(409, {
                "error": "TABLE_NOT_ACTIVE"
            })

        bill_id = table.get("active_bill_id")

        if not isinstance(bill_id, str) or not bill_id:
            return response(409, {
                "error": "TABLE_NOT_ACTIVE"
            })

        # 3. Check the current bill
        bill_result = bills.get_item(
            Key={"bill_id": bill_id},
            ConsistentRead=True
        )

        bill = bill_result.get("Item")

        if (
            not bill
            or bill.get("status") != "OPEN"
            or bill.get("table_id") != table_id
        ):
            return response(409, {
                "error": "TABLE_NOT_ACTIVE"
            })

        # 4. Generate a secure random session token
        token = secrets.token_urlsafe(32)

        token_hash = hashlib.sha256(
            token.encode("utf-8")
        ).hexdigest()

        now = datetime.now(timezone.utc)
        expires = now + timedelta(hours=SESSION_HOURS)

        # 5. Store only the token hash
        sessions.put_item(
            Item={
                "session_hash": token_hash,
                "table_id": table_id,
                "bill_id": bill_id,
                "created_at": now.isoformat(),
                "expires_at": int(expires.timestamp())
            },
            ConditionExpression=(
                "attribute_not_exists(session_hash)"
            )
        )

        # 6. Return the token to the customer
        return response(201, {
            "guest_session_token": token,
            "table_id": table_id,
            "expires_at": expires.isoformat()
        })

    except ClientError as error:
        print(
            "DynamoDB error:",
            error.response["Error"]["Code"]
        )

        return response(500, {
            "error": "INTERNAL_SERVER_ERROR"
        })


# Original Menu.py behavior (renamed handler only).
def get_guest_menu(event, context):
    # 1. Extract the guest token
    headers = {
        str(k).lower(): str(v)
        for k, v in (event.get("headers") or {}).items()
    }

    authorization = headers.get("authorization", "")
    parts = authorization.split()

    if len(parts) != 2 or parts[0].lower() != "bearer":
        return response(401, {
            "error": "UNAUTHORIZED"
        })

    token = parts[1]

    if not 32 <= len(token) <= 256:
        return response(401, {
            "error": "INVALID_SESSION"
        })

    token_hash = hashlib.sha256(
        token.encode("utf-8")
    ).hexdigest()

    try:
        # 2. Check guest session
        result = sessions.get_item(
            Key={"session_hash": token_hash},
            ConsistentRead=True
        )

        session = result.get("Item")

        if not session:
            return response(401, {
                "error": "INVALID_SESSION"
            })

        if (
            int(session.get("expires_at", 0)) <= int(time.time())
            or session.get("revoked_at") is not None
        ):
            return response(401, {
                "error": "SESSION_EXPIRED"
            })

        table_id = session.get("table_id")
        bill_id = session.get("bill_id")

        if not table_id or not bill_id:
            return response(401, {
                "error": "INVALID_SESSION"
            })

        # 3. Verify table is still occupied
        table = tables.get_item(
            Key={"table_id": table_id},
            ConsistentRead=True
        ).get("Item")

        if (
            not table
            or table.get("status") != "OCCUPIED"
            or table.get("active_bill_id") != bill_id
        ):
            return response(401, {
                "error": "SESSION_NOT_ACTIVE"
            })

        # 4. Verify current bill
        bill = bills.get_item(
            Key={"bill_id": bill_id},
            ConsistentRead=True
        ).get("Item")

        if (
            not bill
            or bill.get("status") != "OPEN"
            or bill.get("table_id") != table_id
        ):
            return response(401, {
                "error": "SESSION_NOT_ACTIVE"
            })

        # 5. Read the menu
        dishes = []
        start_key = None

        # Small MVP: read up to 200 menu records.
        while len(dishes) < 200:
            scan_args = {
                "Limit": 100,
                "ConsistentRead": True
            }

            if start_key:
                scan_args["ExclusiveStartKey"] = start_key

            result = menu.scan(**scan_args)

            dishes.extend(result.get("Items", []))
            start_key = result.get("LastEvaluatedKey")

            if not start_key:
                break

        # 6. Check ingredient availability
        ingredient_cache = {}
        items = []

        for dish in dishes[:200]:
            if dish.get("active", True) is False:
                continue

            recipe = dish.get("recipe", [])
            max_portions = 99 if recipe else 0

            for component in recipe:
                ingredient_id = component.get("ingredient_id")
                needed = Decimal(
                    str(component.get("qty_base", "0"))
                )

                if not ingredient_id or needed <= 0:
                    max_portions = 0
                    break

                if ingredient_id not in ingredient_cache:
                    ingredient_cache[ingredient_id] = (
                        ingredients.get_item(
                            Key={"ingredient_id": ingredient_id},
                            ConsistentRead=True
                        ).get("Item")
                    )

                ingredient = ingredient_cache[ingredient_id]

                if not ingredient or (
                    ingredient.get("stock_status") == "OUT_OF_STOCK"
                ):
                    max_portions = 0
                    break

                stock = Decimal(
                    str(ingredient.get("stock_book", 0))
                )

                reserved = Decimal(
                    str(ingredient.get("reserved", 0))
                )

                available = max(
                    Decimal("0"), stock - reserved
                )

                portions = int(available // needed)

                max_portions = min(
                    max_portions, portions
                )

                if max_portions == 0:
                    break

            items.append({
                "dish_id": dish["dish_id"],
                "name": dish["name"],
                "description": dish.get("description", ""),
                "category_id": dish.get("category_id"),
                "price_vnd": int(dish["price_vnd"]),
                "availability": (
                    "AVAILABLE" if max_portions > 0
                    else "UNAVAILABLE"
                ),
                "max_portions": max_portions
            })

        items.sort(key=lambda item: item["name"])

        return response(200, {
            "items": items
        })

    except ClientError as error:
        print(
            "DynamoDB error:",
            error.response["Error"]["Code"]
        )

        return response(500, {
            "error": "INTERNAL_SERVER_ERROR"
        })


def lambda_handler(event, context):
    """Route by HTTP method AND path; do not rely on path alone."""
    method = str(event.get("httpMethod") or
                 (event.get("requestContext") or {}).get("http", {}).get("method") or "").upper()
    path = str(event.get("resource") or event.get("path") or event.get("rawPath") or "").rstrip("/")

    if method == "POST" and path.endswith("/guest/sessions"):
        return create_guest_session(event, context)
    if method == "GET" and path.endswith("/guest/menu"):
        return get_guest_menu(event, context)
    return response(404, {"error": "ROUTE_NOT_FOUND"})
