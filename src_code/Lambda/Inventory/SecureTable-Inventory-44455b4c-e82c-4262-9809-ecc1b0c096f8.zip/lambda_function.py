"""SecureTable Inventory MVP: list ingredients, create and list receipts.

API Gateway REST API (Lambda proxy). Every method MUST use the existing
Cognito User Pool Authorizer, with OAuth scopes empty so ID token claims reach
requestContext.authorizer.claims. Lambda checks INVENTORY/ADMIN groups too.

Receipt effects are one DynamoDB TransactWriteItems operation:
  conditional stock increments + immutable receipt + purchase expense +
  inventory movements + business audit + notification outbox + idempotency.
Outbox delivery to SNS is a separate future component; this Lambda does NOT
claim to have sent an email.
"""
import base64
import hashlib
import json
import re
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

import boto3
from boto3.dynamodb.types import TypeSerializer
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

REGION = "ap-southeast-1"
resource = boto3.resource("dynamodb", region_name=REGION)
client = boto3.client("dynamodb", region_name=REGION)
serializer = TypeSerializer()

NAMES = {
    "ingredients": "SecureTable-Ingredients",
    "receipts": "SecureTable-InventoryReceipts",
    "movements": "SecureTable-InventoryMovements",
    "finance": "SecureTable-FinanceLedger",
    "audit": "SecureTable-AuditLogs",
    "outbox": "SecureTable-NotificationOutbox",
    "idempotency": "SecureTable-Idempotency",
    "corrections": "SecureTable-InventoryCorrections",
    "correction_state": "SecureTable-ReceiptCorrectionState",
}

ING = resource.Table(NAMES["ingredients"])
RECEIPTS = resource.Table(NAMES["receipts"])
IDEM = resource.Table(NAMES["idempotency"])
CORRECTIONS = resource.Table(NAMES["corrections"])
CORRECTION_STATE = resource.Table(NAMES["correction_state"])
LATEST_RECEIPT_META_KEY = "META#LATEST_RECEIPT"


def attr(value):
    return serializer.serialize(value)


def attrs(obj):
    return {k: attr(v) for k, v in obj.items()}


def reply(status, data):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store"},
        "body": json.dumps(data, ensure_ascii=False, default=str),
    }


def error(status, code, message):
    return reply(status, {"error": {"code": code, "message": message}})


def actor_info(event):
    claims = ((event.get("requestContext") or {}).get("authorizer") or {}).get("claims") or {}
    if not isinstance(claims, dict):
        return (None, None)
    sub = claims.get("sub")
    raw = claims.get("cognito:groups", "")
    if not isinstance(sub, str) or not 1 <= len(sub) <= 150:
        return (None, None)
    if isinstance(raw, list):
        groups = set(x for x in raw if isinstance(x, str))
    elif isinstance(raw, str):
        groups = set(re.findall(r"[A-Za-z][A-Za-z0-9_-]*", raw))
    else:
        groups = set()
    role = "INVENTORY" if "INVENTORY" in groups else "ADMIN" if "ADMIN" in groups else None
    return sub, role


def number(x, label, *, positive=False, min_value=Decimal("0"), max_value=Decimal("1000000"), precision=3):
    # json.loads(parse_float=Decimal) avoids floating-point errors.
    if isinstance(x, bool) or not isinstance(x, (int, Decimal)):
        raise ValueError(label + " must be a JSON number")
    d = Decimal(str(x))
    if not d.is_finite() or d < min_value or d > max_value or (positive and d <= 0):
        raise ValueError(label + " is out of range")
    if d.as_tuple().exponent < -precision:
        raise ValueError(label + " has too many decimal places")
    return d


def parse_body(event):
    if event.get("isBase64Encoded"):
        raise ValueError("Base64 request bodies are not supported")
    body = event.get("body")
    if not isinstance(body, str) or len(body.encode("utf-8")) > 12000:
        raise ValueError("Invalid JSON body size")
    data = json.loads(body, parse_float=Decimal, parse_int=int)
    if not isinstance(data, dict):
        raise ValueError("Request body must be a JSON object")
    return data


def parse_cursor(params, key_field):
    cursor = (params or {}).get("cursor")
    if not cursor:
        return None
    if not isinstance(cursor, str) or len(cursor) > 1024:
        raise ValueError("Invalid cursor")
    pad = "=" * ((4 - len(cursor) % 4) % 4)
    decoded = json.loads(base64.urlsafe_b64decode(cursor + pad).decode("utf-8"))
    if not isinstance(decoded, dict) or set(decoded) != {key_field} or not isinstance(decoded[key_field], str):
        raise ValueError("Invalid cursor")
    return decoded


def next_cursor(last_key):
    if not last_key:
        return None
    payload = json.dumps(last_key, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(payload).decode("ascii").rstrip("=")


def list_ingredients(params):
    limit = int((params or {}).get("limit", "50"))
    if not 1 <= limit <= 100:
        raise ValueError("limit must be 1-100")
    kwargs = {"Limit": limit, "ConsistentRead": True}
    start = parse_cursor(params, "ingredient_id")
    if start:
        kwargs["ExclusiveStartKey"] = start
    result = ING.scan(**kwargs)
    entries = []
    for i in result.get("Items", []):
        stock = Decimal(str(i.get("stock_book", 0)))
        reserved = Decimal(str(i.get("reserved", 0)))
        available = max(Decimal("0"), stock - reserved)
        entries.append({
            "ingredient_id": i["ingredient_id"],
            "name": i.get("name", i["ingredient_id"]),
            "base_unit": i.get("base_unit", "unit"),
            "stock_book": float(stock),
            "reserved": float(reserved),
            "available": float(available),
            "stock_status": i.get("stock_status", "UNKNOWN"),
            "stockout_cascade_state": i.get("stockout_cascade_state"),
            "last_unit_cost_vnd": int(i.get("last_unit_cost_vnd", 0)),
            "min_stock_base": float(Decimal(str(i.get("min_stock_base", 0)))),
        })
    entries.sort(key=lambda i: i["name"].lower())
    return reply(200, {"items": entries, "next_cursor": next_cursor(result.get("LastEvaluatedKey"))})



def ensure_latest_meta():
    """Read the latest confirmed receipt pointer, backfilling existing deployments once.

    New receipts update the pointer in the same DynamoDB transaction that
    creates the receipt. This scan occurs only before the pointer exists.
    """
    item = CORRECTION_STATE.get_item(
        Key={"receipt_id": LATEST_RECEIPT_META_KEY}, ConsistentRead=True
    ).get("Item")
    if item:
        return item.get("latest_receipt_id")

    newest_id = None
    newest_key = None
    args = {"ConsistentRead": True, "ProjectionExpression": "receipt_id, confirmed_at, #st",
            "ExpressionAttributeNames": {"#st": "status"}}
    while True:
        page = RECEIPTS.scan(**args)
        for rec in page.get("Items", []):
            if rec.get("status") != "CONFIRMED":
                continue
            date = rec.get("confirmed_at", "")
            try:
                dt = datetime.fromisoformat(date.replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                key = (dt.timestamp(), rec["receipt_id"])
            except (TypeError, KeyError, ValueError, OverflowError):
                continue
            if newest_key is None or key > newest_key:
                newest_key, newest_id = key, rec["receipt_id"]
        if not page.get("LastEvaluatedKey"):
            break
        args["ExclusiveStartKey"] = page["LastEvaluatedKey"]

    if newest_id is None:
        return None

    try:
        CORRECTION_STATE.put_item(
            Item={"receipt_id": LATEST_RECEIPT_META_KEY,
                  "latest_receipt_id": newest_id,
                  "updated_at": datetime.now(timezone.utc).isoformat()},
            ConditionExpression="attribute_not_exists(receipt_id)",
        )
        return newest_id
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") != "ConditionalCheckFailedException":
            raise
        # A newer receipt may have committed while the initial scan ran.
        existing = CORRECTION_STATE.get_item(
            Key={"receipt_id": LATEST_RECEIPT_META_KEY}, ConsistentRead=True
        ).get("Item")
        return existing.get("latest_receipt_id") if existing else None


def receipt_to_public(i):
    return {
        "receipt_id": i["receipt_id"],
        "supplier_name": i.get("supplier_name", ""),
        "note": i.get("note", ""),
        "status": i.get("status", ""),
        "total_purchase_vnd": int(i.get("total_purchase_vnd", 0)),
        "actor_id": i.get("actor_id", ""),
        "confirmed_at": i.get("confirmed_at", ""),
        "items": [
            {"ingredient_id": line["ingredient_id"],
             "qty": float(Decimal(str(line["qty"]))),
             "unit": line["unit"],
             "unit_price_vnd": int(line["unit_price_vnd"]),
             "line_total_vnd": int(line["line_total_vnd"])}
            for line in i.get("items", [])
        ],
    }


def list_receipts(params):
    limit = int((params or {}).get("limit", "30"))
    if not 1 <= limit <= 100:
        raise ValueError("limit must be 1-100")
    kwargs = {"Limit": limit, "ConsistentRead": True}
    start = parse_cursor(params, "receipt_id")
    if start:
        kwargs["ExclusiveStartKey"] = start
    result = RECEIPTS.scan(**kwargs)
    records = [receipt_to_public(rec) for rec in result.get("Items", [])]

    latest_id = ensure_latest_meta()
    # DynamoDB Scan is not chronologically ordered. Ensure the actual latest
    # receipt is present even when the scanned page did not contain it.
    if latest_id and not any(r["receipt_id"] == latest_id for r in records):
        latest_item = RECEIPTS.get_item(
            Key={"receipt_id": latest_id}, ConsistentRead=True
        ).get("Item")
        if latest_item:
            records.append(receipt_to_public(latest_item))
    # Original receipt records are immutable. A correction updates the separate
    # ReceiptCorrectionState item, NOT InventoryReceipts, so list views must
    # overlay that effective state. Strong reads make a successful correction
    # visible immediately after a frontend refresh. Keep original values in
    # explicit fields for financial audit. No new IAM action is required:
    # GetItem on ReceiptCorrectionState is already used by correction endpoints.
    for rec in records:
        state = CORRECTION_STATE.get_item(
            Key={"receipt_id": rec["receipt_id"]}, ConsistentRead=True
        ).get("Item")
        rec["original_total_purchase_vnd"] = rec["total_purchase_vnd"]
        rec["is_corrected"] = False
        rec["correction_count"] = 0
        if not state or "corrected_total_vnd" not in state:
            continue
        effective_quantities = state.get("line_qty") or {}
        effective_amounts = state.get("line_amount_vnd") or {}
        for line in rec["items"]:
            ingredient_id = line["ingredient_id"]
            line["original_qty"] = line["qty"]
            line["original_line_total_vnd"] = line["line_total_vnd"]
            if ingredient_id in effective_quantities:
                line["qty"] = float(Decimal(str(effective_quantities[ingredient_id])))
            if ingredient_id in effective_amounts:
                line["line_total_vnd"] = int(effective_amounts[ingredient_id])
        rec["total_purchase_vnd"] = int(state["corrected_total_vnd"])
        rec["correction_count"] = int(state.get("version", 1))
        rec["is_corrected"] = True
    records.sort(key=lambda r: r["confirmed_at"], reverse=True)
    return reply(200, {
        "items": records,
        "next_cursor": next_cursor(result.get("LastEvaluatedKey")),
        "latest_receipt_id": latest_id,
    })


def previous_receipt(scope, key, payload_hash):
    existing = IDEM.get_item(Key={"scope": scope, "key": key}, ConsistentRead=True).get("Item")
    if not existing:
        return None
    if existing.get("payload_hash") != payload_hash:
        return error(409, "IDEMPOTENCY_CONFLICT", "Khóa này đã dùng cho nội dung phiếu khác")
    return reply(201, json.loads(existing["result_json"]))


def create_receipt(event, actor, role):
    headers = {str(k).lower(): v for k, v in (event.get("headers") or {}).items()}
    key = headers.get("idempotency-key")
    if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z0-9._:-]{8,128}", key):
        return error(400, "INVALID_IDEMPOTENCY_KEY", "Cần Idempotency-Key gồm 8–128 ký tự")

    try:
        body = parse_body(event)
        supplier = body.get("supplier_name")
        note = body.get("note", "")
        lines = body.get("items")
        if (not isinstance(supplier, str) or not 1 <= len(supplier.strip()) <= 100
                or not isinstance(note, str) or len(note) > 300
                or not isinstance(lines, list) or not 1 <= len(lines) <= 10):
            raise ValueError("Supplier, note or items invalid")

        normalized = []
        seen = set()
        for i in lines:
            if not isinstance(i, dict):
                raise ValueError("Invalid receipt line")
            ing_id, unit = i.get("ingredient_id"), i.get("unit")
            if (not isinstance(ing_id, str) or not re.fullmatch(r"I[A-Za-z0-9_-]{1,40}", ing_id)
                    or ing_id in seen or not isinstance(unit, str) or len(unit) > 16):
                raise ValueError("Duplicate or invalid ingredient")
            seen.add(ing_id)
            qty = number(i.get("qty"), "qty", positive=True, min_value=Decimal("0.001"), max_value=Decimal("100000"))
            price = number(i.get("unit_price_vnd"), "unit_price_vnd", min_value=Decimal("0"), max_value=Decimal("1000000000"), precision=0)
            normalized.append({"ingredient_id": ing_id, "unit": unit, "qty": qty, "unit_price_vnd": int(price)})
        normalized.sort(key=lambda x: x["ingredient_id"])

    except (KeyError, ValueError, TypeError, InvalidOperation, OverflowError, json.JSONDecodeError) as exc:
        return error(400, "INVALID_REQUEST", str(exc))

    payload_hash = hashlib.sha256(json.dumps({
        "supplier_name": supplier.strip(), "note": note.strip(),
        "items": [{"ingredient_id": i["ingredient_id"], "unit": i["unit"],
                   "qty": str(i["qty"]), "unit_price_vnd": i["unit_price_vnd"]} for i in normalized],
    }, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()

    scope = "INVENTORY_RECEIPT#" + actor
    old = previous_receipt(scope, key, payload_hash)
    if old is not None:
        return old

    now = datetime.now(timezone.utc).isoformat()
    receipt_id = "RC" + hashlib.sha256((actor + ":" + key).encode("utf-8")).hexdigest()[:24].upper()
    total = 0
    tx = []
    receipt_lines = []
    for i in normalized:
        ing_id = i["ingredient_id"]
        existing = ING.get_item(Key={"ingredient_id": ing_id}, ConsistentRead=True).get("Item")
        if not existing:
            return error(409, "INGREDIENT_NOT_FOUND", "Không tìm thấy nguyên liệu " + ing_id)
        if existing.get("base_unit") != i["unit"]:
            return error(409, "UNIT_MISMATCH", "Đơn vị không trùng với đơn vị gốc: " + ing_id)

        state = existing.get("stock_status")
        if state not in ("IN_STOCK", "LOW", "OUT_OF_STOCK"):
            return error(409, "INVALID_STOCK_STATE", "Trạng thái kho không hợp lệ: " + ing_id)
        if state == "OUT_OF_STOCK" and existing.get("stockout_cascade_state") not in (None, "DONE"):
            return error(409, "STOCKOUT_PROCESSING", "Chưa hoàn tất xử lý món bị từ chối: " + ing_id)
        try:
            old_stock = Decimal(str(existing["stock_book"]))
            old_res = Decimal(str(existing["reserved"]))
            old_cost = Decimal(str(existing.get("last_unit_cost_vnd", 0)))
            threshold = Decimal(str(existing.get("min_stock_base", 0)))
            if (not all(x.is_finite() for x in (old_stock, old_res, old_cost, threshold))
                    or old_stock < 0 or old_res < 0 or old_cost < 0 or threshold < 0
                    or (state == "OUT_OF_STOCK" and old_res != 0)
                    or (state != "OUT_OF_STOCK" and old_stock < old_res)):
                raise ValueError()
        except (ValueError, KeyError, InvalidOperation):
            return error(409, "INVALID_STOCK_DATA", "Dữ liệu kho không hợp lệ: " + ing_id)

        new_stock = old_stock + i["qty"]
        available = new_stock - old_res
        new_state = "LOW" if threshold > 0 and available <= threshold else "IN_STOCK"
        line_total = int((i["qty"] * Decimal(i["unit_price_vnd"])).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        total += line_total
        receipt_lines.append({**i, "line_total_vnd": line_total})

        names = {"#stock": "stock_book", "#res": "reserved", "#state": "stock_status",
                 "#cost": "last_unit_cost_vnd", "#ver": "version"}
        values = attrs({":qty": i["qty"], ":old_stock": old_stock, ":old_res": old_res,
                        ":old_state": state, ":new_state": new_state, ":price": Decimal(i["unit_price_vnd"]),
                        ":now": now, ":zero": Decimal("0"), ":one": Decimal("1"),
                        ":unit": i["unit"]})
        if "last_unit_cost_vnd" in existing:
            cost_check = "#cost = :old_cost"
            values[":old_cost"] = attr(old_cost)
        else:
            cost_check = "attribute_not_exists(#cost)"
        cascade_check = ""
        if state == "OUT_OF_STOCK":
            cascade_check = " AND #res = :zero AND (attribute_not_exists(stockout_cascade_state) OR stockout_cascade_state = :done)"
            values[":done"] = attr("DONE")
        tx.append({"Update": {
            "TableName": NAMES["ingredients"], "Key": attrs({"ingredient_id": ing_id}),
            "UpdateExpression": ("SET #stock = #stock + :qty, #cost = :price, #state = :new_state, "
                                 "updated_at = :now, #ver = if_not_exists(#ver, :zero) + :one"),
            "ConditionExpression": ("attribute_exists(ingredient_id) AND #stock = :old_stock "
                                    "AND #res = :old_res AND #state = :old_state AND base_unit = :unit AND "
                                    + cost_check + cascade_check),
            "ExpressionAttributeNames": names,
            "ExpressionAttributeValues": values,
        }})
        tx.append({"Put": {
            "TableName": NAMES["movements"],
            "Item": attrs({"movement_id": "MV#RECEIPT#" + receipt_id + "#" + ing_id,
                           "receipt_id": receipt_id, "ingredient_id": ing_id,
                           "reason": "INVENTORY_RECEIPT", "qty_delta_base": i["qty"],
                           "unit_cost_snapshot_vnd": Decimal(i["unit_price_vnd"]),
                           "total_cost_vnd": Decimal(line_total),
                           "actor_id": actor, "created_at": now}),
            "ConditionExpression": "attribute_not_exists(movement_id)",
        }})

    result = {"receipt_id": receipt_id, "status": "CONFIRMED", "total_purchase_vnd": total,
              "notification_status": "PENDING", "confirmed_at": now}
    tx.extend([
        {"Put": {"TableName": NAMES["receipts"],
                 "Item": attrs({"receipt_id": receipt_id, "supplier_name": supplier.strip(),
                                "note": note.strip(), "status": "CONFIRMED",
                                "total_purchase_vnd": Decimal(total), "items": receipt_lines,
                                "actor_id": actor, "confirmed_at": now}),
                 "ConditionExpression": "attribute_not_exists(receipt_id)"}},
        {"Put": {"TableName": NAMES["finance"],
                 "Item": attrs({"entry_id": "FL#RECEIPT#" + receipt_id,
                                "entry_type": "PURCHASE_EXPENSE", "amount_vnd": Decimal(total),
                                "business_date": datetime.now(timezone.utc).astimezone(__import__('zoneinfo').ZoneInfo('Asia/Ho_Chi_Minh')).date().isoformat(),
                                "reference_id": receipt_id, "created_at": now}),
                 "ConditionExpression": "attribute_not_exists(entry_id)"}},
        {"Put": {"TableName": NAMES["audit"],
                 "Item": attrs({"audit_id": "AUD#RECEIPT#" + receipt_id,
                                "timestamp": now, "actor_id": actor, "actor_role": role,
                                "action": "INVENTORY_RECEIPT_CONFIRMED", "resource_type": "INVENTORY_RECEIPT",
                                "resource_id": receipt_id, "total_purchase_vnd": Decimal(total),
                                "item_count": len(receipt_lines)}),
                 "ConditionExpression": "attribute_not_exists(audit_id)"}},
        {"Put": {"TableName": NAMES["outbox"],
                 "Item": attrs({"event_id": "EV#RECEIPT#" + receipt_id,
                                "type": "INVENTORY_RECEIPT_CONFIRMED",
                                "reference_id": receipt_id, "actor_id": actor,
                                "total_purchase_vnd": Decimal(total), "status": "PENDING",
                                "retries": 0, "created_at": now}),
                 "ConditionExpression": "attribute_not_exists(event_id)"}},
        {"Put": {"TableName": NAMES["idempotency"],
                 "Item": attrs({"scope": scope, "key": key,
                                "payload_hash": payload_hash,
                                "result_json": json.dumps(result, ensure_ascii=False),
                                "created_at": now, "ttl": int(time.time()) + 7 * 86400}),
                 "ConditionExpression": "attribute_not_exists(#scope) AND attribute_not_exists(#key)",
                 "ExpressionAttributeNames": {"#scope": "scope", "#key": "key"}}},
    ])
    # Serialize new receipts against corrections. No manual metadata setup is
    # required for new installs: Update creates the singleton if absent.
    tx.append({"Update": {
        "TableName": NAMES["correction_state"],
        "Key": attrs({"receipt_id": LATEST_RECEIPT_META_KEY}),
        "UpdateExpression": "SET latest_receipt_id = :new, updated_at = :now",
        "ExpressionAttributeValues": attrs({":new": receipt_id, ":now": now}),
    }})
    if len(tx) > 100:
        return error(400, "RECEIPT_TOO_LARGE", "Phiếu nhập vượt giới hạn transaction")
    try:
        client.transact_write_items(TransactItems=tx)
        return reply(201, result)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "Unknown")
        print("DynamoDB transaction error:", code)
        if code in ("TransactionCanceledException", "TransactionInProgressException", "IdempotentParameterMismatchException"):
            old = previous_receipt(scope, key, payload_hash)
            if old is not None:
                return old
            return error(409, "RECEIPT_CONFLICT", "Dữ liệu kho thay đổi; tải lại và thử lại")
        return error(500, "INTERNAL_SERVER_ERROR", "Không thể lưu phiếu nhập")



def list_corrections(receipt_id, params):
    """Return separate, immutable corrections; never mutate the original receipt."""
    receipt = RECEIPTS.get_item(Key={"receipt_id": receipt_id}, ConsistentRead=True).get("Item")
    if not receipt:
        return error(404, "RECEIPT_NOT_FOUND", "Không tìm thấy phiếu nhập")
    limit = int((params or {}).get("limit", "30"))
    if not 1 <= limit <= 100:
        raise ValueError("limit must be 1-100")
    # Receipt ID partition avoids a scan; no GSI required.
    result = CORRECTIONS.query(
        KeyConditionExpression=Key("receipt_id").eq(receipt_id),
        ConsistentRead=True, Limit=limit, ScanIndexForward=False,
    )
    entries = []
    for row in result.get("Items", []):
        entries.append({
            "correction_id": row["correction_id"],
            "receipt_id": row["receipt_id"],
            "reason": row.get("reason", ""),
            "actor_id": row.get("actor_id", ""),
            "created_at": row.get("created_at", ""),
            "amount_delta_vnd": int(row.get("amount_delta_vnd", 0)),
            "items": [{"ingredient_id": i["ingredient_id"],
                       "quantity_delta_base": float(i["quantity_delta_base"]),
                       "purchase_amount_delta_vnd": int(i["purchase_amount_delta_vnd"])}
                      for i in row.get("items", [])],
        })
    state = CORRECTION_STATE.get_item(Key={"receipt_id": receipt_id}, ConsistentRead=True).get("Item")
    corrected_total = int(state["corrected_total_vnd"]) if state else int(receipt.get("total_purchase_vnd", 0))
    return reply(200, {"items": entries, "original_total_vnd": int(receipt.get("total_purchase_vnd",0)),
                       "corrected_total_vnd": corrected_total})


def create_correction(event, receipt_id, actor, role):
    headers = {str(k).lower(): v for k, v in (event.get("headers") or {}).items()}
    key = headers.get("idempotency-key")
    if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z0-9._:-]{8,128}", key):
        return error(400, "INVALID_IDEMPOTENCY_KEY", "Cần Idempotency-Key từ 8 đến 128 ký tự")

    try:
        data = parse_body(event)
        reason = data.get("reason", "")
        raw_items = data.get("items")
        if (not isinstance(reason, str) or not 5 <= len(reason.strip()) <= 300
                or not isinstance(raw_items, list) or not 1 <= len(raw_items) <= 10):
            raise ValueError("Yêu cầu lý do 5-300 ký tự và 1-10 dòng điều chỉnh")
        normalized = []
        seen = set()
        for row in raw_items:
            if not isinstance(row, dict):
                raise ValueError("Dòng điều chỉnh không hợp lệ")
            ing_id = row.get("ingredient_id")
            if (not isinstance(ing_id, str) or not re.fullmatch(r"I[A-Za-z0-9_-]{1,40}", ing_id)
                    or ing_id in seen):
                raise ValueError("Nguyên liệu trùng hoặc không hợp lệ")
            seen.add(ing_id)
            qty = number(row.get("quantity_delta_base"), "quantity_delta_base",
                         min_value=Decimal("-100000"), max_value=Decimal("100000"))
            amount = number(row.get("purchase_amount_delta_vnd"), "purchase_amount_delta_vnd",
                            min_value=Decimal("-1000000000"), max_value=Decimal("1000000000"), precision=0)
            if qty == 0 and amount == 0:
                raise ValueError("Mỗi dòng phải thay đổi số lượng hoặc số tiền")
            normalized.append({"ingredient_id": ing_id, "quantity_delta_base": qty,
                               "purchase_amount_delta_vnd": int(amount)})
        normalized.sort(key=lambda i: i["ingredient_id"])
    except (KeyError, ValueError, TypeError, InvalidOperation, json.JSONDecodeError) as exc:
        return error(400, "INVALID_REQUEST", str(exc))

    payload_hash = hashlib.sha256(json.dumps({
        "receipt_id": receipt_id,
        "reason": reason.strip(),
        "items": [{"ingredient_id": x["ingredient_id"],
                   "quantity_delta_base": str(x["quantity_delta_base"]),
                   "purchase_amount_delta_vnd": x["purchase_amount_delta_vnd"]} for x in normalized],
    }, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    scope = "INVENTORY_CORRECTION#" + actor + "#" + receipt_id
    old = previous_receipt(scope, key, payload_hash)
    if old is not None:
        return old

    latest_id = ensure_latest_meta()
    if not latest_id:
        return error(409, "LATEST_RECEIPT_UNAVAILABLE", "Chưa có phiếu nhập gần nhất hợp lệ")
    if receipt_id != latest_id:
        return error(409, "NOT_LATEST_RECEIPT", "Chỉ được điều chỉnh phiếu nhập gần nhất: " + latest_id)

    receipt = RECEIPTS.get_item(Key={"receipt_id": receipt_id}, ConsistentRead=True).get("Item")
    if not receipt or receipt.get("status") != "CONFIRMED":
        return error(404, "RECEIPT_NOT_FOUND", "Không tìm thấy phiếu nhập đã xác nhận")
    original = {i["ingredient_id"]: i for i in receipt.get("items", [])}
    if any(x["ingredient_id"] not in original for x in normalized):
        return error(400, "INGREDIENT_NOT_IN_RECEIPT", "Nguyên liệu không thuộc phiếu nhập gốc")

    # This separate state item serializes corrections for the same receipt without
    # editing the original receipt and prevents cumulative negative quantities/costs.
    state = CORRECTION_STATE.get_item(Key={"receipt_id": receipt_id}, ConsistentRead=True).get("Item")
    if state:
        prev_version = int(state["version"])
        balances = {i: Decimal(str(q)) for i, q in state["line_qty"].items()}
        amounts = {i: int(a) for i, a in state["line_amount_vnd"].items()}
    else:
        prev_version = 0
        balances = {i: Decimal(str(row["qty"])) for i, row in original.items()}
        amounts = {i: int(row["line_total_vnd"]) for i, row in original.items()}

    for line in normalized:
        ing_id = line["ingredient_id"]
        balances[ing_id] += line["quantity_delta_base"]
        amounts[ing_id] += line["purchase_amount_delta_vnd"]
        if balances[ing_id] < 0 or amounts[ing_id] < 0:
            return error(409, "CORRECTION_EXCEEDS_RECEIPT", "Điều chỉnh vượt quá số lượng hoặc tiền của phiếu")
    total_amount = sum(amounts.values())
    if total_amount < 0:
        return error(409, "INVALID_CORRECTED_TOTAL", "Tổng tiền phiếu sau điều chỉnh không thể âm")

    now = datetime.now(timezone.utc).isoformat()
    correction_id = "CRX#" + now + "#" + hashlib.sha256((actor + ":" + receipt_id + ":" + key).encode()).hexdigest()[:16].upper()
    delta_total = sum(x["purchase_amount_delta_vnd"] for x in normalized)
    tx = [{"ConditionCheck": {
        "TableName": NAMES["correction_state"],
        "Key": attrs({"receipt_id": LATEST_RECEIPT_META_KEY}),
        "ConditionExpression": "latest_receipt_id = :expected",
        "ExpressionAttributeValues": attrs({":expected": receipt_id}),
    }}]
    for line in normalized:
        ing_id, delta = line["ingredient_id"], line["quantity_delta_base"]
        if delta == 0:
            continue  # Money-only corrections do not affect live inventory.
        old_ing = ING.get_item(Key={"ingredient_id": ing_id}, ConsistentRead=True).get("Item")
        if not old_ing:
            return error(409, "INGREDIENT_NOT_FOUND", "Nguyên liệu không còn tồn tại: " + ing_id)
        if old_ing.get("stock_status") == "OUT_OF_STOCK" or old_ing.get("stockout_cascade_state") == "PENDING":
            return error(409, "STOCKOUT_PROCESSING", "Không điều chỉnh số lượng nguyên liệu OUT_OF_STOCK/PENDING")
        old_stock = Decimal(str(old_ing.get("stock_book", 0)))
        reserved = Decimal(str(old_ing.get("reserved", 0)))
        threshold = Decimal(str(old_ing.get("min_stock_base", 0)))
        new_stock = old_stock + delta
        if new_stock < reserved or new_stock < 0:
            return error(409, "STOCK_CONFLICT", "Số lượng sau điều chỉnh thấp hơn reserved: " + ing_id)
        # LOW at zero avoids falsely starting the physical stock-out/loss workflow.
        status_new = "LOW" if (new_stock - reserved <= threshold or new_stock == 0) else "IN_STOCK"
        values = attrs({":prev": old_stock, ":res": reserved, ":state": old_ing.get("stock_status"),
                        ":new": new_stock, ":new_state": status_new, ":now": now,
                        ":zero": Decimal("0"), ":one": Decimal("1"), ":done": "DONE"})
        tx.append({"Update": {
            "TableName": NAMES["ingredients"],
            "Key": attrs({"ingredient_id": ing_id}),
            "UpdateExpression": "SET #stock = :new, #state = :new_state, updated_at = :now, #ver = if_not_exists(#ver, :zero) + :one",
            "ConditionExpression": "attribute_exists(ingredient_id) AND #stock = :prev AND #res = :res AND #state = :state AND (attribute_not_exists(stockout_cascade_state) OR stockout_cascade_state = :done)",
            "ExpressionAttributeNames": {"#stock": "stock_book", "#res": "reserved", "#state": "stock_status", "#ver": "version"},
            "ExpressionAttributeValues": values,
        }})
        tx.append({"Put": {
            "TableName": NAMES["movements"],
            "Item": attrs({"movement_id": "MV#CORRECTION#" + correction_id + "#" + ing_id,
                           "receipt_id": receipt_id, "correction_id": correction_id,
                           "ingredient_id": ing_id, "reason": "INVENTORY_RECEIPT_CORRECTION",
                           "qty_delta_base": delta,
                           "purchase_amount_delta_vnd": Decimal(line["purchase_amount_delta_vnd"]),
                           "actor_id": actor, "created_at": now}),
            "ConditionExpression": "attribute_not_exists(movement_id)",
        }})

    state_item = {"receipt_id": receipt_id, "version": Decimal(prev_version+1),
                  "line_qty": balances, "line_amount_vnd": {k: Decimal(v) for k,v in amounts.items()},
                  "corrected_total_vnd": Decimal(total_amount), "updated_at": now}
    if state:
        tx.append({"Update": {
            "TableName": NAMES["correction_state"],
            "Key": attrs({"receipt_id": receipt_id}),
            "UpdateExpression": "SET #ver = :next, line_qty = :qty, line_amount_vnd = :amount, corrected_total_vnd = :total, updated_at = :now",
            "ConditionExpression": "#ver = :prev",
            "ExpressionAttributeNames": {"#ver": "version"},
            "ExpressionAttributeValues": attrs({":next": Decimal(prev_version+1), ":qty": balances,
                                               ":amount": {k:Decimal(v) for k,v in amounts.items()},
                                               ":total": Decimal(total_amount), ":now": now,
                                               ":prev": Decimal(prev_version)}),
        }})
    else:
        tx.append({"Put": {
            "TableName": NAMES["correction_state"],
            "Item": attrs(state_item),
            "ConditionExpression": "attribute_not_exists(receipt_id)",
        }})

    result = {"correction_id": correction_id, "receipt_id": receipt_id,
              "status": "CONFIRMED", "amount_delta_vnd": delta_total,
              "corrected_total_vnd": total_amount, "created_at": now,
              "notification_status": "PENDING"}
    business_date = datetime.now(timezone.utc).astimezone(
        __import__('zoneinfo').ZoneInfo('Asia/Ho_Chi_Minh')).date().isoformat()
    tx.extend([
        {"Put": {"TableName": NAMES["corrections"],
                 "Item": attrs({"receipt_id": receipt_id, "correction_id": correction_id,
                                "reason": reason.strip(), "items": normalized,
                                "actor_id": actor, "actor_role": role, "created_at": now,
                                "amount_delta_vnd": Decimal(delta_total),
                                "corrected_total_vnd": Decimal(total_amount)}),
                 "ConditionExpression": "attribute_not_exists(receipt_id)"}},
        {"Put": {"TableName": NAMES["finance"],
                 "Item": attrs({"entry_id": "FL#CORRECTION#" + correction_id,
                                "entry_type": "PURCHASE_EXPENSE_ADJUSTMENT",
                                "amount_vnd": Decimal(delta_total), "business_date": business_date,
                                "reference_id": receipt_id, "correction_id": correction_id,
                                "created_at": now}),
                 "ConditionExpression": "attribute_not_exists(entry_id)"}},
        {"Put": {"TableName": NAMES["audit"],
                 "Item": attrs({"audit_id": "AUD#CORRECTION#" + correction_id,
                                "timestamp": now, "actor_id": actor, "actor_role": role,
                                "action": "INVENTORY_RECEIPT_CORRECTED", "resource_type": "INVENTORY_RECEIPT",
                                "resource_id": receipt_id, "correction_id": correction_id,
                                "reason": reason.strip(), "items": normalized}),
                 "ConditionExpression": "attribute_not_exists(audit_id)"}},
        {"Put": {"TableName": NAMES["outbox"],
                 "Item": attrs({"event_id": "EV#CORRECTION#" + correction_id,
                                "type": "INVENTORY_RECEIPT_CORRECTED",
                                "reference_id": receipt_id, "correction_id": correction_id,
                                "actor_id": actor, "status": "PENDING", "retries": Decimal(0),
                                "created_at": now}),
                 "ConditionExpression": "attribute_not_exists(event_id)"}},
        {"Put": {"TableName": NAMES["idempotency"],
                 "Item": attrs({"scope": scope, "key": key, "payload_hash": payload_hash,
                                "result_json": json.dumps(result, ensure_ascii=False),
                                "created_at": now, "ttl": int(time.time()) + 7*86400}),
                 "ConditionExpression": "attribute_not_exists(#scope) AND attribute_not_exists(#key)",
                 "ExpressionAttributeNames": {"#scope": "scope", "#key": "key"}}},
    ])
    try:
        client.transact_write_items(TransactItems=tx)
        return reply(201, result)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "Unknown")
        print("Correction transaction error:", code)
        if code in ("TransactionCanceledException", "TransactionInProgressException"):
            old = previous_receipt(scope, key, payload_hash)
            if old is not None:
                return old
            if ensure_latest_meta() != receipt_id:
                return error(409, "NOT_LATEST_RECEIPT", "Phiếu này không còn là phiếu nhập gần nhất")
            return error(409, "CORRECTION_CONFLICT", "Dữ liệu kho/phiếu đã thay đổi; tải lại rồi thử lại")
        return error(500, "INTERNAL_SERVER_ERROR", "Không thể lưu phiếu điều chỉnh")


# Inventory stock count addon (no restaurant open/close state).

class CountConflict(Exception):
    pass

COUNT_TABLE = "SecureTable-InventoryCounts"
BILL_TABLE = "SecureTable-Bills"
ORDER_ITEM_TABLE = "SecureTable-OrderItems"
COUNTS = resource.Table(COUNT_TABLE)


def scan_every(table, projection=None, name_map=None):
    """Strongly consistent table scan: no arbitrary first-page success."""
    kwargs = {"ConsistentRead": True}
    if projection:
        kwargs["ProjectionExpression"] = projection
    if name_map:
        kwargs["ExpressionAttributeNames"] = name_map
    while True:
        response = table.scan(**kwargs)
        yield from response.get("Items", [])
        if not response.get("LastEvaluatedKey"):
            break
        kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]


def readiness():
    """Eligibility preflight: no restaurant OPEN/CLOSED state is required.

    This scan does not lock concurrent bill creation or new orders.
    """
    issues = []
    bills = resource.Table(BILL_TABLE)
    for bill in scan_every(bills, "bill_id,#st", {"#st": "status"}):
        if str(bill.get("status", "")).upper() in ("OPEN", "CLOSING"):
            issues.append("Còn bill đang OPEN/CLOSING (ví dụ: %s)" % bill.get("bill_id", "?"))
            break
    order_items = resource.Table(ORDER_ITEM_TABLE)
    for order in scan_every(order_items, "item_id,#st", {"#st": "status"}):
        if str(order.get("status", "")).upper() in ("ORDERED", "PENDING", "PROCESSING"):
            issues.append("Còn món chưa hoàn tất (ví dụ: %s)" % order.get("item_id", "?"))
            break
    return issues


def count_inputs(data):
    items = data.get("items")
    note = data.get("note", "")
    counted_at = data.get("counted_at")
    if not isinstance(note, str) or len(note) > 300 or not isinstance(items, list) or not 1 <= len(items) <= 40:
        raise ValueError("Cần 1–40 nguyên liệu và ghi chú không quá 300 ký tự")
    if not isinstance(counted_at, str) or len(counted_at) > 40:
        raise ValueError("counted_at phải là thời gian ISO-8601")
    try:
        dt = datetime.fromisoformat(counted_at.replace("Z", "+00:00"))
    except ValueError:
        raise ValueError("counted_at không phải ISO-8601")
    if dt.tzinfo is None or abs((datetime.now(timezone.utc) - dt.astimezone(timezone.utc)).total_seconds()) > 86400:
        raise ValueError("counted_at phải có múi giờ và nằm trong 24 giờ gần nhất")
    normalized = {}
    for row in items:
        if not isinstance(row, dict):
            raise ValueError("Dòng kiểm kê không hợp lệ")
        ing_id = row.get("ingredient_id")
        if not isinstance(ing_id, str) or not re.fullmatch(r"I[A-Za-z0-9_-]{1,40}", ing_id) or ing_id in normalized:
            raise ValueError("ID nguyên liệu trùng hoặc không hợp lệ")
        normalized[ing_id] = number(row.get("actual_qty_base"), "actual_qty_base", min_value=Decimal("0"), max_value=Decimal("1000000"), precision=3)
    return normalized, note.strip(), dt.astimezone(timezone.utc).isoformat()


def count_snapshot(actuals):
    existing = list(scan_every(ING))
    if len(existing) > 40:
        raise ValueError("Bản MVP hỗ trợ tối đa 40 nguyên liệu/phiếu; cần cơ chế kiểm kê nhiều kỳ cho kho lớn")
    found = {i["ingredient_id"]: i for i in existing}
    if set(found) != set(actuals):
        missing = sorted(set(found) - set(actuals))
        extra = sorted(set(actuals) - set(found))
        raise ValueError("Cần kiểm kê đủ toàn bộ nguyên liệu (thiếu: %s; không có trong kho: %s)" % (", ".join(missing), ", ".join(extra)))
    entries = []
    fingerprint_entries = []
    for ing_id in sorted(found):
        ing = found[ing_id]
        before = Decimal(str(ing.get("stock_book", 0)))
        reserved = Decimal(str(ing.get("reserved", 0)))
        threshold = Decimal(str(ing.get("min_stock_base", 0)))
        unit_cost = Decimal(str(ing.get("last_unit_cost_vnd", 0)))
        actual = actuals[ing_id]
        state = ing.get("stock_status", "UNKNOWN")
        cascade = ing.get("stockout_cascade_state")
        if not all(x.is_finite() for x in [before, reserved, threshold, unit_cost]) or min(before, reserved, threshold, unit_cost) < 0:
            raise ValueError("Dữ liệu kho không hợp lệ: " + ing_id)
        if reserved != 0 or cascade == "PENDING":
            raise CountConflict("Còn reserved hoặc stock-out chưa xử lý tại " + ing_id + "; hãy hoàn tất Kitchen trước")
        if state not in ("IN_STOCK", "LOW", "OUT_OF_STOCK"):
            raise CountConflict("Trạng thái nguyên liệu không hợp lệ: " + ing_id)
        diff = actual - before
        loss_val = int((-diff * unit_cost).quantize(Decimal('1'), rounding=ROUND_HALF_UP)) if diff < 0 else 0
        surplus_val = int((diff * unit_cost).quantize(Decimal('1'), rounding=ROUND_HALF_UP)) if diff > 0 else 0
        if actual == 0:
            new_status = "OUT_OF_STOCK"
        elif threshold > 0 and actual <= threshold:
            new_status = "LOW"
        else:
            new_status = "IN_STOCK"
        entry = {"ingredient_id": ing_id, "name": ing.get("name", ing_id), "unit": ing.get("base_unit", "unit"),
                 "book_qty": before, "actual_qty_base": actual, "difference_qty_base": diff,
                 "reserved": reserved, "stock_status_before": state, "stock_status_after": new_status,
                 "stockout_cascade_state": cascade, "unit_cost_snapshot_vnd": unit_cost,
                 "loss_value_estimated_vnd": loss_val, "surplus_value_estimated_vnd": surplus_val,
                 "min_stock_base": threshold}
        entries.append(entry)
        fingerprint_entries.append([ing_id, str(before), str(reserved), state, str(cascade),
                                    str(unit_cost), str(threshold), entry["unit"]])
    fingerprint = hashlib.sha256(json.dumps(fingerprint_entries, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
    return entries, fingerprint


def count_public(entry):
    return {k: (float(v) if isinstance(v, Decimal) and k in ('book_qty', 'actual_qty_base', 'difference_qty_base', 'reserved')
                else int(v) if isinstance(v, Decimal) and k == 'unit_cost_snapshot_vnd' else v)
            for k, v in entry.items() if k not in ('min_stock_base', 'stockout_cascade_state')}


def count_preview(event):
    data = parse_body(event)
    actuals, note, counted_at = count_inputs(data)
    try:
        entries, snapshot = count_snapshot(actuals)
    except CountConflict as exc:
        return error(409, "STOCK_NOT_READY", str(exc))
    blockers = readiness()
    return reply(200, {"items": [count_public(x) for x in entries], "snapshot_hash": snapshot,
                       "count_ready": not bool(blockers),
                       "restaurant_ready": not bool(blockers),  # deprecated UI compatibility
                       "blockers": blockers,
                       "loss_value_estimated_vnd": sum(x["loss_value_estimated_vnd"] for x in entries),
                       "surplus_value_estimated_vnd": sum(x["surplus_value_estimated_vnd"] for x in entries)})


def count_create(event, actor, role):
    headers = {str(k).lower(): v for k, v in (event.get("headers") or {}).items()}
    key = headers.get("idempotency-key")
    if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z0-9._:-]{8,128}", key):
        return error(400, "INVALID_IDEMPOTENCY_KEY", "Thiếu Idempotency-Key hợp lệ")
    data = parse_body(event)
    actuals, note, counted_at = count_inputs(data)
    sent_fingerprint = data.get("snapshot_hash")
    if not isinstance(sent_fingerprint, str) or not re.fullmatch(r"[a-f0-9]{64}", sent_fingerprint):
        return error(400, "PREVIEW_REQUIRED", "Phải xem trước kiểm kê rồi mới xác nhận")
    scope = "INVENTORY_COUNT#" + actor
    payload_hash = hashlib.sha256(json.dumps({"actuals": {k: str(v) for k, v in sorted(actuals.items())},
              "note": note, "counted_at": counted_at, "snapshot": sent_fingerprint}, sort_keys=True).encode()).hexdigest()
    duplicate = IDEM.get_item(Key={"scope": scope, "key": key}, ConsistentRead=True).get("Item")
    if duplicate:
        if duplicate.get("payload_hash") != payload_hash:
            return error(409, "IDEMPOTENCY_CONFLICT", "Khóa này đã dùng cho nội dung kiểm kê khác")
        return reply(201, json.loads(duplicate["result_json"]))
    try:
        entries, current_fingerprint = count_snapshot(actuals)
    except CountConflict as exc:
        return error(409, "STOCK_NOT_READY", str(exc))
    if sent_fingerprint != current_fingerprint:
        return error(409, "STOCK_CHANGED", "Tồn kho thay đổi sau lúc xem trước; tải lại và xem trước lần nữa")
    blockers = readiness()
    if blockers:
        return error(409, "COUNT_NOT_READY", "; ".join(blockers))

    now = datetime.now(timezone.utc).isoformat()
    count_id = "CNT" + hashlib.sha256((actor + ":" + key).encode()).hexdigest()[:24].upper()
    loss_total = sum(x["loss_value_estimated_vnd"] for x in entries)
    surplus_total = sum(x["surplus_value_estimated_vnd"] for x in entries)
    local_business_day = datetime.now(timezone.utc).astimezone(__import__('zoneinfo').ZoneInfo('Asia/Ho_Chi_Minh')).date().isoformat()
    response = {"count_id": count_id, "status": "CONFIRMED", "business_date": local_business_day,
                "loss_value_estimated_vnd": loss_total, "surplus_value_estimated_vnd": surplus_total,
                "ingredient_count": len(entries), "confirmed_at": now}
    tx = []
    for e in entries:
        old, new = e["book_qty"], e["actual_qty_base"]
        vals = attrs({":old": old, ":new": new, ":reserved": e["reserved"],
                      ":oldst": e["stock_status_before"], ":newst": e["stock_status_after"],
                      ":cost": e["unit_cost_snapshot_vnd"], ":threshold": e["min_stock_base"],
                      ":unit": e["unit"], ":now": now,
                      ":zero": Decimal(0), ":one": Decimal(1)})
        # Atomically compare every attribute that affects the preview result.
        cond = ("attribute_exists(ingredient_id) AND #stock = :old AND #reserved = :reserved "
                "AND #status = :oldst AND #cost = :cost AND "
                "#threshold = :threshold AND base_unit = :unit")
        names = {"#stock": "stock_book", "#reserved": "reserved", "#status": "stock_status",
                 "#cost": "last_unit_cost_vnd", "#threshold": "min_stock_base", "#version": "version"}
        # Older ingredient records may omit optional values. Treat absent as zero.
        if e["unit_cost_snapshot_vnd"] == 0:
            cond = cond.replace("#cost = :cost", "(attribute_not_exists(#cost) OR #cost = :cost)")
        if e["min_stock_base"] == 0:
            cond = cond.replace("#threshold = :threshold", "(attribute_not_exists(#threshold) OR #threshold = :threshold)")
        if e["stockout_cascade_state"] is None:
            cond += " AND attribute_not_exists(stockout_cascade_state)"
        else:
            cond += " AND stockout_cascade_state = :cascade"
            vals[":cascade"] = attr(e["stockout_cascade_state"])
        if old == new and e["stock_status_before"] == e["stock_status_after"]:
            # DynamoDB rejects unused names/values; ConditionCheck needs only
            # placeholders referenced in cond (unlike the Update branch).
            import re as _re
            active_names = {k: v for k, v in names.items() if k in set(_re.findall(r"#[A-Za-z0-9_]+", cond))}
            active_values = {k: v for k, v in vals.items() if k in set(_re.findall(r":[A-Za-z0-9_]+", cond))}
            tx.append({"ConditionCheck": {"TableName": NAMES["ingredients"],
                 "Key": attrs({"ingredient_id": e["ingredient_id"]}),
                 "ConditionExpression": cond, "ExpressionAttributeNames": active_names,
                 "ExpressionAttributeValues": active_values}})
        else:
            tx.append({"Update": {"TableName": NAMES["ingredients"],
                "Key": attrs({"ingredient_id": e["ingredient_id"]}),
                "UpdateExpression": ("SET #stock = :new, #status = :newst, "
                                     "updated_at = :now, #version = if_not_exists(#version, :zero) + :one"),
                "ConditionExpression": cond, "ExpressionAttributeNames": names,
                "ExpressionAttributeValues": vals}})
        if e["difference_qty_base"] != 0:
            tx.append({"Put": {"TableName": NAMES["movements"],
                "Item": attrs({"movement_id": "MV#COUNT#" + count_id + "#" + e["ingredient_id"],
                               "count_id": count_id, "ingredient_id": e["ingredient_id"],
                               "reason": "STOCK_COUNT_DISCREPANCY", "qty_delta_base": e["difference_qty_base"],
                               "loss_value_estimated_vnd": Decimal(e["loss_value_estimated_vnd"]),
                               "surplus_value_estimated_vnd": Decimal(e["surplus_value_estimated_vnd"]),
                               "unit_cost_snapshot_vnd": e["unit_cost_snapshot_vnd"],
                               "actor_id": actor, "created_at": now}),
                "ConditionExpression": "attribute_not_exists(movement_id)"}})
    tx.extend([
        {"Put": {"TableName": COUNT_TABLE, "Item": attrs({"count_id": count_id, "status": "CONFIRMED",
                  "actor_id": actor, "actor_role": role, "counted_at": counted_at, "confirmed_at": now,
                  "business_date": local_business_day, "note": note, "snapshot_hash": current_fingerprint,
                  "loss_value_estimated_vnd": Decimal(loss_total), "surplus_value_estimated_vnd": Decimal(surplus_total),
                  "items": [{"ingredient_id": x["ingredient_id"], "unit": x["unit"],
                             "book_qty": x["book_qty"], "actual_qty_base": x["actual_qty_base"],
                             "difference_qty_base": x["difference_qty_base"],
                             "unit_cost_snapshot_vnd": x["unit_cost_snapshot_vnd"],
                             "loss_value_estimated_vnd": Decimal(x["loss_value_estimated_vnd"]),
                             "surplus_value_estimated_vnd": Decimal(x["surplus_value_estimated_vnd"])} for x in entries]}),
             "ConditionExpression": "attribute_not_exists(count_id)"}},
        {"Put": {"TableName": NAMES["audit"], "Item": attrs({"audit_id": "AUD#COUNT#" + count_id,
                  "action": "STOCK_COUNT_CONFIRMED", "timestamp": now, "actor_id": actor,
                  "actor_role": role, "resource_type": "INVENTORY_COUNT", "resource_id": count_id,
                  "loss_value_estimated_vnd": Decimal(loss_total), "surplus_value_estimated_vnd": Decimal(surplus_total),
                  "items_changed": sum(1 for x in entries if x["difference_qty_base"] != 0)}),
             "ConditionExpression": "attribute_not_exists(audit_id)"}},
        {"Put": {"TableName": NAMES["outbox"], "Item": attrs({"event_id": "EV#COUNT#" + count_id,
                  "type": "STOCK_COUNT_CONFIRMED", "reference_id": count_id,
                  "actor_id": actor, "status": "PENDING", "retries": Decimal(0), "created_at": now}),
             "ConditionExpression": "attribute_not_exists(event_id)"}},
        {"Put": {"TableName": NAMES["idempotency"], "Item": attrs({"scope": scope, "key": key,
                  "payload_hash": payload_hash, "result_json": json.dumps(response), "created_at": now,
                  "ttl": int(time.time()) + 7 * 86400}),
             "ConditionExpression": "attribute_not_exists(#scope) AND attribute_not_exists(#key)",
             "ExpressionAttributeNames": {"#scope": "scope", "#key": "key"}}}
    ])
    if len(tx) > 100:
        return error(400, "COUNT_TOO_LARGE", "Kiểm kê vượt giới hạn giao dịch DynamoDB")
    try:
        client.transact_write_items(TransactItems=tx)
        return reply(201, response)
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "Unknown")
        print("Inventory count transaction:", code)
        if code in ("TransactionCanceledException", "TransactionInProgressException"):
            duplicate = IDEM.get_item(Key={"scope": scope, "key": key}, ConsistentRead=True).get("Item")
            if duplicate and duplicate.get("payload_hash") == payload_hash:
                return reply(201, json.loads(duplicate["result_json"]))
            return error(409, "STOCK_CHANGED", "Dữ liệu vừa thay đổi; tải lại rồi xem trước lại")
        return error(500, "COUNT_FAILED", "Không thể lưu kiểm kê")


def count_history(params):
    limit = int((params or {}).get("limit", "20"))
    if not 1 <= limit <= 50:
        raise ValueError("limit phải nằm trong 1–50")
    # MVP: small demo data. Replace scan with date GSI in higher-scale production.
    data = []
    for r in scan_every(COUNTS):
        data.append({"count_id": r["count_id"], "status": r.get("status"),
                     "business_date": r.get("business_date"), "confirmed_at": r.get("confirmed_at"),
                     "note": r.get("note", ""), "ingredient_count": len(r.get("items", [])),
                     "loss_value_estimated_vnd": int(r.get("loss_value_estimated_vnd", 0)),
                     "surplus_value_estimated_vnd": int(r.get("surplus_value_estimated_vnd", 0))})
    data.sort(key=lambda r: r["confirmed_at"], reverse=True)
    return reply(200, {"items": data[:limit]})

def lambda_handler(event, context):
    actor, role = actor_info(event)
    if not actor:
        return error(401, "UNAUTHORIZED", "Thiếu danh tính Cognito")
    if role is None:
        return error(403, "FORBIDDEN", "Không thuộc nhóm INVENTORY")

    route = event.get("resource") or event.get("path") or ""
    method = (event.get("httpMethod") or "").upper()
    path_params = event.get("pathParameters") or {}
    match = re.fullmatch(r"/v1/staff/inventory/receipts/\{receiptId\}/corrections", route)
    if not match:
        match = re.fullmatch(r"/v1/staff/inventory/receipts/([A-Za-z0-9_-]{2,100})/corrections", route)
    receipt_id = (path_params.get("receiptId") if "{" in route else (match.group(1) if match else None))
    if receipt_id is not None and not re.fullmatch(r"[A-Za-z0-9_-]{2,100}", str(receipt_id)):
        return error(400, "INVALID_RECEIPT_ID", "Mã phiếu không hợp lệ")
    try:
        if method == "POST" and route == "/v1/staff/inventory/counts/preview":
            return count_preview(event)
        if method == "POST" and route == "/v1/staff/inventory/counts":
            return count_create(event, actor, role)
        if method == "GET" and route == "/v1/staff/inventory/counts":
            return count_history(event.get("queryStringParameters"))
        if method == "GET" and route == "/v1/staff/ingredients":
            return list_ingredients(event.get("queryStringParameters"))
        if method == "GET" and route == "/v1/staff/inventory/receipts":
            return list_receipts(event.get("queryStringParameters"))
        if method == "POST" and route == "/v1/staff/inventory/receipts":
            return create_receipt(event, actor, role)
        if match and receipt_id and method == "POST":
            return create_correction(event, receipt_id, actor, role)
        if match and receipt_id and method == "GET":
            return list_corrections(receipt_id, event.get("queryStringParameters"))
        return error(404, "ROUTE_NOT_FOUND", "Inventory route không tồn tại")
    except (ValueError, TypeError, json.JSONDecodeError, UnicodeError) as exc:
        return error(400, "INVALID_QUERY", str(exc))
    except ClientError as exc:
        print("DynamoDB read error:", exc.response.get("Error", {}).get("Code", "Unknown"))
        return error(500, "INTERNAL_SERVER_ERROR", "Lỗi truy cập DynamoDB")
    except (KeyError, InvalidOperation, OverflowError) as exc:
        print("Invalid inventory data:", type(exc).__name__)
        return error(500, "INVALID_INVENTORY_DATA", "Dữ liệu nguyên liệu không hợp lệ")
