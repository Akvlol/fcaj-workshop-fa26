"""SecureTable Kitchen: queue, complete, reject, OUT_OF_STOCK fan-out.

API Gateway REST API Lambda-proxy; Cognito User Pool authorizer REQUIRED
on every /v1/staff/kitchen/* method (without OAuth scopes -> ID token).
This Lambda must never be exposed as an unauthenticated HTTP route.

All writes are transactional, item status transitions happen at most once.
OUT_OF_STOCK is marked atomically and cascaded by a DynamoDB Streams trigger.
Enable NEW_AND_OLD_IMAGES on SecureTable-Ingredients and attach it to this
Lambda. Failed stream batches must be retried; monitor IteratorAge/Errors.
"""
import base64
import json
import re
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

import boto3
from boto3.dynamodb.conditions import Key
from boto3.dynamodb.types import TypeSerializer
from botocore.exceptions import ClientError

REGION = "ap-southeast-1"
db = boto3.resource("dynamodb", region_name=REGION)
client = boto3.client("dynamodb", region_name=REGION)
serializer = TypeSerializer()

NAMES = {
    "items": "SecureTable-OrderItems",
    "bills": "SecureTable-Bills",
    "menu": "SecureTable-MenuItems",
    "ingredients": "SecureTable-Ingredients",
    "pending": "SecureTable-PendingByIngredient",
    "movements": "SecureTable-InventoryMovements",
    "audit": "SecureTable-AuditLogs",
}
items_table = db.Table(NAMES["items"])
bills_table = db.Table(NAMES["bills"])
menu_table = db.Table(NAMES["menu"])
ing_table = db.Table(NAMES["ingredients"])
pending_table = db.Table(NAMES["pending"])


def attr(value):
    return serializer.serialize(value)


def attrs(obj):
    return {k: attr(v) for k, v in obj.items()}


def reply(status, payload):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store",
        },
        "body": json.dumps(payload, ensure_ascii=False, default=str),
    }


def fail(http_status, code, message):
    return reply(http_status, {"error": {"code": code, "message": message}})


def authenticated_staff(event):
    """Only trust claims injected by an API Gateway Cognito Authorizer."""
    rc = event.get("requestContext") or {}
    claims = (rc.get("authorizer") or {}).get("claims") or {}
    if not isinstance(claims, dict):
        return None
    sub = claims.get("sub")
    if not isinstance(sub, str) or not sub or len(sub) > 150:
        return None
    raw_groups = claims.get("cognito:groups", "")
    if isinstance(raw_groups, list):
        groups = set(raw_groups)
    elif isinstance(raw_groups, str):
        groups = set(re.findall(r"[A-Za-z][A-Za-z0-9_-]*", raw_groups))
    else:
        groups = set()
    if not {"KITCHEN", "ADMIN"}.intersection(groups):
        return (sub, None, False)
    return (sub, "ADMIN" if "ADMIN" in groups else "KITCHEN", True)


def parse_body(event):
    if event.get("isBase64Encoded"):
        raise ValueError("Base64 request bodies are unsupported")
    body = event.get("body")
    if body is None or body == "":
        return {}
    if not isinstance(body, str) or len(body.encode("utf-8")) > 4096:
        raise ValueError("Invalid request body")
    parsed = json.loads(body)
    if not isinstance(parsed, dict):
        raise ValueError("Request body must be an object")
    return parsed


def get_pending_recipe(item):
    """Use Ordering's per-item pending records as source of reserved qty.

    Require current dish recipe to match those exact allocations; prevents
    corrupt stock deductions when someone edited a recipe while ORDERED.
    """
    dish = menu_table.get_item(
        Key={"dish_id": item["dish_id"]}, ConsistentRead=True
    ).get("Item")
    if not dish or not isinstance(dish.get("recipe"), list):
        raise ValueError("Current dish recipe not found")
    recipe = dish["recipe"]
    if not 1 <= len(recipe) <= 5:
        raise ValueError("Invalid dish recipe length")
    result = []
    seen = set()
    for component in recipe:
        if not isinstance(component, dict):
            raise ValueError("Invalid recipe component")
        ingredient_id = component.get("ingredient_id")
        if (not isinstance(ingredient_id, str)
                or not re.fullmatch(r"I[A-Za-z0-9_-]{1,40}", ingredient_id)
                or ingredient_id in seen):
            raise ValueError("Invalid or duplicate ingredient")
        seen.add(ingredient_id)
        quantity = Decimal(str(component.get("qty_base", "0")))
        if not quantity.is_finite() or quantity <= 0:
            raise ValueError("Invalid recipe quantity")
        pending = pending_table.get_item(Key={
            "ingredient_id": ingredient_id,
            "item_id": item["item_id"],
        }, ConsistentRead=True).get("Item")
        if (not pending or pending.get("bill_id") != item["bill_id"]
                or pending.get("order_id") != item["order_id"]
                or Decimal(str(pending.get("qty_base", "0"))) != quantity):
            raise ValueError("Recipe differs from the reserved allocations")
        result.append((ingredient_id, quantity, pending))
    return result, recipe


def get_ordered_item(item_id):
    item = items_table.get_item(
        Key={"item_id": item_id}, ConsistentRead=True
    ).get("Item")
    if not item:
        return None, fail(404, "ITEM_NOT_FOUND", "Order item not found")
    if item.get("status") != "ORDERED":
        return None, fail(409, "ITEM_ALREADY_PROCESSED", "Order item is no longer ORDERED")
    return item, None


def get_open_bill(item):
    bill = bills_table.get_item(
        Key={"bill_id": item["bill_id"]}, ConsistentRead=True
    ).get("Item")
    if not bill or bill.get("status") != "OPEN":
        return None, fail(409, "BILL_NOT_OPEN", "Bill is no longer OPEN")
    return bill, None


def tx_condition_bill(bill_id):
    return {"ConditionCheck": {
        "TableName": NAMES["bills"],
        "Key": attrs({"bill_id": bill_id}),
        "ConditionExpression": "#s = :open",
        "ExpressionAttributeNames": {"#s": "status"},
        "ExpressionAttributeValues": attrs({":open": "OPEN"}),
    }}


def available_ingredients_for_item(item):
    """Show the ingredients reserved by this ORDERED portion for stock-out UI."""
    try:
        allocations, _ = get_pending_recipe(item)
    except (ValueError, KeyError, InvalidOperation):
        return []
    output = []
    for ingredient_id, quantity, _ in allocations:
        ingredient = ing_table.get_item(
            Key={"ingredient_id": ingredient_id}, ConsistentRead=True
        ).get("Item") or {}
        output.append({
            "ingredient_id": ingredient_id,
            "name": str(ingredient.get("name") or ingredient_id),
            "qty_base": float(quantity),
        })
    return output


def queue(event):
    params = event.get("queryStringParameters") or {}
    try:
        limit = int(params.get("limit", "30"))
        if not 1 <= limit <= 50:
            raise ValueError()
        cursor = params.get("cursor")
        start_key = None
        if cursor:
            if not isinstance(cursor, str) or len(cursor) > 2048:
                raise ValueError()
            decoded = base64.b64decode(cursor, validate=True)
            start_key = json.loads(decoded.decode("utf-8"))
            if (not isinstance(start_key, dict)
                    or not all(isinstance(k, str) and isinstance(v, str)
                               for k, v in start_key.items())
                    or not {"item_id", "status", "created_at"}.issubset(start_key)):
                raise ValueError()
    except (ValueError, TypeError, UnicodeDecodeError, json.JSONDecodeError):
        return fail(400, "INVALID_CURSOR", "Invalid limit or pagination cursor")

    kwargs = {
        "IndexName": "status-created_at-index",
        "KeyConditionExpression": Key("status").eq("ORDERED"),
        "ScanIndexForward": True,
        "Limit": limit,
    }
    if start_key:
        kwargs["ExclusiveStartKey"] = start_key
    result = items_table.query(**kwargs)
    data = []
    bill_cache = {}
    for indexed_item in result.get("Items", []):
        # GSI is eventually consistent: re-check source table before display.
        live = items_table.get_item(
            Key={"item_id": indexed_item["item_id"]}, ConsistentRead=True
        ).get("Item")
        if not live or live.get("status") != "ORDERED":
            continue
        bill_id = live.get("bill_id")
        if bill_id not in bill_cache:
            bill_cache[bill_id] = bills_table.get_item(
                Key={"bill_id": bill_id}, ConsistentRead=True
            ).get("Item") or {}
        table_id = bill_cache[bill_id].get("table_id", "")
        data.append({
            "table_id": table_id,
            "item_id": live["item_id"],
            "order_id": live.get("order_id"),
            "bill_id": live.get("bill_id"),
            "dish_id": live.get("dish_id"),
            "dish_name": live.get("dish_name_snapshot", ""),
            "note": live.get("note", ""),
            "status": "ORDERED",
            "created_at": live.get("created_at"),
            "ingredient_options": available_ingredients_for_item(live),
        })
    last_key = result.get("LastEvaluatedKey")
    next_cursor = None
    if last_key:
        next_cursor = base64.b64encode(
            json.dumps(last_key, separators=(",", ":")).encode("utf-8")
        ).decode("ascii")
    return reply(200, {"items": data, "next_cursor": next_cursor})


def process_item(item_id, action, actor, actor_role, event, internal_reason=None):
    if not isinstance(item_id, str) or not re.fullmatch(r"IT[A-Za-z0-9_-]{1,50}", item_id):
        return fail(400, "INVALID_ITEM_ID", "Invalid item identifier")
    try:
        body = parse_body(event)
    except (ValueError, TypeError, json.JSONDecodeError):
        return fail(400, "INVALID_REQUEST", "Invalid JSON request body")
    note = body.get("note", "")
    if not isinstance(note, str) or len(note) > 200:
        return fail(400, "INVALID_NOTE", "note must be at most 200 characters")
    note = note.strip()
    if action == "reject":
        reason = internal_reason if internal_reason == "OUT_OF_STOCK" else body.get("reason")
        if reason not in ("INSUFFICIENT", "OTHER") and not (reason == "OUT_OF_STOCK" and internal_reason):
            return fail(400, "INVALID_REASON", "Unsupported rejection reason")
        if reason == "OTHER" and not note:
            return fail(400, "NOTE_REQUIRED", "A note is required for OTHER rejection")
    elif body.get("reason") is not None:
        return fail(400, "INVALID_REQUEST", "reason is not accepted for completion")

    item, error = get_ordered_item(item_id)
    if error:
        return error
    bill, error = get_open_bill(item)
    if error:
        return error
    allocations, recipe_snapshot = get_pending_recipe(item)

    now = datetime.now(timezone.utc).isoformat()
    update_names = {"#s": "status"}
    new_status = "COMPLETED" if action == "complete" else "REJECTED"
    updates = {
        ":ordered": attr("ORDERED"),
        ":new": attr(new_status),
        ":actor": attr(actor),
        ":when": attr(now),
        ":note": attr(note),
        ":one": attr(1),
    }
    if action == "complete":
        expr = ("SET #s = :new, #source = :source, completed_at = :when, "
                "completed_by = :actor, kitchen_note = :note, version = version + :one")
        update_names["#source"] = "source"
        updates[":source"] = attr("KITCHEN")
    else:
        expr = ("SET #s = :new, reason = :reason, rejected_at = :when, "
                "rejected_by = :actor, kitchen_note = :note, version = version + :one")
        updates[":reason"] = attr(reason)

    tx = [
        {"Update": {
            "TableName": NAMES["items"],
            "Key": attrs({"item_id": item_id}),
            "UpdateExpression": expr,
            "ConditionExpression": "#s = :ordered AND attribute_exists(item_id)",
            "ExpressionAttributeNames": update_names,
            "ExpressionAttributeValues": updates,
        }},
    ]
    if action == "complete":
        # Update bill once in the SAME transaction; cannot also ConditionCheck bill.
        price = Decimal(str(item.get("price_snapshot_vnd", "-1")))
        if not price.is_finite() or price < 0 or price != price.to_integral_value():
            raise ValueError("Invalid price snapshot")
        tx.append({"Update": {
            "TableName": NAMES["bills"],
            "Key": attrs({"bill_id": item["bill_id"]}),
            "UpdateExpression": "SET total_vnd = if_not_exists(total_vnd, :zero) + :price",
            "ConditionExpression": "#s = :open AND attribute_exists(bill_id)",
            "ExpressionAttributeNames": {"#s": "status"},
            "ExpressionAttributeValues": attrs({
                ":zero": 0, ":price": price, ":open": "OPEN",
            }),
        }})
    else:
        tx.append(tx_condition_bill(item["bill_id"]))

    # Freeze recipe in transaction. If changed, refuse to act on old reservations.
    tx.append({"ConditionCheck": {
        "TableName": NAMES["menu"],
        "Key": attrs({"dish_id": item["dish_id"]}),
        "ConditionExpression": "#recipe = :recipe",
        "ExpressionAttributeNames": {"#recipe": "recipe"},
        "ExpressionAttributeValues": {":recipe": attr(recipe_snapshot)},
    }})

    stock_deducted = []
    for ingredient_id, qty, _pending in allocations:
        # Only record a stock cost when the item is COMPLETED.
        if action == "complete":
            ing = ing_table.get_item(Key={"ingredient_id": ingredient_id}, ConsistentRead=True).get("Item")
            if not ing:
                raise ValueError("Ingredient no longer exists")
            cost = Decimal(str(ing.get("last_unit_cost_vnd", "0")))
            if not cost.is_finite() or cost < 0:
                raise ValueError("Invalid ingredient unit cost")
            tx.append({"Update": {
                "TableName": NAMES["ingredients"],
                "Key": attrs({"ingredient_id": ingredient_id}),
                "UpdateExpression": "SET #r = #r - :qty, #b = #b - :qty",
                "ConditionExpression": (
                    "attribute_exists(ingredient_id) AND #r >= :qty AND #b >= :qty "
                    "AND (#state = :in OR #state = :low) AND #cost = :cost"
                ) if "last_unit_cost_vnd" in ing else (
                    "attribute_exists(ingredient_id) AND #r >= :qty AND #b >= :qty "
                    "AND (#state = :in OR #state = :low) AND attribute_not_exists(#cost)"
                ),
                "ExpressionAttributeNames": {
                    "#r": "reserved", "#b": "stock_book",
                    "#state": "stock_status", "#cost": "last_unit_cost_vnd",
                },
                "ExpressionAttributeValues": attrs({
                    ":qty": qty, ":in": "IN_STOCK", ":low": "LOW",
                    **({":cost": cost} if "last_unit_cost_vnd" in ing else {}),
                }),
            }})
            tx.append({"Put": {
                "TableName": NAMES["movements"],
                "Item": attrs({
                    "movement_id": "MV#COMPLETE#" + item_id + "#" + ingredient_id,
                    "item_id": item_id,
                    "bill_id": item["bill_id"],
                    "ingredient_id": ingredient_id,
                    "reason": "KITCHEN_COMPLETED",
                    "qty_delta_base": -qty,
                    "unit_cost_snapshot_vnd": cost,
                    "total_cost_vnd": qty * cost,
                    "actor_id": actor,
                    "created_at": now,
                }),
                "ConditionExpression": "attribute_not_exists(movement_id)",
            }})
            stock_deducted.append({"ingredient_id": ingredient_id, "qty_base": float(qty)})
        else:
            tx.append({"Update": {
                "TableName": NAMES["ingredients"],
                "Key": attrs({"ingredient_id": ingredient_id}),
                "UpdateExpression": "SET #r = #r - :qty",
                "ConditionExpression": "attribute_exists(ingredient_id) AND #r >= :qty",
                "ExpressionAttributeNames": {"#r": "reserved"},
                "ExpressionAttributeValues": attrs({":qty": qty}),
            }})
        tx.append({"Delete": {
            "TableName": NAMES["pending"],
            "Key": attrs({"ingredient_id": ingredient_id, "item_id": item_id}),
            "ConditionExpression": "attribute_exists(ingredient_id) AND qty_base = :qty AND bill_id = :bill",
            "ExpressionAttributeValues": attrs({":qty": qty, ":bill": item["bill_id"]}),
        }})

    tx.append({"Put": {
        "TableName": NAMES["audit"],
        "Item": attrs({
            "audit_id": "AUD#" + new_status + "#" + item_id,
            "timestamp": now,
            "actor_id": actor,
            "actor_role": actor_role,
            "action": "KITCHEN_ITEM_" + new_status,
            "resource_type": "ORDER_ITEM",
            "resource_id": item_id,
            "bill_id": item["bill_id"],
            "dish_id": item["dish_id"],
            "before_status": "ORDERED",
            "after_status": new_status,
            "reason": reason if action == "reject" else "",
            "note": note,
        }),
        "ConditionExpression": "attribute_not_exists(audit_id)",
    }})

    # For current Ordering recipe max 5, transaction is far under 100 actions.
    if len(tx) > 100:
        return fail(409, "TOO_MANY_ACTIONS", "Item requires too many transaction actions")
    client.transact_write_items(TransactItems=tx)
    if action == "complete":
        return reply(200, {
            "item_id": item_id, "status": "COMPLETED", "source": "KITCHEN",
            "charged_vnd": int(price), "stock_deducted": stock_deducted,
        })
    return reply(200, {
        "item_id": item_id, "status": "REJECTED", "reason": reason,
        "charged_vnd": 0,
    })


def mark_out_of_stock(item_id, actor, actor_role, event):
    """Atomically mark one or more recipe ingredients as depleted.

    Every selected ingredient is blocked and its loss recorded exactly once
    in the same transaction. Ingredient stream events independently cascade
    rejections. Replayed streams do not re-book losses.
    """
    if not isinstance(item_id, str) or not re.fullmatch(r"IT[A-Za-z0-9_-]{1,50}", item_id):
        return fail(400, "INVALID_ITEM_ID", "Invalid order item identifier")
    try:
        body = parse_body(event)
        ids = body.get("out_ingredient_ids")
        note = body.get("note", "")
        if (body.get("reason") != "OUT_OF_STOCK"
                or not isinstance(ids, list) or not 1 <= len(ids) <= 5
                or len(set(ids)) != len(ids)
                or any(not isinstance(i, str) or not re.fullmatch(r"I[A-Za-z0-9_-]{1,40}", i) for i in ids)
                or not isinstance(note, str) or not (1 <= len(note.strip()) <= 200)):
            raise ValueError()
    except (ValueError, TypeError, json.JSONDecodeError):
        return fail(400, "INVALID_REQUEST", "Select 1-5 distinct recipe ingredients with a note (max 200 characters)")

    item, error = get_ordered_item(item_id)
    if error:
        return error
    _, error = get_open_bill(item)
    if error:
        return error
    allocations, recipe = get_pending_recipe(item)
    allocated_ids = {part[0] for part in allocations}
    if not set(ids).issubset(allocated_ids):
        return fail(400, "INGREDIENT_NOT_IN_ITEM", "One or more ingredients are not reserved by the item")

    now = datetime.now(timezone.utc).isoformat()
    actions = [
        {"ConditionCheck": {
            "TableName": NAMES["items"],
            "Key": attrs({"item_id": item_id}),
            "ConditionExpression": "#s = :ordered AND bill_id = :bill",
            "ExpressionAttributeNames": {"#s": "status"},
            "ExpressionAttributeValues": attrs({":ordered": "ORDERED", ":bill": item["bill_id"]}),
        }},
        tx_condition_bill(item["bill_id"]),
        {"ConditionCheck": {
            "TableName": NAMES["menu"],
            "Key": attrs({"dish_id": item["dish_id"]}),
            "ConditionExpression": "#recipe = :recipe",
            "ExpressionAttributeNames": {"#recipe": "recipe"},
            "ExpressionAttributeValues": {":recipe": attr(recipe)},
        }},
    ]
    results = []
    total_loss = Decimal(0)
    for ingredient_id in ids:
        stock_item = ing_table.get_item(
            Key={"ingredient_id": ingredient_id}, ConsistentRead=True
        ).get("Item")
        if not stock_item:
            return fail(409, "INGREDIENT_NOT_FOUND", "A selected ingredient no longer exists")
        if stock_item.get("stock_status") == "OUT_OF_STOCK":
            return fail(409, "ALREADY_OUT_OF_STOCK", "A selected ingredient is already marked out")
        if stock_item.get("stock_status") not in ("IN_STOCK", "LOW"):
            return fail(409, "INVALID_STOCK_STATE", "Selected ingredient is not currently orderable")
        try:
            old_stock = Decimal(str(stock_item["stock_book"]))
            old_reserved = Decimal(str(stock_item["reserved"]))
            cost = Decimal(str(stock_item.get("last_unit_cost_vnd", "0")))
            if (not old_stock.is_finite() or not old_reserved.is_finite()
                    or not cost.is_finite() or old_stock < 0 or old_reserved < 0
                    or cost < 0 or old_reserved > old_stock):
                raise ValueError()
        except (ValueError, InvalidOperation, KeyError):
            return fail(409, "INVALID_STOCK_DATA", "Invalid ingredient stock/reserved/cost")

        stockout_id = "SO" + uuid.uuid4().hex.upper()
        loss_value = old_stock * cost
        total_loss += loss_value
        names = {
            "#stock": "stock_book", "#reserved": "reserved",
            "#state": "stock_status", "#cost": "last_unit_cost_vnd",
        }
        values = attrs({
            ":old": old_stock, ":oldr": old_reserved,
            ":zero": Decimal(0), ":out": "OUT_OF_STOCK",
            ":in": "IN_STOCK", ":low": "LOW", ":pending": "PENDING",
            ":sid": stockout_id, ":actor": actor, ":when": now,
        })
        if "last_unit_cost_vnd" in stock_item:
            cost_condition = "#cost = :cost"
            values[":cost"] = attr(cost)
        else:
            cost_condition = "attribute_not_exists(#cost)"

        actions.extend([
            {"Update": {
                "TableName": NAMES["ingredients"],
                "Key": attrs({"ingredient_id": ingredient_id}),
                "UpdateExpression": (
                    "SET #stock = :zero, #state = :out, stockout_cascade_state = :pending, "
                    "stockout_id = :sid, stockout_actor_id = :actor, stockout_started_at = :when"
                ),
                "ConditionExpression": (
                    "attribute_exists(ingredient_id) AND #stock = :old AND #reserved = :oldr "
                    "AND (#state = :in OR #state = :low) AND " + cost_condition
                ),
                "ExpressionAttributeNames": names,
                "ExpressionAttributeValues": values,
            }},
            {"Put": {
                "TableName": NAMES["movements"],
                "Item": attrs({
                    "movement_id": "MV#STOCKOUT#" + stockout_id,
                    "ingredient_id": ingredient_id, "item_id": item_id,
                    "bill_id": item["bill_id"], "reason": "OUT_OF_STOCK_LOSS",
                    "qty_delta_base": -old_stock, "loss_qty_base": old_stock,
                    "unit_cost_snapshot_vnd": cost, "total_cost_vnd": loss_value,
                    "actor_id": actor, "created_at": now, "stockout_id": stockout_id,
                }),
                "ConditionExpression": "attribute_not_exists(movement_id)",
            }},
            {"Put": {
                "TableName": NAMES["audit"],
                "Item": attrs({
                    "audit_id": "AUD#STOCKOUT#" + stockout_id,
                    "timestamp": now, "actor_id": actor, "actor_role": actor_role,
                    "action": "INGREDIENT_MARKED_OUT", "resource_type": "INGREDIENT",
                    "resource_id": ingredient_id, "trigger_item_id": item_id,
                    "before_stock_book": old_stock, "after_stock_book": Decimal(0),
                    "loss_value_vnd": loss_value, "stockout_id": stockout_id,
                    "note": note.strip(),
                }),
                "ConditionExpression": "attribute_not_exists(audit_id)",
            }},
        ])
        results.append({"ingredient_id": ingredient_id, "stockout_id": stockout_id})

    if len(actions) > 100:
        return fail(409, "TOO_MANY_ACTIONS", "Too many ingredients")
    client.transact_write_items(TransactItems=actions)
    return reply(202, {
        "status": "PROCESSING",
        "ingredient_ids": [x["ingredient_id"] for x in results],
        "stockout_ids": results,
        "estimated_loss_vnd": str(total_loss),
        "message": "Ingredients blocked immediately; affected pending items are being rejected",
    })


def cascade_one_stockout(ingredient_id, stockout_id, context):
    """Stream-triggered repairable fanout. Retry failed events instead of skipping items.

    Each item's status, reserved allocations, pending entries and audit log are
    committed together. Can be replayed safely after a worker timeout/failure.
    """
    processed = 0
    while True:
        current = ing_table.get_item(
            Key={"ingredient_id": ingredient_id}, ConsistentRead=True
        ).get("Item")
        if not current or current.get("stockout_id") != stockout_id:
            return  # A newer stock-out event superseded this event.
        if current.get("stock_status") != "OUT_OF_STOCK":
            raise RuntimeError("Stock-out ingredient was restocked before cascade ended")
        if current.get("stockout_cascade_state") == "DONE":
            return
        if current.get("stockout_cascade_state") != "PENDING":
            raise RuntimeError("Unknown stock-out cascade state")
        if context and context.get_remaining_time_in_millis() < 9000:
            raise RuntimeError("Retry DynamoDB Stream event to continue cascade")
        if processed >= 60:
            raise RuntimeError("Cascade chunk complete: retry stream event for next chunk")

        # Strongly consistent query on the base table (not a GSI).
        result = pending_table.query(
            KeyConditionExpression=Key("ingredient_id").eq(ingredient_id),
            ConsistentRead=True, Limit=10,
        )
        pending = result.get("Items", [])
        if not pending:
            if Decimal(str(current.get("reserved", "0"))) != Decimal(0):
                raise RuntimeError("No pending records but reserved remains nonzero")
            ing_table.update_item(
                Key={"ingredient_id": ingredient_id},
                UpdateExpression="SET stockout_cascade_state = :done, stockout_finished_at = :now",
                ConditionExpression=(
                    "stockout_id = :sid AND stockout_cascade_state = :pending "
                    "AND stock_status = :out AND reserved = :zero"
                ),
                ExpressionAttributeValues={
                    ":done": "DONE", ":now": datetime.now(timezone.utc).isoformat(),
                    ":sid": stockout_id, ":pending": "PENDING",
                    ":out": "OUT_OF_STOCK", ":zero": Decimal(0),
                },
            )
            print("Stock-out cascade DONE", ingredient_id, stockout_id, processed)
            return

        made_progress = False
        for row in pending:
            if context and context.get_remaining_time_in_millis() < 9000:
                raise RuntimeError("Retry DynamoDB Stream event to continue cascade")
            item_id = row["item_id"]
            outcome = process_item(
                item_id, "reject", current.get("stockout_actor_id", "SYSTEM"),
                "KITCHEN", {"body": json.dumps({
                    "reason": "OUT_OF_STOCK", "note": "Auto-rejected after ingredient stock-out",
                })}, internal_reason="OUT_OF_STOCK",
            )
            if outcome.get("statusCode") == 200:
                processed += 1
                made_progress = True
            elif outcome.get("statusCode") == 409:
                # The item might have completed/rejected concurrently; re-query
                # its pending record before deciding whether to retry.
                still = pending_table.get_item(Key={
                    "ingredient_id": ingredient_id, "item_id": item_id,
                }, ConsistentRead=True).get("Item")
                if still:
                    print("Conflicting pending item; retry event:", item_id)
                    raise RuntimeError("Pending item is still unresolved")
            else:
                print("Unexpected cascade response", outcome.get("statusCode"), item_id)
                raise RuntimeError("Cascading rejection failed")
        if not made_progress and pending:
            raise RuntimeError("No forward progress in cascade; retry event")


def process_stream(event, context):
    for record in event.get("Records", []):
        if record.get("eventSource") != "aws:dynamodb":
            continue
        if ":table/SecureTable-Ingredients/stream/" not in record.get("eventSourceARN", ""):
            continue
        new = (record.get("dynamodb") or {}).get("NewImage") or {}
        old = (record.get("dynamodb") or {}).get("OldImage") or {}
        def sval(image, name):
            return (image.get(name) or {}).get("S")
        # Only start a cascade on the initial transition to PENDING, never on
        # changes to reserved as individual items are being rejected.
        if (sval(new, "stockout_cascade_state") == "PENDING"
                and sval(old, "stockout_cascade_state") != "PENDING"
                and sval(new, "stock_status") == "OUT_OF_STOCK"):
            ingredient_id = sval(new, "ingredient_id")
            sid = sval(new, "stockout_id")
            if ingredient_id and sid:
                cascade_one_stockout(ingredient_id, sid, context)
    return {"ok": True}


def lambda_handler(event, context):
    if isinstance(event.get("Records"), list):
        return process_stream(event, context)
    auth = authenticated_staff(event)
    if auth is None:
        return fail(401, "UNAUTHORIZED", "Authenticated Cognito identity is required")
    actor, actor_role, allowed = auth
    if not allowed:
        return fail(403, "FORBIDDEN", "KITCHEN or ADMIN role required")

    method = event.get("httpMethod", "").upper()
    resource = event.get("resource") or event.get("path") or ""
    path_params = event.get("pathParameters") or {}

    try:
        if method == "GET" and resource.endswith("/kitchen/queue"):
            return queue(event)
        item_id = path_params.get("itemId")
        if method == "POST" and resource.endswith("/complete"):
            return process_item(item_id, "complete", actor, actor_role, event)
        if method == "POST" and resource.endswith("/reject"):
            try:
                body = parse_body(event)
            except (ValueError, TypeError, json.JSONDecodeError):
                return fail(400, "INVALID_REQUEST", "Invalid JSON request body")
            if body.get("reason") == "OUT_OF_STOCK":
                return mark_out_of_stock(item_id, actor, actor_role, event)
            return process_item(item_id, "reject", actor, actor_role, event)
        return fail(404, "ROUTE_NOT_FOUND", "No matching Kitchen route")
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "Unknown")
        print("DynamoDB error code:", code)
        if code in ("TransactionCanceledException", "TransactionInProgressException"):
            return fail(409, "ITEM_CONFLICT", "Item, bill or inventory changed; refresh and retry")
        if code in ("ValidationException",):
            return fail(500, "DATABASE_CONFIGURATION_ERROR", "Invalid DynamoDB configuration")
        return fail(500, "INTERNAL_SERVER_ERROR", "Kitchen operation failed")
    except (ValueError, KeyError, TypeError, InvalidOperation, OverflowError) as exc:
        print("Kitchen input/config error:", type(exc).__name__)
        return fail(409, "INVALID_KITCHEN_DATA", "Order/recipe/reservation data is inconsistent")
