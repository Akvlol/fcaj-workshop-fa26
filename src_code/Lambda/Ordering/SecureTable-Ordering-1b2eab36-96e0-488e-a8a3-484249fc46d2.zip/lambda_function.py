"""SecureTable: POST /v1/guest/orders (AWS Lambda Python 3.12).

Requires the DynamoDB tables documented in the deployment instructions.
Ingests a REST API Gateway Lambda-proxy event. No Cognito required for guests.
"""
import hashlib
import json
import re
import secrets
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

import boto3
from boto3.dynamodb.types import TypeSerializer
from botocore.exceptions import ClientError

region = "ap-southeast-1"
db = boto3.resource("dynamodb", region_name=region)
client = boto3.client("dynamodb", region_name=region)
serializer = TypeSerializer()

sessions = db.Table("SecureTable-GuestSessions")
tables = db.Table("SecureTable-Tables")
bills = db.Table("SecureTable-Bills")
menu = db.Table("SecureTable-MenuItems")
ingredients = db.Table("SecureTable-Ingredients")

NAMES = {
    "sessions": "SecureTable-GuestSessions",
    "tables": "SecureTable-Tables",
    "bills": "SecureTable-Bills",
    "menu": "SecureTable-MenuItems",
    "ingredients": "SecureTable-Ingredients",
    "orders": "SecureTable-Orders",
    "items": "SecureTable-OrderItems",
    "pending": "SecureTable-PendingByIngredient",
    "idempotency": "SecureTable-Idempotency",
}


def attribute(value):
    return serializer.serialize(value)


def ddb_item(data):
    return {k: attribute(v) for k, v in data.items()}


def reply(code, data):
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store",
        },
        "body": json.dumps(data, ensure_ascii=False),
    }


def fail(status, code, message):
    return reply(status, {"error": {"code": code, "message": message}})


def read_request(event):
    headers = {str(k).lower(): str(v) for k, v in (event.get("headers") or {}).items()}
    authorization = headers.get("authorization", "").split()
    if len(authorization) != 2 or authorization[0].lower() != "bearer":
        raise PermissionError("Guest token is required")
    token = authorization[1]
    if not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", token):
        raise PermissionError("Invalid guest token")
    session_hash = hashlib.sha256(token.encode()).hexdigest()

    key = headers.get("idempotency-key", "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,128}", key):
        raise ValueError("Invalid or missing Idempotency-Key")

    raw = event.get("body")
    if not isinstance(raw, str) or len(raw.encode("utf-8")) > 8192:
        raise ValueError("Invalid JSON request body")
    payload = json.loads(raw)
    if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        raise ValueError("items must be an array")
    lines = payload["items"]
    if not (1 <= len(lines) <= 10):
        raise ValueError("A request must contain 1 to 10 dish lines")

    clean = []
    seen_dishes = set()
    total_qty = 0
    for line in lines:
        if not isinstance(line, dict):
            raise ValueError("Invalid order line")
        dish_id = line.get("dish_id")
        qty = line.get("qty")
        note = line.get("note", "")
        if (not isinstance(dish_id, str)
                or not re.fullmatch(r"D[A-Za-z0-9_-]{1,40}", dish_id)
                or type(qty) is not int or not (1 <= qty <= 10)
                or not isinstance(note, str) or len(note) > 200):
            raise ValueError("Invalid dish_id, qty, or note")
        if dish_id in seen_dishes:
            raise ValueError("Duplicate dish lines are not allowed")
        seen_dishes.add(dish_id)
        total_qty += qty
        clean.append({"dish_id": dish_id, "qty": qty, "note": note.strip()})
    if total_qty > 10:
        raise ValueError("At most 10 portions per request")

    # Sort for consistent idempotency even when the browser changes line order.
    clean.sort(key=lambda x: x["dish_id"])
    payload_hash = hashlib.sha256(
        json.dumps(clean, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return session_hash, key, clean, payload_hash


def find_previous(scope, key, payload_hash):
    item = db.Table(NAMES["idempotency"]).get_item(
        Key={"scope": scope, "key": key}, ConsistentRead=True
    ).get("Item")
    if not item:
        return None
    if item.get("payload_hash") != payload_hash:
        return fail(409, "IDEMPOTENCY_CONFLICT", "This key was used with different items")
    return reply(201, json.loads(item["result_json"]))


def lambda_handler(event, context):
    try:
        session_hash, key, lines, payload_hash = read_request(event)
    except PermissionError:
        return fail(401, "UNAUTHORIZED", "Missing or invalid guest token")
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        return fail(400, "INVALID_REQUEST", str(exc))

    now = int(time.time())
    iso_now = datetime.now(timezone.utc).isoformat()

    try:
        # Session must remain linked to the same currently OPEN bill.
        session = sessions.get_item(
            Key={"session_hash": session_hash}, ConsistentRead=True
        ).get("Item")
        if (not session or session.get("revoked_at") is not None
                or int(session.get("expires_at", 0)) <= now):
            return fail(401, "INVALID_SESSION", "Guest session expired or revoked")
        table_id, bill_id = session.get("table_id"), session.get("bill_id")
        if not table_id or not bill_id:
            return fail(401, "INVALID_SESSION", "Incomplete guest session")

        table = tables.get_item(
            Key={"table_id": table_id}, ConsistentRead=True
        ).get("Item")
        bill = bills.get_item(
            Key={"bill_id": bill_id}, ConsistentRead=True
        ).get("Item")
        if (not table or table.get("status") != "OCCUPIED"
                or table.get("active_bill_id") != bill_id
                or not bill or bill.get("status") != "OPEN"
                or bill.get("table_id") != table_id):
            return fail(409, "BILL_NOT_OPEN", "This table has no active open bill")

        scope = "GUEST_ORDER#" + session_hash
        old = find_previous(scope, key, payload_hash)
        if old is not None:
            return old

        # Read every dish with a strongly consistent read; preserve Decimal values.
        dish_details = []
        requirements = {}  # ingredient_id -> total requested quantity
        for line in lines:
            dish = menu.get_item(
                Key={"dish_id": line["dish_id"]}, ConsistentRead=True
            ).get("Item")
            if not dish or dish.get("active") is not True:
                return fail(409, "DISH_UNAVAILABLE", "One of the dishes is unavailable")
            recipe = dish.get("recipe")
            if not isinstance(recipe, list) or not (1 <= len(recipe) <= 5):
                return fail(409, "INVALID_RECIPE", "Dish has no valid recipe (max 5 ingredients)")
            try:
                price = Decimal(str(dish["price_vnd"]))
                if price != price.to_integral_value() or price < 0:
                    raise ValueError()
            except (KeyError, InvalidOperation, ValueError):
                return fail(409, "INVALID_PRICE", "Dish price is invalid")
            dish_recipe = {}
            for part in recipe:
                if not isinstance(part, dict):
                    return fail(409, "INVALID_RECIPE", "Invalid recipe component")
                ingredient_id = part.get("ingredient_id")
                try:
                    qty_base = Decimal(str(part["qty_base"]))
                except (KeyError, InvalidOperation, ValueError):
                    return fail(409, "INVALID_RECIPE", "Invalid recipe quantity")
                if (not isinstance(ingredient_id, str)
                        or not re.fullmatch(r"I[A-Za-z0-9_-]{1,40}", ingredient_id)
                        or not qty_base.is_finite() or qty_base <= 0
                        or qty_base.as_tuple().exponent < -3
                        or ingredient_id in dish_recipe):
                    return fail(409, "INVALID_RECIPE", "Duplicate or invalid ingredient")
                dish_recipe[ingredient_id] = qty_base
                requirements[ingredient_id] = (
                    requirements.get(ingredient_id, Decimal(0))
                    + qty_base * line["qty"]
                )
            dish_details.append((line, dish, dish_recipe, price))

        if len(requirements) > 10:
            return fail(400, "ORDER_TOO_LARGE", "Maximum 10 distinct ingredients")

        # Snapshot recorded available stock. The transaction rechecks it atomically.
        stock_checks = {}
        for ingredient_id, needed in requirements.items():
            ingredient = ingredients.get_item(
                Key={"ingredient_id": ingredient_id}, ConsistentRead=True
            ).get("Item")
            if not ingredient or ingredient.get("stock_status") not in ("IN_STOCK", "LOW"):
                return fail(409, "INGREDIENTS_UNAVAILABLE", "An ingredient is out of stock")
            try:
                stock = Decimal(str(ingredient["stock_book"]))
                reserved = Decimal(str(ingredient["reserved"]))
            except (KeyError, InvalidOperation, ValueError):
                return fail(409, "INVALID_STOCK", "Ingredient stock is misconfigured")
            if not stock.is_finite() or not reserved.is_finite() or reserved < 0 or stock < reserved + needed:
                return fail(409, "INGREDIENTS_UNAVAILABLE", "Not enough unreserved stock")
            stock_checks[ingredient_id] = (reserved, needed)

        order_id = "O" + secrets.token_hex(12).upper()
        result_items = []
        action_items = []
        action_pending = []
        for line, dish, recipe, price in dish_details:
            line_id = "LN" + secrets.token_hex(10).upper()
            for _ in range(line["qty"]):
                item_id = "IT" + secrets.token_hex(12).upper()
                item = {
                    "item_id": item_id,
                    "bill_id": bill_id,
                    "order_id": order_id,
                    "line_id": line_id,
                    "dish_id": line["dish_id"],
                    "dish_name_snapshot": dish["name"],
                    "price_snapshot_vnd": price,
                    "status": "ORDERED",
                    "order_source": "GUEST",
                    "note": line["note"],
                    "created_at": iso_now,
                    "version": 1,
                }
                action_items.append({"Put": {
                    "TableName": NAMES["items"],
                    "Item": ddb_item(item),
                    "ConditionExpression": "attribute_not_exists(item_id)",
                }})
                for ingredient_id, qty_base in recipe.items():
                    action_pending.append({"Put": {
                        "TableName": NAMES["pending"],
                        "Item": ddb_item({
                            "ingredient_id": ingredient_id,
                            "item_id": item_id,
                            "bill_id": bill_id,
                            "order_id": order_id,
                            "dish_id": line["dish_id"],
                            "qty_base": qty_base,
                            "created_at": iso_now,
                        }),
                        "ConditionExpression": "attribute_not_exists(ingredient_id)",
                    }})
                result_items.append({
                    "item_id": item_id,
                    "line_id": line_id,
                    "dish_id": line["dish_id"],
                    "unit_price_vnd": int(price),
                    "status": "ORDERED",
                })

        result_json = {
            "order_id": order_id,
            "table_id": table_id,
            "items": result_items,
        }

        tx = [
            {"ConditionCheck": {
                "TableName": NAMES["sessions"],
                "Key": ddb_item({"session_hash": session_hash}),
                "ConditionExpression": "#e > :now AND attribute_not_exists(revoked_at) AND table_id = :t AND bill_id = :b",
                "ExpressionAttributeNames": {"#e": "expires_at"},
                "ExpressionAttributeValues": ddb_item({":now": now, ":t": table_id, ":b": bill_id}),
            }},
            {"ConditionCheck": {
                "TableName": NAMES["tables"],
                "Key": ddb_item({"table_id": table_id}),
                "ConditionExpression": "#s = :occupied AND active_bill_id = :b",
                "ExpressionAttributeNames": {"#s": "status"},
                "ExpressionAttributeValues": ddb_item({":occupied": "OCCUPIED", ":b": bill_id}),
            }},
            {"ConditionCheck": {
                "TableName": NAMES["bills"],
                "Key": ddb_item({"bill_id": bill_id}),
                "ConditionExpression": "#s = :open AND table_id = :t",
                "ExpressionAttributeNames": {"#s": "status"},
                "ExpressionAttributeValues": ddb_item({":open": "OPEN", ":t": table_id}),
            }},
        ]

        # Prevent active/price/recipe changes between read and transaction.
        for line, dish, recipe, price in dish_details:
            tx.append({"ConditionCheck": {
                "TableName": NAMES["menu"],
                "Key": ddb_item({"dish_id": line["dish_id"]}),
                "ConditionExpression": "#active = :yes AND #price = :p AND #recipe = :r",
                "ExpressionAttributeNames": {
                    "#active": "active", "#price": "price_vnd", "#recipe": "recipe"
                },
                "ExpressionAttributeValues": {
                    ":yes": attribute(True),
                    ":p": attribute(price),
                    ":r": attribute(dish["recipe"]),
                },
            }})

        for ingredient_id, (old_reserved, needed) in stock_checks.items():
            tx.append({"Update": {
                "TableName": NAMES["ingredients"],
                "Key": ddb_item({"ingredient_id": ingredient_id}),
                "UpdateExpression": "SET #reserved = #reserved + :delta",
                "ConditionExpression": (
                    "attribute_exists(ingredient_id) AND #reserved = :old "
                    "AND #stock >= :needed_total AND (#state = :instock OR #state = :low)"
                ),
                "ExpressionAttributeNames": {
                    "#reserved": "reserved", "#stock": "stock_book", "#state": "stock_status"
                },
                "ExpressionAttributeValues": {
                    ":delta": attribute(needed),
                    ":old": attribute(old_reserved),
                    ":needed_total": attribute(old_reserved + needed),
                    ":instock": attribute("IN_STOCK"),
                    ":low": attribute("LOW"),
                },
            }})

        tx.append({"Put": {
            "TableName": NAMES["orders"],
            "Item": ddb_item({
                "order_id": order_id,
                "bill_id": bill_id,
                "table_id": table_id,
                "created_at": iso_now,
                "status": "ORDERED",
                "source": "GUEST",
                "portion_count": len(result_items),
            }),
            "ConditionExpression": "attribute_not_exists(order_id)",
        }})
        tx.extend(action_items)
        tx.extend(action_pending)

        tx.append({"Put": {
            "TableName": NAMES["idempotency"],
            "Item": ddb_item({
                "scope": scope,
                "key": key,
                "payload_hash": payload_hash,
                "result_json": json.dumps(result_json, ensure_ascii=False),
                "created_at": iso_now,
                "ttl": now + 7 * 24 * 3600,
            }),
            "ConditionExpression": "attribute_not_exists(#scope) AND attribute_not_exists(#key)",
            "ExpressionAttributeNames": {"#scope": "scope", "#key": "key"},
        }})
        if len(tx) > 100:
            return fail(400, "ORDER_TOO_LARGE", "Too many transaction actions")

        client.transact_write_items(TransactItems=tx)
        return reply(201, result_json)

    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "Unknown")
        print("DynamoDB error code:", code)
        if code in ("TransactionCanceledException", "TransactionInProgressException"):
            # For concurrent retries, the previous transaction might have succeeded.
            try:
                previous = find_previous(scope, key, payload_hash)
                if previous is not None:
                    return previous
            except ClientError:
                pass
            return fail(409, "ORDER_CONFLICT", "Bill, menu or stock changed; please retry")
        return fail(500, "INTERNAL_SERVER_ERROR", "Unable to process this order")
    except (KeyError, TypeError, ValueError, InvalidOperation) as exc:
        print("Invalid configuration:", type(exc).__name__)
        return fail(500, "INVALID_CONFIGURATION", "Menu or ingredient configuration is invalid")
