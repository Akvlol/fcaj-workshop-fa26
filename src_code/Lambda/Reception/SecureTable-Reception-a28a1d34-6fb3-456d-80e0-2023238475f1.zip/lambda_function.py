"""SecureTable Reception v1 -- read tables/bills, receipt, resumable close.

Deploy as the single SecureTable-Reception Lambda. Route POST /v1/staff/bills
and all other Reception routes to this function. REST API Lambda proxy with Cognito
User Pool authorizer on ALL routes; requires ID token and RECEPTION/ADMIN.

Bill close uses OPEN -> CLOSING to atomically block new guest orders and Kitchen
processing. Each remaining portion is processed in an independent conditional
DynamoDB transaction; retries with the SAME Idempotency-Key are safe. Closed
bills can no longer be accessed by guest sessions because guest APIs require OPEN.

Small-restaurant MVP: strongly-consistent base-table Scan of OrderItems instead
of eventually-consistent bill_id GSI; see README for scaling limitation.
"""
import base64
import hashlib
import json
import os
import re
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

import boto3
from boto3.dynamodb.conditions import Attr
from boto3.dynamodb.types import TypeSerializer
from botocore.exceptions import ClientError

REGION = os.environ.get('AWS_REGION', 'ap-southeast-1')
DB = boto3.resource('dynamodb', region_name=REGION)
CLIENT = boto3.client('dynamodb', region_name=REGION)
SER = TypeSerializer()
TABLES = {
    'tables': 'SecureTable-Tables',
    'bills': 'SecureTable-Bills',
    'items': 'SecureTable-OrderItems',
    'menu': 'SecureTable-MenuItems',
    'ingredients': 'SecureTable-Ingredients',
    'pending': 'SecureTable-PendingByIngredient',
    'movements': 'SecureTable-InventoryMovements',
    'audit': 'SecureTable-AuditLogs',
    'finance': 'SecureTable-FinanceLedger',
}
DDB = {k: DB.Table(name) for k, name in TABLES.items()}
RE_ITEM = re.compile(r'^IT[A-Za-z0-9_-]{1,50}$')
RE_BILL = re.compile(r'^B[A-Za-z0-9_-]{1,90}$')
RE_ING = re.compile(r'^I[A-Za-z0-9_-]{1,40}$')
MAX_SCAN_PAGES = 250


def a(v):
    return SER.serialize(v)


def aa(obj):
    return {k: a(v) for k, v in obj.items()}


def now_utc():
    return datetime.now(timezone.utc).isoformat()


def jsonable(obj):
    if isinstance(obj, Decimal):
        return int(obj) if obj == obj.to_integral_value() else float(obj)
    if isinstance(obj, dict):
        return {k: jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [jsonable(v) for v in obj]
    return obj


def respond(status, payload, content_type='application/json; charset=utf-8'):
    if content_type.startswith('text/plain'):
        body = str(payload)
    else:
        body = json.dumps(jsonable(payload), ensure_ascii=False)
    return {'statusCode': status, 'headers': {'Content-Type': content_type,
            'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}, 'body': body}


def error(status, code, message):
    return respond(status, {'error': {'code': code, 'message': message}})


def staff(event):
    claims = ((event.get('requestContext') or {}).get('authorizer') or {}).get('claims') or {}
    if not isinstance(claims, dict) or not isinstance(claims.get('sub'), str) or not claims['sub']:
        return None
    raw = claims.get('cognito:groups', '')
    groups = set(raw) if isinstance(raw, list) else set(re.findall(r'[A-Za-z][A-Za-z0-9_-]*', str(raw)))
    role = 'ADMIN' if 'ADMIN' in groups else ('RECEPTION' if 'RECEPTION' in groups else None)
    return claims['sub'], role


def read_json(event):
    if event.get('isBase64Encoded'):
        raise ValueError('Không hỗ trợ request body base64.')
    raw = event.get('body')
    if not isinstance(raw, str) or len(raw.encode('utf-8')) > 2048:
        raise ValueError('Request body JSON không hợp lệ.')
    obj = json.loads(raw)
    if not isinstance(obj, dict):
        raise ValueError('Request body phải là object.')
    return obj


def scan_all(tab_key, filter_expr=None):
    """Strong read across pagination; safe for already-locked bill on small MVP.

    There is no *point-in-time* scan snapshot; new items are blocked before
    bill item scan because Ordering writes require bill status OPEN.
    """
    result = []
    cursor = None
    for _ in range(MAX_SCAN_PAGES):
        kw = {'ConsistentRead': True}
        if filter_expr is not None:
            kw['FilterExpression'] = filter_expr
        if cursor:
            kw['ExclusiveStartKey'] = cursor
        page = DDB[tab_key].scan(**kw)
        result.extend(page.get('Items', []))
        cursor = page.get('LastEvaluatedKey')
        if not cursor:
            return result
    raise RuntimeError('SCAN_LIMIT_REACHED')


def get_bill(bill_id):
    return DDB['bills'].get_item(Key={'bill_id': bill_id}, ConsistentRead=True).get('Item')


def get_table(table_id):
    return DDB['tables'].get_item(Key={'table_id': table_id}, ConsistentRead=True).get('Item')


def list_items(bill_id):
    rows = scan_all('items', Attr('bill_id').eq(bill_id))
    return sorted(rows, key=lambda x: (str(x.get('created_at', '')), str(x.get('item_id', ''))))


def positive_int_price(item):
    price = Decimal(str(item.get('price_snapshot_vnd', '')))
    if not price.is_finite() or price < 0 or price != price.to_integral_value():
        raise ValueError('INVALID_PRICE_SNAPSHOT')
    return price


def bill_view(bill, include_items=True):
    obj = {
        'bill_id': bill['bill_id'], 'table_id': bill.get('table_id'),
        'status': bill.get('status'), 'outcome': bill.get('outcome'),
        'opened_at': bill.get('opened_at'), 'closed_at': bill.get('closed_at'),
        'guest_count': bill.get('guest_count'), 'total_vnd': bill.get('total_vnd', 0),
        'close_note': bill.get('close_note', ''),
    }
    # These are only exposed to staff with Reception privileges.
    if bill.get('status') == 'CLOSING':
        obj['close_request_key'] = bill.get('close_request_key')
        obj['close_unpaid'] = bool(bill.get('close_unpaid', False))
    if not include_items:
        return obj
    rows = list_items(bill['bill_id'])
    out = []
    completed_total = Decimal(0)
    ordered_total = Decimal(0)
    counts = {'ORDERED': 0, 'COMPLETED': 0, 'REJECTED': 0}
    for item in rows:
        status = item.get('status', '')
        if status not in counts:
            raise ValueError('UNKNOWN_ITEM_STATUS')
        price = positive_int_price(item)
        counts[status] += 1
        if status == 'COMPLETED':
            completed_total += price
        elif status == 'ORDERED':
            ordered_total += price
        out.append({
            'item_id': item.get('item_id'), 'dish_name': item.get('dish_name_snapshot') or item.get('dish_id'),
            'dish_id': item.get('dish_id'), 'status': status, 'price_vnd': price,
            'source': item.get('source', ''), 'reason': item.get('reason', ''),
            'note': item.get('note', ''), 'kitchen_note': item.get('kitchen_note', ''),
            'created_at': item.get('created_at'),
        })
    obj.update({'items': out, 'counts': counts,
                'completed_total_vnd': completed_total,
                'pending_total_vnd': ordered_total,
                'estimated_total_vnd': completed_total + ordered_total})
    return obj


def list_tables(event):
    rows = scan_all('tables')
    allowed = {'FREE', 'OCCUPIED', 'CLOSING'}
    out = []
    for row in rows:
        if row.get('status') not in allowed:
            continue
        out.append({'table_id': row['table_id'], 'name': row.get('name', row['table_id']),
                    'status': row['status'], 'active_bill_id': row.get('active_bill_id')})
    out.sort(key=lambda x: x['table_id'])
    return respond(200, {'tables': out})


def list_bills(event):
    p = event.get('queryStringParameters') or {}
    status = (p.get('status') or '').upper()
    if status and status not in ('OPEN', 'CLOSING', 'CLOSED'):
        return error(400, 'INVALID_STATUS', 'status không hợp lệ')
    try:
        limit = int(p.get('limit') or '50')
    except ValueError:
        return error(400, 'INVALID_LIMIT', 'limit phải là số nguyên')
    if not 1 <= limit <= 100:
        return error(400, 'INVALID_LIMIT', 'limit từ 1 đến 100')
    rows = scan_all('bills')
    if status:
        rows = [x for x in rows if x.get('status') == status]
    rows.sort(key=lambda x: (str(x.get('opened_at', '')), x['bill_id']), reverse=True)
    return respond(200, {'bills': [bill_view(b, False) for b in rows[:limit]]})


def view_bill(bill_id, event):
    if not RE_BILL.fullmatch(str(bill_id or '')):
        return error(400, 'INVALID_BILL_ID', 'Mã bill không hợp lệ')
    bill = get_bill(bill_id)
    if not bill:
        return error(404, 'BILL_NOT_FOUND', 'Không tìm thấy bill')
    detailed = bill_view(bill)
    if event.get('resource', '').endswith('/receipt'):
        q = event.get('queryStringParameters') or {}
        fmt = q.get('format', 'json')
        if fmt not in ('json', 'text'):
            return error(400, 'INVALID_FORMAT', 'format chỉ hỗ trợ json hoặc text')
        if fmt == 'text':
            lines = ['SecureTable', f'Bill: {bill_id}', f'Ban: {bill.get("table_id")}',
                     f'Trang thai: {bill.get("outcome") or bill.get("status")}']
            for item in detailed['items']:
                if item['status'] == 'COMPLETED':
                    lines.append(f'{item["dish_name"]}: {int(item["price_vnd"]):,} VND')
            lines.append(f'Tong: {int(detailed["completed_total_vnd"]):,} VND')
            return respond(200, '\n'.join(lines), 'text/plain; charset=utf-8')
        return respond(200, detailed)
    return respond(200, detailed)


def close_fields(body, event):
    if type(body.get('unpaid')) is not bool:
        raise ValueError('unpaid phải là true hoặc false')
    note = body.get('note', '')
    if not isinstance(note, str) or len(note.strip()) > 400:
        raise ValueError('Ghi chú tối đa 400 ký tự')
    note = note.strip()
    if body['unpaid'] and not note:
        raise ValueError('Bill chưa thanh toán cần có ghi chú')
    key = {str(k).lower(): str(v) for k, v in (event.get('headers') or {}).items()}.get('idempotency-key', '')
    if not re.fullmatch(r'[A-Za-z0-9_-]{8,128}', key):
        raise ValueError('Thiếu Idempotency-Key hợp lệ')
    canon = json.dumps({'unpaid': body['unpaid'], 'note': note}, sort_keys=True, separators=(',', ':'))
    return key, hashlib.sha256(canon.encode()).hexdigest(), note


def claim_close(bill, key, payload_hash, unpaid, note, actor):
    now = now_utc()
    CLIENT.transact_write_items(TransactItems=[
        {'Update': {'TableName': TABLES['bills'], 'Key': aa({'bill_id': bill['bill_id']}),
            'UpdateExpression': ('SET #s = :closing, close_request_key = :key, '
                                 'close_payload_hash = :hash, close_unpaid = :unpaid, '
                                 'close_note = :note, closing_started_at = :now, closing_actor_id = :actor'),
            'ConditionExpression': '#s = :open AND table_id = :table AND attribute_not_exists(close_request_key)',
            'ExpressionAttributeNames': {'#s': 'status'},
            'ExpressionAttributeValues': aa({':closing': 'CLOSING', ':open': 'OPEN',
                ':table': bill['table_id'], ':key': key, ':hash': payload_hash,
                ':unpaid': unpaid, ':note': note, ':now': now, ':actor': actor})}},
        {'Update': {'TableName': TABLES['tables'], 'Key': aa({'table_id': bill['table_id']}),
            'UpdateExpression': 'SET #s = :closing',
            'ConditionExpression': '#s = :occupied AND active_bill_id = :bill',
            'ExpressionAttributeNames': {'#s': 'status'},
            'ExpressionAttributeValues': aa({':closing': 'CLOSING', ':occupied': 'OCCUPIED',
                                              ':bill': bill['bill_id']})}},
    ])


def reserved_allocations(item):
    dish = DDB['menu'].get_item(Key={'dish_id': item['dish_id']}, ConsistentRead=True).get('Item')
    if not dish or not isinstance(dish.get('recipe'), list) or not 1 <= len(dish['recipe']) <= 5:
        raise ValueError('RECIPE_NOT_FOUND')
    recipe = dish['recipe']
    results = []
    seen = set()
    for line in recipe:
        ingredient_id = line.get('ingredient_id')
        if not isinstance(ingredient_id, str) or not RE_ING.fullmatch(ingredient_id) or ingredient_id in seen:
            raise ValueError('INVALID_RECIPE')
        seen.add(ingredient_id)
        quantity = Decimal(str(line.get('qty_base', 0)))
        if not quantity.is_finite() or quantity <= 0:
            raise ValueError('INVALID_RECIPE_QUANTITY')
        pending = DDB['pending'].get_item(Key={'ingredient_id': ingredient_id,
            'item_id': item['item_id']}, ConsistentRead=True).get('Item')
        if not pending or pending.get('bill_id') != item['bill_id'] or pending.get('order_id') != item.get('order_id') or Decimal(str(pending.get('qty_base', 0))) != quantity:
            raise ValueError('RESERVATION_MISMATCH')
        results.append((ingredient_id, quantity))
    return recipe, results


def auto_process(item, key, actor):
    """One atomic portion transition. Auto-reject if ingredient already OUT_OF_STOCK."""
    if item.get('status') != 'ORDERED':
        return
    recipe, allocs = reserved_allocations(item)
    stocks = {}
    reject = False
    for ing_id, qty in allocs:
        ing = DDB['ingredients'].get_item(Key={'ingredient_id': ing_id}, ConsistentRead=True).get('Item')
        if not ing:
            raise ValueError('INGREDIENT_MISSING')
        stocks[ing_id] = ing
        state = ing.get('stock_status')
        if state == 'OUT_OF_STOCK':
            reject = True
        elif state not in ('IN_STOCK', 'LOW'):
            raise ValueError('INVALID_STOCK_STATE')
        if Decimal(str(ing.get('reserved', 0))) < qty:
            raise ValueError('RESERVATION_MISMATCH')
    now = now_utc()
    item_id = item['item_id']
    price = positive_int_price(item)
    target = 'REJECTED' if reject else 'COMPLETED'
    vals = aa({':old': 'ORDERED', ':new': target, ':now': now, ':actor': actor, ':zero': 0, ':one': 1})
    names = {'#s': 'status', '#source': 'source'}
    update = ('SET #s = :new, #source = :source, version = if_not_exists(version, :zero) + :one, '
              'processed_at = :now, processed_by = :actor')
    vals[':source'] = a('AUTO_REJECTED_ON_CLOSE' if reject else 'AUTO_COMPLETED_ON_CLOSE')
    if reject:
        update += ', reason = :reason, rejected_at = :now'
        vals[':reason'] = a('OUT_OF_STOCK')
    else:
        update += ', completed_at = :now'
    tx = [{'Update': {'TableName': TABLES['items'], 'Key': aa({'item_id': item_id}),
        'UpdateExpression': update,
        'ConditionExpression': '#s = :old AND bill_id = :bill',
        'ExpressionAttributeNames': names,
        'ExpressionAttributeValues': {**vals, ':bill': a(item['bill_id'])}}}]
    if reject:
        tx.append({'ConditionCheck': {'TableName': TABLES['bills'],
            'Key': aa({'bill_id': item['bill_id']}),
            'ConditionExpression': '#s = :closing AND close_request_key = :key',
            'ExpressionAttributeNames': {'#s': 'status'},
            'ExpressionAttributeValues': aa({':closing': 'CLOSING', ':key': key})}})
    else:
        tx.append({'Update': {'TableName': TABLES['bills'],
            'Key': aa({'bill_id': item['bill_id']}),
            'UpdateExpression': 'SET total_vnd = if_not_exists(total_vnd, :zero) + :price',
            'ConditionExpression': '#s = :closing AND close_request_key = :key',
            'ExpressionAttributeNames': {'#s': 'status'},
            'ExpressionAttributeValues': aa({':closing': 'CLOSING', ':key': key, ':zero': 0, ':price': price})}})
    tx.append({'ConditionCheck': {'TableName': TABLES['menu'],
        'Key': aa({'dish_id': item['dish_id']}),
        'ConditionExpression': '#r = :recipe',
        'ExpressionAttributeNames': {'#r': 'recipe'},
        'ExpressionAttributeValues': {':recipe': a(recipe)}}})
    for ing_id, qty in allocs:
        ing = stocks[ing_id]
        if reject:
            tx.append({'Update': {'TableName': TABLES['ingredients'], 'Key': aa({'ingredient_id': ing_id}),
                'UpdateExpression': 'SET #r = #r - :qty',
                'ConditionExpression': 'attribute_exists(ingredient_id) AND #r >= :qty',
                'ExpressionAttributeNames': {'#r': 'reserved'},
                'ExpressionAttributeValues': aa({':qty': qty})}})
        else:
            cost = Decimal(str(ing.get('last_unit_cost_vnd', 0)))
            if not cost.is_finite() or cost < 0:
                raise ValueError('INVALID_UNIT_COST')
            cost_expr = '#cost = :cost' if 'last_unit_cost_vnd' in ing else 'attribute_not_exists(#cost)'
            tx.append({'Update': {'TableName': TABLES['ingredients'], 'Key': aa({'ingredient_id': ing_id}),
                'UpdateExpression': 'SET #r = #r - :qty, #b = #b - :qty',
                'ConditionExpression': ('attribute_exists(ingredient_id) AND #r >= :qty AND #b >= :qty '
                    'AND (#state = :in OR #state = :low) AND ' + cost_expr),
                'ExpressionAttributeNames': {'#r': 'reserved', '#b': 'stock_book',
                                             '#state': 'stock_status', '#cost': 'last_unit_cost_vnd'},
                'ExpressionAttributeValues': aa({':qty': qty, ':in': 'IN_STOCK', ':low': 'LOW',
                    **({':cost': cost} if 'last_unit_cost_vnd' in ing else {})})}})
            tx.append({'Put': {'TableName': TABLES['movements'],
                'Item': aa({'movement_id': 'MV#AUTO_CLOSE#' + item_id + '#' + ing_id,
                    'item_id': item_id, 'bill_id': item['bill_id'], 'ingredient_id': ing_id,
                    'reason': 'AUTO_COMPLETED_ON_CLOSE', 'qty_delta_base': -qty,
                    'unit_cost_snapshot_vnd': cost, 'total_cost_vnd': qty * cost,
                    'actor_id': actor, 'created_at': now}),
                'ConditionExpression': 'attribute_not_exists(movement_id)'}})
        tx.append({'Delete': {'TableName': TABLES['pending'],
            'Key': aa({'ingredient_id': ing_id, 'item_id': item_id}),
            'ConditionExpression': 'attribute_exists(ingredient_id) AND bill_id = :bill AND qty_base = :qty',
            'ExpressionAttributeValues': aa({':bill': item['bill_id'], ':qty': qty})}})
    tx.append({'Put': {'TableName': TABLES['audit'],
        'Item': aa({'audit_id': 'AUD#AUTO_CLOSE#' + item_id,
            'timestamp': now, 'actor_id': actor, 'actor_role': 'RECEPTION',
            'action': 'AUTO_REJECTED_ON_CLOSE' if reject else 'AUTO_COMPLETED_ON_CLOSE',
            'resource_type': 'ORDER_ITEM', 'resource_id': item_id,
            'bill_id': item['bill_id'], 'reason': 'OUT_OF_STOCK' if reject else '',
            'price_vnd': 0 if reject else price}),
        'ConditionExpression': 'attribute_not_exists(audit_id)'}})
    if len(tx) > 100:
        raise ValueError('TRANSACTION_TOO_LARGE')
    CLIENT.transact_write_items(TransactItems=tx)


def pending_stockout_for_bill(rows):
    """Don't finalize until pending stock-out cascades relevant to bill finish."""
    affected = set()
    for item in rows:
        if item.get('status') != 'REJECTED' or item.get('reason') != 'OUT_OF_STOCK':
            continue
        dish = DDB['menu'].get_item(Key={'dish_id': item['dish_id']}, ConsistentRead=True).get('Item')
        if not dish:
            raise ValueError('RECIPE_NOT_FOUND')
        for part in dish.get('recipe', []):
            ing_id = part['ingredient_id']
            affected.add(ing_id)
    for ing_id in affected:
        ing = DDB['ingredients'].get_item(Key={'ingredient_id': ing_id}, ConsistentRead=True).get('Item') or {}
        if ing.get('stockout_cascade_state') == 'PENDING':
            return True
    return False


def finalize(bill, key, actor, role, rows, note, unpaid):
    if any(i.get('status') == 'ORDERED' for i in rows):
        return error(409, 'ITEMS_STILL_PENDING', 'Vẫn còn món chờ xử lý; thử lại')
    if pending_stockout_for_bill(rows):
        return respond(202, {'status': 'CLOSING', 'bill_id': bill['bill_id'],
            'message': 'Kitchen đang xử lý hết nguyên liệu; thử tiếp tục đóng bill sau'})
    total = sum((positive_int_price(i) for i in rows if i.get('status') == 'COMPLETED'), Decimal(0))
    outcome = 'EMPTY' if total == 0 else ('UNPAID' if unpaid else 'PAID')
    now = now_utc()
    ledger_type = 'REVENUE_PAID' if outcome == 'PAID' else 'ACCOUNTS_RECEIVABLE'
    tx = [
        {'Update': {'TableName': TABLES['bills'], 'Key': aa({'bill_id': bill['bill_id']}),
            'UpdateExpression': ('SET #s = :closed, outcome = :outcome, total_vnd = :total, '
                                 'closed_at = :now, closed_by = :actor'),
            'ConditionExpression': '#s = :closing AND close_request_key = :key',
            'ExpressionAttributeNames': {'#s': 'status'},
            'ExpressionAttributeValues': aa({':closed': 'CLOSED', ':closing': 'CLOSING',
                ':key': key, ':outcome': outcome, ':total': total, ':now': now, ':actor': actor})}},
        {'Update': {'TableName': TABLES['tables'], 'Key': aa({'table_id': bill['table_id']}),
            'UpdateExpression': 'SET #s = :free REMOVE active_bill_id',
            'ConditionExpression': '#s = :closing AND active_bill_id = :bill',
            'ExpressionAttributeNames': {'#s': 'status'},
            'ExpressionAttributeValues': aa({':free': 'FREE', ':closing': 'CLOSING', ':bill': bill['bill_id']})}},
        {'Put': {'TableName': TABLES['audit'],
            'Item': aa({'audit_id': 'AUD#BILL_CLOSE#' + bill['bill_id'], 'timestamp': now,
                'actor_id': actor, 'actor_role': role, 'action': 'BILL_CLOSED_' + outcome,
                'resource_type': 'BILL', 'resource_id': bill['bill_id'],
                'table_id': bill['table_id'], 'total_vnd': total, 'outcome': outcome,
                'note': note}),
            'ConditionExpression': 'attribute_not_exists(audit_id)'}},
    ]
    if total > 0:
        tx.append({'Put': {'TableName': TABLES['finance'],
            'Item': aa({'entry_id': 'FL#BILL#' + bill['bill_id'],
                'entry_type': ledger_type, 'amount_vnd': total,
                'business_date': datetime.now(timezone.utc).astimezone(ZoneInfo('Asia/Ho_Chi_Minh')).date().isoformat(),
                'reference_id': bill['bill_id'], 'table_id': bill['table_id'],
                'created_at': now, 'actor_id': actor}),
            'ConditionExpression': 'attribute_not_exists(entry_id)'}})
    CLIENT.transact_write_items(TransactItems=tx)
    return respond(200, {'bill_id': bill['bill_id'], 'table_id': bill['table_id'],
        'status': 'CLOSED', 'outcome': outcome, 'total_vnd': total,
        'auto_completed_items': [i['item_id'] for i in rows if i.get('source') == 'AUTO_COMPLETED_ON_CLOSE'],
        'closed_at': now})


def close_bill(bill_id, event, actor, role, context):
    if not RE_BILL.fullmatch(str(bill_id or '')):
        return error(400, 'INVALID_BILL_ID', 'Mã bill không hợp lệ')
    try:
        body = read_json(event)
        key, digest, note = close_fields(body, event)
    except (ValueError, TypeError, json.JSONDecodeError) as e:
        return error(400, 'INVALID_REQUEST', str(e))
    bill = get_bill(bill_id)
    if not bill:
        return error(404, 'BILL_NOT_FOUND', 'Bill không tồn tại')
    if bill.get('status') == 'OPEN':
        # Require matching active table before locking it.
        table = get_table(bill['table_id'])
        if not table or table.get('status') != 'OCCUPIED' or table.get('active_bill_id') != bill_id:
            return error(409, 'TABLE_BILL_MISMATCH', 'Bàn và bill không khớp')
        try:
            claim_close(bill, key, digest, body['unpaid'], note, actor)
        except ClientError as exc:
            if exc.response.get('Error', {}).get('Code') in ('TransactionCanceledException', 'TransactionInProgressException'):
                bill = get_bill(bill_id) or bill
                if bill.get('status') == 'OPEN':
                    return error(409, 'CLOSE_CONFLICT', 'Trạng thái bàn hoặc bill vừa thay đổi; tải lại')
            else:
                raise
        bill = get_bill(bill_id)
    if bill.get('status') == 'CLOSED':
        if bill.get('close_request_key') == key and bill.get('close_payload_hash') == digest:
            return respond(200, {'bill_id': bill_id, 'status': 'CLOSED',
                'outcome': bill.get('outcome'), 'total_vnd': bill.get('total_vnd', 0),
                'closed_at': bill.get('closed_at'), 'already_closed': True})
        return error(409, 'ALREADY_CLOSED', 'Bill đã được đóng bởi yêu cầu khác')
    if bill.get('status') != 'CLOSING' or bill.get('close_request_key') != key or bill.get('close_payload_hash') != digest:
        return error(409, 'CLOSE_IN_PROGRESS', 'Bill đang được đóng; dùng lại yêu cầu trước')
    rows = list_items(bill_id)
    # Complete each pending portion atomically. Return 202 if time too short.
    for item in rows:
        if item.get('status') != 'ORDERED':
            continue
        if context is not None and context.get_remaining_time_in_millis() < 8500:
            return respond(202, {'status': 'CLOSING', 'bill_id': bill_id,
                'message': 'Chưa xử lý hết món. Gửi lại cùng Idempotency-Key để tiếp tục.'})
        try:
            auto_process(item, key, actor)
        except ClientError as exc:
            if exc.response.get('Error', {}).get('Code') in ('TransactionCanceledException', 'TransactionInProgressException'):
                return respond(202, {'status': 'CLOSING', 'bill_id': bill_id,
                    'message': 'Dữ liệu món/kho thay đổi hoặc có thao tác cạnh tranh. Thử tiếp tục cùng yêu cầu.'})
            raise
    rows = list_items(bill_id)
    if any(i.get('status') == 'ORDERED' for i in rows):
        return respond(202, {'status': 'CLOSING', 'bill_id': bill_id,
            'message': 'Vẫn còn món chờ, hãy thử tiếp tục'})
    if context is not None and context.get_remaining_time_in_millis() < 8500:
        return respond(202, {'status': 'CLOSING', 'bill_id': bill_id,
            'message': 'Đã xử lý món; cần gọi lại để xác nhận đóng bill'})
    try:
        return finalize(bill, key, actor, role, rows, note, body['unpaid'])
    except ClientError as exc:
        if exc.response.get('Error', {}).get('Code') in ('TransactionCanceledException', 'TransactionInProgressException'):
            latest = get_bill(bill_id)
            if latest and latest.get('status') == 'CLOSED' and latest.get('close_request_key') == key:
                return respond(200, {'bill_id': bill_id, 'status': 'CLOSED', 'outcome': latest.get('outcome'),
                    'total_vnd': latest.get('total_vnd', 0), 'closed_at': latest.get('closed_at'), 'already_closed': True})
            return respond(202, {'status': 'CLOSING', 'bill_id': bill_id,
                'message': 'Đóng bill chưa hoàn tất; thử tiếp tục cùng yêu cầu'})
        raise



def open_response(status, data):
    return {
        'statusCode': status,
        'headers': {'Content-Type': 'application/json', 'Cache-Control': 'no-store'},
        'body': json.dumps(data)
    }


def open_bill(event, actor):
    # 2. Validate request and idempotency key
    headers = {
        str(k).lower(): v
        for k, v in (event.get("headers") or {}).items()
    }

    key = headers.get("idempotency-key", "")

    if not isinstance(key, str) or not 8 <= len(key) <= 128:
        return open_response(400, {
            "error": "INVALID_IDEMPOTENCY_KEY"
        })

    try:
        body = event.get("body") or "{}"
        data = json.loads(body) if isinstance(body, str) else body

        if not isinstance(data, dict):
            raise ValueError()

        table_id = data.get("table_id")
        guest_count = data.get("guest_count")

        if not isinstance(table_id, str):
            raise ValueError()

        table_id = table_id.strip()

        if (
            not table_id
            or len(table_id) > 64
            or type(guest_count) is not int
            or not 1 <= guest_count <= 50
        ):
            raise ValueError()

    except (ValueError, TypeError):
        return open_response(400, {
            "error": "INVALID_REQUEST"
        })

    # 3. Stable bill ID for request retries
    request_hash = hashlib.sha256(
        json.dumps({
            "table_id": table_id,
            "guest_count": guest_count
        }, sort_keys=True).encode()
    ).hexdigest()

    bill_id = "B" + hashlib.sha256(
        f"{actor}:{key}".encode()
    ).hexdigest()[:24].upper()

    def check_existing():
        result = CLIENT.get_item(
            TableName=TABLES['bills'],
            Key={"bill_id": {"S": bill_id}},
            ConsistentRead=True
        )

        item = result.get("Item")

        if not item:
            return None

        if item.get("request_hash", {}).get("S") != request_hash:
            return open_response(409, {
                "error": "IDEMPOTENCY_CONFLICT"
            })

        return open_response(201, {
            "bill_id": bill_id,
            "table_id": item["table_id"]["S"],
            "status": item["status"]["S"],
            "opened_at": item["opened_at"]["S"]
        })

    try:
        previous = check_existing()

        if previous is not None:
            return previous

        opened_at = datetime.now(
            timezone.utc
        ).isoformat()

        # 4. Atomic transaction: occupy table + create bill
        CLIENT.transact_write_items(
            TransactItems=[
                {
                    "Update": {
                        "TableName": TABLES['tables'],
                        "Key": {
                            "table_id": {"S": table_id}
                        },
                        "UpdateExpression":
                            "SET #s = :occupied, active_bill_id = :bill",
                        "ConditionExpression":
                            "attribute_exists(table_id) "
                            "AND #s = :free "
                            "AND attribute_not_exists(active_bill_id)",
                        "ExpressionAttributeNames": {
                            "#s": "status"
                        },
                        "ExpressionAttributeValues": {
                            ":occupied": {"S": "OCCUPIED"},
                            ":free": {"S": "FREE"},
                            ":bill": {"S": bill_id}
                        }
                    }
                },
                {
                    "Put": {
                        "TableName": TABLES['bills'],
                        "Item": {
                            "bill_id": {"S": bill_id},
                            "table_id": {"S": table_id},
                            "guest_count": {
                                "N": str(guest_count)
                            },
                            "status": {"S": "OPEN"},
                            "total_vnd": {"N": "0"},
                            "opened_at": {"S": opened_at},
                            "opened_by": {"S": actor},
                            "request_hash": {
                                "S": request_hash
                            },
                            "version": {"N": "1"}
                        },
                        "ConditionExpression":
                            "attribute_not_exists(bill_id)"
                    }
                }
            ]
        )

        return open_response(201, {
            "bill_id": bill_id,
            "table_id": table_id,
            "status": "OPEN",
            "opened_at": opened_at
        })

    except ClientError as e:
        code = e.response["Error"]["Code"]

        if code in (
            "TransactionCanceledException",
            "TransactionInProgressException"
        ):
            try:
                previous = check_existing()

                if previous is not None:
                    return previous
            except ClientError:
                pass

            return open_response(409, {
                "error": "TABLE_NOT_AVAILABLE",
                "message": "Table is occupied or cannot be opened"
            })

        print("DynamoDB error:", code)
        return open_response(500, {
            "error": "INTERNAL_SERVER_ERROR"
        })


def lambda_handler(event, context):
    identity = staff(event)
    if identity is None:
        return error(401, 'UNAUTHORIZED', 'Thiếu danh tính Cognito')
    actor, role = identity
    if not role:
        return error(403, 'FORBIDDEN', 'Chỉ RECEPTION và ADMIN được sử dụng')
    method = str(event.get('httpMethod', '')).upper()
    resource = event.get('resource') or event.get('path') or ''
    params = event.get('pathParameters') or {}
    bill_id = params.get('billId')
    try:
        if method == 'POST' and resource.endswith('/staff/bills'):
            return open_bill(event, actor)
        if method == 'GET' and resource.endswith('/staff/tables'):
            return list_tables(event)
        if method == 'GET' and resource.endswith('/staff/bills'):
            return list_bills(event)
        if method == 'GET' and (resource.endswith('/staff/bills/{billId}') or resource.endswith('/staff/bills/{billId}/receipt')):
            return view_bill(bill_id, event)
        if method == 'POST' and resource.endswith('/staff/bills/{billId}/close'):
            return close_bill(bill_id, event, actor, role, context)
        return error(404, 'ROUTE_NOT_FOUND', 'Không có route Reception phù hợp')
    except ClientError as exc:
        print('DynamoDB error:', exc.response.get('Error', {}).get('Code', 'Unknown'))
        return error(500, 'DATABASE_ERROR', 'Lỗi DynamoDB; xem CloudWatch Logs')
    except RuntimeError as exc:
        print('Runtime error:', str(exc))
        return error(503, 'RETRY_LATER', 'Không thể đọc hết dữ liệu; thử lại')
    except (ValueError, KeyError, TypeError, InvalidOperation) as exc:
        print('Data error:', type(exc).__name__, str(exc))
        return error(409, 'INCONSISTENT_DATA', 'Bill, recipe hoặc dữ liệu kho không nhất quán; cần kiểm tra')
