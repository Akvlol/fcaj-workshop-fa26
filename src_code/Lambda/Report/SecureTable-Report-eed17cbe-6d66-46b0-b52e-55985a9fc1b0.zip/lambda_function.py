"""SecureTable scheduled email reporting (EventBridge Scheduler -> Lambda -> SNS).

Uses the exact pure calculation functions copied from the deployed Finance Lambda.
No API endpoint, no Cognito user, no SNS email addresses or AWS credentials in code.

Dry-run event (safe, never writes or emails):
  {"report_type":"DAILY","business_date":"2026-11-23","dry_run":true}
Normal Scheduler events:
  {"report_type":"DAILY"} or {"report_type":"WEEKLY"}
"""
import json
import os
import time
import uuid
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import boto3
from botocore.exceptions import ClientError
import finance_core as fin

TZ = ZoneInfo('Asia/Ho_Chi_Minh')
DB = boto3.resource('dynamodb')
SNS = boto3.client('sns')
DISPATCH_TABLE = DB.Table(os.environ.get('DISPATCH_TABLE', 'SecureTable-ReportDispatch'))
TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN', '').strip()
LEASE_SECONDS = 900


def local_now():
    return datetime.now(TZ)


def choose_period(event, today):
    # Scheduler inserts <aws.scheduler.scheduled-time> into the target input.
    # Anchoring the date to its scheduled instant keeps retries after midnight
    # from accidentally reporting the wrong business day.
    scheduled = event.get('scheduled_at')
    if scheduled:
        try:
            run_at = datetime.fromisoformat(scheduled.replace('Z', '+00:00'))
            if run_at.tzinfo is None:
                raise ValueError('scheduled_at must include time zone')
            today = run_at.astimezone(TZ).date()
        except (ValueError, AttributeError) as exc:
            raise ValueError('Invalid scheduled_at timestamp') from exc
    typ = event.get('report_type')
    if typ not in ('DAILY', 'WEEKLY'):
        raise ValueError('report_type must be DAILY or WEEKLY')
    if typ == 'DAILY':
        start = fin.parse_day(event['business_date']) if event.get('business_date') else today
        end = start
    else:
        if event.get('week_start'):
            start = fin.parse_day(event['week_start'])
            if start.weekday() != 0:
                raise ValueError('week_start must be a Monday')
        else:
            start = today - timedelta(days=today.weekday())
        end = start + timedelta(days=6)
    if end > local_now().date() and event.get('dry_run') is not True:
        raise ValueError('Cannot send a report for a future period')
    if start < today - timedelta(days=365):
        raise ValueError('Period is more than 365 days in the past')
    return typ, start, end


def report_readiness(start, end, data, pending_items):
    """Fail-safe: OPEN/CLOSING anywhere, pending items/reservations anywhere,
    and no recorded CONFIRMED stock count for a business day -> provisional.
    This is a read-time warning, not a transactional restaurant lock.
    """
    reasons = []
    active = [b for b in data['bills'] if b.get('status') in ('OPEN', 'CLOSING')]
    if active:
        reasons.append(f'Còn {len(active)} Bill OPEN/CLOSING (toàn nhà hàng)')
    pending_count = sum(1 for x in pending_items if x.get('status') == 'ORDERED')
    if pending_count:
        reasons.append(f'Còn {pending_count} phần món ORDERED')
    reserved = [i for i in data['ingredients'] if fin.as_vnd(i, 'reserved') > 0]
    if reserved:
        reasons.append(f'Còn {len(reserved)} nguyên liệu đang reserved')
    cascading = [i for i in data['ingredients'] if i.get('stockout_cascade_state') == 'PENDING']
    if cascading:
        reasons.append(f'Còn {len(cascading)} xử lý OUT_OF_STOCK chưa hoàn tất')
    counted_days = set()
    for c in data['counts']:
        if c.get('status') == 'CONFIRMED':
            d = c.get('business_date') or fin.business_day(c.get('confirmed_at'))
            if d:
                counted_days.add(d)
    no_count = []
    day = start
    while day <= end:
        if day.isoformat() not in counted_days:
            no_count.append(day.isoformat())
        day += timedelta(days=1)
    if no_count:
        reasons.append('Chưa có kiểm kê CONFIRMED cho ngày: ' + ', '.join(no_count))
    return reasons


def vnd(n):
    return f'{int(n):,}'.replace(',', '.') + ' VND'


def construct_report(typ, start, end, data, pending_items):
    days = fin.build_metrics(start, end, data)
    stats = fin.summary(days, start, end, include_rows=True)
    reasons = report_readiness(start, end, data, pending_items)
    ready = not reasons
    range_label = start.isoformat() if typ == 'DAILY' else f'{start.isoformat()} -> {end.isoformat()}'
    # Amazon SNS email Subject must use ASCII and be <=100 characters.
    prefix = 'Bao cao ngay' if typ == 'DAILY' else 'Bao cao tuan'
    subject = f'[SecureTable] {prefix} {range_label} ' + ('(DA CHOT)' if ready else '(TAM TINH)')
    lines = [
        'SECURETABLE — BÁO CÁO TÀI CHÍNH',
        'Kỳ báo cáo: ' + range_label + ' | Múi giờ: Asia/Ho_Chi_Minh',
        'Trạng thái: ' + ('ĐỦ ĐIỀU KIỆN CHỐT THEO MVP' if ready else 'TẠM TÍNH — CHƯA ĐỦ ĐIỀU KIỆN CHỐT'),
        '',
        'SỐ LIỆU TỔNG HỢP',
        f"Bill PAID / UNPAID / EMPTY: {stats['bills']['paid']} / {stats['bills']['unpaid']} / {stats['bills']['empty']}",
        'Doanh thu thực thu (PAID): ' + vnd(stats['collected_revenue_vnd']),
        'Khoản chưa thu (UNPAID): ' + vnd(stats['unpaid_bill_value_vnd']),
        'Chi mua nguyên liệu (sau điều chỉnh): ' + vnd(stats['purchase_spend_vnd']),
        'Giá vốn nguyên liệu tiêu hao (ước tính): ' + vnd(stats['material_consumption_cost_vnd']),
        'Giá trị thất thoát nguyên liệu (ước tính): ' + vnd(stats['inventory_loss_cost_vnd']),
        'Chênh lệch thu tiền - chi mua hàng: ' + vnd(stats['cash_difference_vnd']),
        'Lợi nhuận gộp ước tính: ' + vnd(stats['estimated_gross_profit_vnd']),
        'Lợi nhuận sau thất thoát (ước tính): ' + vnd(stats['estimated_after_loss_vnd']),
        '',
    ]
    if reasons:
        lines += ['CẢNH BÁO — BÁO CÁO CHƯA CHỐT:'] + ['- ' + reason for reason in reasons] + ['']
    if typ == 'WEEKLY':
        lines.append('CHI TIẾT TỪNG NGÀY:')
        for d in days:
            lines.append(f"- {d['date']}: PAID {vnd(d['collected_revenue_vnd'])}; "
                         f"mua hàng {vnd(d['purchase_spend_vnd'])}; "
                         f"thất thoát {vnd(d['inventory_loss_cost_vnd'])}")
        lines.append('')
    else:
        lines.append('TỒN KHO HIỆN TẠI (không phải tồn tại ngày lịch sử):')
        stock = fin.stock_view(data)
        for i in stock[:30]:
            lines.append(f"- {i['name']} [{i['ingredient_id']}]: {i['qty_base']:g} {i['unit']}; "
                         f"đã giữ chỗ {i['reserved']:g} {i['unit']}")
        if len(stock) > 30:
            lines.append(f'- Còn {len(stock)-30} nguyên liệu; xem trên Dashboard')
        lines.append('')
    lines.extend([
        'GHI CHÚ:',
        '- Doanh thu thực thu chỉ tính Bill CLOSED/PAID theo ngày đóng Bill.',
        '- UNPAID theo dõi riêng, KHÔNG cộng vào doanh thu thực thu.',
        '- Chi mua hàng KHÔNG phải giá vốn tiêu hao; chênh lệch thu-chi không phải lợi nhuận ròng.',
        '- Giá vốn và thất thoát sử dụng giá nhập gần nhất, chỉ là ước tính MVP.',
        '- Chưa trừ lương, mặt bằng, điện nước và các chi phí vận hành khác.',
        '- Báo cáo quét DynamoDB, không phải ảnh chụp nhất quán của nhiều bảng cùng thời điểm.',
        'Dashboard: https://d2ywqywgcyo1r7.cloudfront.net/finance.html',
    ])
    message = '\n'.join(lines)
    if len(message.encode('utf-8')) > 200_000:
        raise ValueError('Email content is too long')
    return subject, message, ready, reasons, stats


def claim(report_key, token, now_epoch):
    """Dedupe all invocations with conditional DynamoDB writes.
    A crash after SNS publish but before marking SENT can still create duplicate
    mail on later retries: SNS and DynamoDB have no shared transaction.
    """
    nowiso = datetime.now(TZ).isoformat()
    item = {'report_key': report_key, 'status': 'PROCESSING', 'token': token,
            'lock_until': now_epoch + LEASE_SECONDS, 'created_at': nowiso}
    try:
        DISPATCH_TABLE.put_item(Item=item, ConditionExpression='attribute_not_exists(report_key)')
        return 'ACQUIRED'
    except ClientError as exc:
        if exc.response['Error']['Code'] != 'ConditionalCheckFailedException':
            raise
    old = DISPATCH_TABLE.get_item(Key={'report_key': report_key}, ConsistentRead=True).get('Item') or {}
    if old.get('status') == 'SENT':
        return 'ALREADY_SENT'
    if int(old.get('lock_until', 0)) >= now_epoch:
        # Let EventBridge/Lambda retry handler failures rather than hiding a failure.
        raise RuntimeError('Another invocation currently processes this period')
    try:
        DISPATCH_TABLE.update_item(
            Key={'report_key': report_key},
            UpdateExpression='SET #s=:processing, #tok=:token, lock_until=:lease',
            ConditionExpression='attribute_exists(report_key) AND #s <> :sent AND lock_until < :now',
            ExpressionAttributeNames={'#s': 'status', '#tok': 'token'},
            ExpressionAttributeValues={':processing': 'PROCESSING', ':token': token,
                                       ':lease': now_epoch + LEASE_SECONDS,
                                       ':sent': 'SENT', ':now': now_epoch})
        return 'ACQUIRED'
    except ClientError as exc:
        if exc.response['Error']['Code'] == 'ConditionalCheckFailedException':
            raise RuntimeError('Period was claimed by another invocation') from exc
        raise


def mark_success(report_key, token, sns_message_id):
    DISPATCH_TABLE.update_item(
        Key={'report_key': report_key},
        UpdateExpression='SET #s=:sent, sns_message_id=:msg, sent_at=:when REMOVE lock_until',
        ConditionExpression='#s=:processing AND #tok=:token',
        ExpressionAttributeNames={'#s': 'status', '#tok': 'token'},
        ExpressionAttributeValues={':sent': 'SENT', ':msg': sns_message_id,
                                   ':when': datetime.now(TZ).isoformat(),
                                   ':processing': 'PROCESSING', ':token': token})


def mark_failed(report_key, token):
    DISPATCH_TABLE.update_item(
        Key={'report_key': report_key},
        UpdateExpression='SET #s=:failed, lock_until=:zero',
        ConditionExpression='#s=:processing AND #tok=:token',
        ExpressionAttributeNames={'#s': 'status', '#tok': 'token'},
        ExpressionAttributeValues={':failed': 'FAILED', ':zero': 0,
                                   ':processing': 'PROCESSING', ':token': token})


def lambda_handler(event, context):
    if not isinstance(event, dict):
        raise ValueError('Event must be a JSON object')
    typ, start, end = choose_period(event, local_now().date())
    key = typ + '#' + start.isoformat()
    data = fin.load_data(include_stock=True)
    pending_items = scan_order_items()
    subject, message, ready, warnings, stats = construct_report(typ, start, end, data, pending_items)
    if event.get('dry_run') is True:
        return {'mode': 'DRY_RUN', 'report_key': key, 'ready': ready,
                'warnings': warnings, 'subject': subject, 'message': message,
                'metrics': stats}
    if not TOPIC_ARN or not TOPIC_ARN.startswith('arn:aws:sns:'):
        raise ValueError('Set SNS_TOPIC_ARN in Lambda environment variables')
    token = getattr(context, 'aws_request_id', None) or uuid.uuid4().hex
    status = claim(key, token, int(time.time()))
    if status == 'ALREADY_SENT':
        return {'status': 'ALREADY_SENT', 'report_key': key}
    try:
        result = SNS.publish(TopicArn=TOPIC_ARN, Subject=subject[:100], Message=message)
    except Exception:
        try:
            mark_failed(key, token)
        except Exception:
            print('Could not release report claim after SNS error:', key)
        raise
    # If this update fails after SNS publish, a later retry may send duplicate email.
    mark_success(key, token, result['MessageId'])
    print('SecureTable report sent:', key)
    return {'status': 'SENT', 'report_key': key, 'ready': ready,
            'warnings': warnings, 'sns_message_id': result['MessageId']}


def scan_order_items():
    table = DB.Table(os.environ.get('ORDER_ITEMS_TABLE', 'SecureTable-OrderItems'))
    out, cursor = [], None
    for _ in range(fin.MAX_PAGES_PER_TABLE):
        params = {'ConsistentRead': True}
        if cursor:
            params['ExclusiveStartKey'] = cursor
        r = table.scan(**params)
        out.extend(r.get('Items') or [])
        if len(out) > fin.MAX_ITEMS_PER_TABLE:
            raise RuntimeError('REPORT_TOO_LARGE')
        cursor = r.get('LastEvaluatedKey')
        if not cursor:
            return out
    raise RuntimeError('REPORT_TOO_LARGE')
